<?php 
ob_start();
$API_KEY = "1270746171:AAHV-JZ_wkYvuq06E9BUH9-o1vkYsQQfhxY";#توكن البوت
define('API_KEY',$API_KEY);
echo "<a href='https://api.telegram.org/bot$API_KEY/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']."'>setwebhook</a>";
echo file_get_contents("https://api.telegram.org/bot$API_KEY/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']);
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;

curl_setopt($ch,CURLOPT_URL,$url); curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{return json_decode($res);}}
$update   = json_decode(file_get_contents('php://input'));
$message  = $update->message;
$text     = $message->text;
$chat_id  = $message->chat->id;
$name     = $message->from->first_name;
$user     = $message->from->username;
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
$a = strtolower($text);
$message = $update->message;
$message = $update->message;
$username = $message->from->username;
$message_id2 = $update->callback_query->message->message_id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$Name = $update->callback_query->from->first_name;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$text = $message->text;
$useree = $update->callback_query->message->chat->id;
$username = $message->from->username;
$fn = $message->from->first_name;
$user_id = $message->from->id;
$admin = "1010918290";
$ch = "ThePHPbots";
$fromid = $message->from->id;
$name = $message->from->first_name;
if($text == '/start'){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=> "
*اهلا بك يا* [$name](tg://user?id=$from_id) 
لـ عرض الايدي الخاص بك أرسل /id
لـ عرض معلوماتك أرسل /infome
",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"• قناة الـبوت 🧡. •", 'url'=>'t.me/$ch']],
]
])
]);
} 
if($text == "/id") {
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
اضغط على ايديك ليتم نسخه
⌯ `$fromid` 🆔
",
]);
}
if($text == "/infome" ){
bot('sendMessage',[
'chat_id'=>$chat_id,
'parse_mode'=>'MarkDown',
'disable_web_page_preview'=>true,
"text"=>"*Name 💲 = $name *
*ID 🗯 =* `$fromid`
*UserName 🃏* = @$username ",
'reply_to_message_id'=>$message->message_id, 
]);
}