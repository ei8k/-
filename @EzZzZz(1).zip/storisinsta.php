<?php

// تخمط اذكر اسمي حبي #كلاوجي
// قناتي @NONBBN
//معرفي @ll8III

ob_start();
$Token = "1073935834:AAGuO4PJMnJaiQymkbVkhyfUoTu0lo0VN20";
define('API_KEY',$Token);
echo file_get_contents("https://api.telegram.org/bot" . API_KEY . "/setwebhook?url=" . $_SERVER['SERVER_NAME'] . "" . $_SERVER['SCRIPT_NAME']);
function bot($method,$datas=[]){
$Alsh = http_build_query($datas);
$url = "https://api.telegram.org/bot".API_KEY."/".$method."?$Alsh";
$Alsh = file_get_contents($url);
return json_decode($Alsh);}
#كود ضغط ملف ى سعيد
function AliZip($AliZip1, $AliZip2){
$AliZip4 = realpath($AliZip1);
$AliZip = new ZipArchive();
$AliZip->open($AliZip2, ZipArchive::CREATE | ZipArchive::OVERWRITE);
$AliZip3 = new RecursiveIteratorIterator(
new RecursiveDirectoryIterator($AliZip4),
RecursiveIteratorIterator::LEAVES_ONLY);
foreach($AliZip3 as $AliZip5 => $AliZip6){
if(!$AliZip6->isDir()){
$AliZip7 = $AliZip6->getRealPath();
$AliZip8 = substr($AliZip7, strlen($AliZip4) + 1);
$AliZip->addFile($AliZip7, $AliZip8);
}}
$AliZip->close();
}
# كود حجم الملف لـ @MrDGSY #
function AliZip1($AliZip9, $AliZip10 = 2){
$AliZip11=array(' B', ' KB', ' MB', ' GB', ' TB', ' PB', ' EB', ' ZB', ' YB');
$AliZip12=floor((strlen($AliZip9) - 1) / 3);
return sprintf("%.{$AliZip10}f", $AliZip9 / pow(1024, $AliZip12)) . @$AliZip11[$AliZip12];
}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$caption = $update->message->caption;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$text = $message->text;
$data = $update->callback_query->data;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id2 = $update->callback_query->message->message_id;
$name = $message->from->first_name;
$user = $message->from->username;
$abbas = "AWM_AWM"; 
$admin = "1010918290";
$tws = file_get_contents("tw.txt");
$de = file_get_contents("admin2.txt");
$ad = array("$admin","$de");
$list = file_get_contents("blocklist.txt");
$ebu = explode("\n",$list);
$type       = $update->message->chat->type;
if(in_array($from_id,$ebu)){
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"⛳| عزيزي انت محظور من البوت",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);    
}
mkdir('alsh');
include "php.php";
#التخزين ايديات
$from_id = $message->from->id;
$type       = $update->message->chat->type;
$gp = explode("\n",file_get_contents("group.txt"));
$pv = explode("\n",file_get_contents("alsh/Alsh.txt"));
$sta = file_get_contents("start.txt");
#شتراك اجباري خاصه
$all = file_get_contents("id.txt");
$rabt = file_get_contents("rabt.txt");
$join = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$all&user_id=".$from_id);
if($message && (strpos($join,'"status":"left"') or strpos($join,'"Bad Request: USER_ID_INVALID"') or strpos($join,'"status":"kicked"'))!== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لستخدام البوت عليك اشتراك في قنوات البوت 🎁.
بعد الاشتراك في القنوات اضغط - /start 📦.",
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
          'inline_keyboard'=>[
[['text'=>"📦. اشترك -",'url'=>"$rabt"]],
]])]);return false;}
#شتراك اجباري1
$op = file_get_contents("ch.txt");
$join = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$op&user_id=".$from_id);
if($message && (strpos($join,'"status":"left"') or strpos($join,'"Bad Request: USER_ID_INVALID"') or strpos($join,'"status":"kicked"'))!== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لستخدام البوت عليك اشتراك في قنوات البوت 🎁.
بعد الاشتراك في القنوات اضغط - /start 📦.
قناة البوت : @$op",
'reply_to_message_id'=>$message->message_id,
]);return false;}
#شتراك اجباري2
$oop = file_get_contents("chc.txt");
$join = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$oop&user_id=".$from_id);
if($message && (strpos($join,'"status":"left"') or strpos($join,'"Bad Request: USER_ID_INVALID"') or strpos($join,'"status":"kicked"'))!== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لستخدام البوت عليك اشتراك في قنوات البوت 🎁.
بعد الاشتراك في القنوات اضغط - /start 📦.
قناة البوت : @$oop",
'reply_to_message_id'=>$message->message_id,
]);return false;}
if($text and $text != "/start"){
file_put_contents("text.txt", "$text\n",FILE_APPEND);}
if($text and $type == "private" and !in_array($from_id, $pv)){
file_put_contents("alsh/Alsh.txt", "$from_id\n",FILE_APPEND);}
if($text and $type == "supergroup" and !in_array($chat_id, $gp)) {
file_put_contents("group.txt", "$chat_id\n",FILE_APPEND);}
if($text == "/start" and !in_array($from_id,$ebu) and !in_array($chat_id,$ad) and $chat_id != $admin and $sta == null){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
مرحبا بك. ، $name ،

خلي رساله ستارتك تريدةه.
",
'parse_mode'=>"Markdown",
'disable_web_page_preview'=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"$name","url"=>"t.me/$user"]],
]])
]);   
}
if($text == "/start" and !in_array($from_id,$ebu) and !in_array($chat_id,$ad) and $chat_id != $admin and $sta != null){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"مـرحبا بك عزيزي 🎁. ، $name ،
$sta
",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"$name","url"=>"t.me/$user"]],
]])
]);   
}

$bot = file_get_contents("com.txt");
if($text == "/start" and in_array($chat_id,$ad)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"آهلا بك $name 🍟.
🎺| يمكنك استخدام الاوامر الموجوده في اسفل.
📌| لعرض احصائيات البوت ارسل : /mem.
",
'parse_mode'=>"Markdown",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"تغير رساله ال/start ،📎.","callback_data"=>"start"]],
[["text"=>"تفعيل التواصل ،📯.","callback_data"=>"utws"],["text"=>"تعطيل التواصل ،📌.","callback_data"=>"ntws"]],
[["text"=>"حظـر عضو ،📤.","callback_data"=>"bn"],["text"=>"الغاء حظر العضو ،📦.","callback_data"=>"unbn"]],
[["text"=>"آضـآفهہ‏‏ آدمـن للبوت ،📚.","callback_data"=>"admin"],["text"=>"حذف آدمـن آلبوت ،🍟.","callback_data"=>"unadmin"]],
[["text"=>"مـعلومـآت العضو بالايدي ،🎺.","callback_data"=>"info"],["text"=>"مـعلومـآت عضو بالمعرف ،🎄.","callback_data"=>"infous"]],
[["text"=>"قسم شتراك اجباري ،🎯.","callback_data"=>"chh"],["text"=>"قسم الاذاعه ،🏆.","callback_data"=>"bcc"]],
[["text"=>"تجربه كود ،💧.","callback_data"=>"setphp"],["text"=>"حذف لكود ،🚿.","callback_data"=>"delphp"]],
[["text"=>"تفعيل اشعار الدخول ،🔖.","callback_data"=>"on"],["text"=>"تعطيل اشعار الدخول ،🎵.","callback_data"=>"off"]],
[["text"=>"نسـخهہ‏‏ احتياطيه ،💛.","callback_data"=>"get"],["text"=>"نسـخهہ‏‏ من اعضا ،🔦.","callback_data"=>"upmem"]],
[["text"=>" رفع نسخه من اعضا ،📮.","callback_data"=>"puo"]],
[["text"=>"حذف جميع احصائيات البوت ،🌻.","callback_data"=>"delbot"]],
]])
]);   
unlink("com.txt");
}
#رجوع
if($data == "bk" and in_array($chat_id2,$ad)){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"آهلا بك $name 🍟.
🎺| يمكنك استخدام الاوامر الموجوده في اسفل.
📌| لعرض احصائيات البوت ارسل : /mem.
",
'parse_mode'=>"Markdown",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"تغير رساله ال/start ،📎.","callback_data"=>"start"]],
[["text"=>"تفعيل التواصل ،📯.","callback_data"=>"utws"],["text"=>"تعطيل التواصل ،📌.","callback_data"=>"ntws"]],
[["text"=>"حظـر عضو ،📤.","callback_data"=>"bn"],["text"=>"الغاء حظر العضو ،📦.","callback_data"=>"unbn"]],
[["text"=>"آضـآفهہ‏‏ آدمـن للبوت ،📚.","callback_data"=>"admin"],["text"=>"حذف آدمـن آلبوت ،🍟.","callback_data"=>"unadmin"]],
[["text"=>"مـعلومـآت العضو بالايدي ،🎺.","callback_data"=>"info"],["text"=>"مـعلومـآت عضو بالمعرف ،🎄.","callback_data"=>"infous"]],
[["text"=>"قسم شتراك اجباري ،🎯.","callback_data"=>"chh"],["text"=>"قسم الاذاعه ،🏆.","callback_data"=>"bcc"]],
[["text"=>"تجربه كود ،💧.","callback_data"=>"setphp"],["text"=>"حذف لكود ،🚿.","callback_data"=>"delphp"]],
[["text"=>"تفعيل اشعار الدخول ،🔖.","callback_data"=>"on"],["text"=>"تعطيل اشعار الدخول ،🎵.","callback_data"=>"off"]],
[["text"=>"نسـخهہ‏‏ احتياطيه ،💛.","callback_data"=>"get"],["text"=>"نسـخهہ‏‏ من اعضا ،🔦.","callback_data"=>"upmem"]],
[["text"=>" رفع نسخه من اعضا ،📮.","callback_data"=>"puo"]],
[["text"=>"حذف جميع احصائيات البوت ،🌻.","callback_data"=>"delbot"]],
]])
]);   
unlink("com.txt");
}
#تفعيل اشعار دخول
if($data == "on" and in_array($chat_id2,$ad)){
file_put_contents("onn.txt","on");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"💘| تم تفعيل اشعار الدخول،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
#تعطيل اشعار دخول
if($data == "off" and in_array($chat_id2,$ad)){
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🔖| تم تعطيل الاشعار الدخول،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
unlink('onn.txt');
}
#حذف آدمن
if($data == "unadmin" and $chat_id2 == $admin){
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"تم حذف الادمن.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،📌.","callback_data"=>"bk"]],
]])
]);   
unlink('admin2.txt');
}
#قسم حذف كل
if($data == "delbot" and in_array($chat_id2,$ad)  ){
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮| عزيزي هل انت متاكد من انك تريد حذف جميع احصائيات البوت،
🎄| #مـلآحظـهہ‏‏ سيتم حذف جميع ايديات الاعضا،الاشتراك الاجباري،اعضا المحظورين،عدد رسائل داخل لبوت و....،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"نعم ،📌.","callback_data"=>"dell"],["text"=>"لآ ،📌.","callback_data"=>"bk"]],
]])
]);   
}
if($data == "dell" and in_array($chat_id2,$ad)  ){
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮| تم حذف جميع احصائيات البوت اصبح الان جديد",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،📌.","callback_data"=>"bk"]],
]])
]);   
unlink("start.txt");
unlink("tw.txt");
unlink("blocklist.txt");
unlink("admin2.txt");
unlink("alsh/Alsh.txt");
unlink("rabt.txt");
unlink("id.txt");
unlink("ch.txt");
unlink("chc.txt");
unlink("text.txt");
unlink("php.php");
}
#قسم الاذاعه
if($data == "bcc" and in_array($chat_id2,$ad)  ){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"💛| حسننا الان قم بختيار الاذاعه من فضلك،",
'disable_web_page_preview'=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"آذآعهہ‏‏ رسـآلهہ‏‏ ،🌻.","callback_data"=>"bc"],["text"=>"آذآعهہ‏‏ بآلتوجيهہ‏‏ ،🌻.","callback_data"=>"for"]],
[["text"=>"آذآعهہ‏‏ شـفآف ،🌻.","callback_data"=>"inln"],["text"=>"آذآعهہ‏‏ بآلمـيديآ ،🌻.","callback_data"=>"med"]],
[["text"=>"آذآعهہ‏‏ HTML ،🌻.","callback_data"=>"HTML"],["text"=>"آذآعهہ‏‏ MarkDown ،🌻.","callback_data"=>"MarkDown"]],
[["text"=>"آذآعهہ‏‏ للمجموعات ،🌻.","callback_data"=>"sndgp"],["text"=>"آذآعهہ‏‏ للكل مجموعات و اعضا ،🌻.","callback_data"=>"MarkDown"]],
[["text"=>"رجوع ،🌻.","callback_data"=>"bk"]],
]])
]);   
}
#قسم شتراك اجباري
if($data == "chh" and in_array($chat_id2,$ad)  ){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🌻| حسننا عزيزي قم بلختيار من الاسفل لوضع شتراك اجباري،",
'disable_web_page_preview'=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"قناة عامه 1 ،🎺.","callback_data"=>"add2"],["text"=>"قناة عامه 2 ،🎺.","callback_data"=>"add1"]],
[["text"=>"قناة خاصه ،🎺.","callback_data"=>"add"]],
[["text"=>"حذف جميع القنوات من شتراك ،🎺.","callback_data"=>"remch"]],
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
#الاحصائيات
$tkzk = explode("\n",file_get_contents("text.txt"));
$meb = explode("\n",file_get_contents("alsh/Alsh.txt"));
$band = explode("\n",file_get_contents("blocklist.txt"));
$tx = explode("\n",file_get_contents("text.txt"));
$admn = file_get_contents("admin2.txt");
$gpp = explode("\n",file_get_contents("group.txt"));
$mem = count($meb)-1;
$zktex = count($tkzk)-1;
$bnn = count($band)-1;
$ts = count($tx)-1;
$grup = count($gpp)-1;
$oop = file_get_contents("chc.txt");
$op = file_get_contents("ch.txt");
$all = file_get_contents("id.txt");
$rabt = file_get_contents("rabt.txt");
if($text == "/mem" and in_array($chat_id,$ad)  ){
 date_default_timezone_set("Asia/Baghdad");
$getMe = bot('getMe')->result;
$date = $message->date;
$gettime = time();
$sppedtime = $gettime - $date;
$time = date('h:i');
$date = date('y/m/d');
$userbot = "{$getMe->username}";
$userb = strtoupper($userbot);
if ($sppedtime == 3  or $sppedtime < 3) {
$f = "ممتازة 👏🏻";}
if ($sppedtime == 9 or $sppedtime > 9 ) {
$f = "لا بأس 👍🏻";}
if ($sppedtime == 10 or $sppedtime > 10) {
$f = " سئ جدا 👎🏻"; }
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🌻| عدد العضاء : *$mem*،
🌻| عدد الاعضا المحظورين : *$bnn*،
🌻| سرعهہ‏‏ البوت : *$f*،
🌻|  عدد رسائل داخل البوت : *$ts*،
🌻|  عدد المجموعات : *$grup*،
🌻| الوقت و التاريخ : *20$date - $time*،
🌻|   آدمن الثاني : *$admn*،
🌻| قنوات الاشتراك الاجباري العام،
@$op ، @$oop
🌻| قناة الاشتراك الاجباري الخاص،
`$all` ، `$rabt`
",
'parse_mode'=>'MarkDown',
'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message->message_id,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
#رساله ستارت
if($data == "start" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","start");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🌻| حسننا الان قم برسال النص،
🐞| يمكنك ايضا استخدام الماركدوان كمثال،
[اضغط هنا وتابع جديدنا](t.me/alshh)",
'disable_web_page_preview'=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "start" and $text != "/h" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("start.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🎯| تم حفظ نص الاستارت،",
'reply_to_message_id'=>$message->message_id,
]);
unlink("com.txt");
}
#تفعيل تواصل
if($data == "utws" and in_array($chat_id2,$ad)  ){
file_put_contents("tw.txt","on");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📦|تم تفعيل التواصل ،",
]); 
}
#تعطيل تواصل
if($data == "ntws" and in_array($chat_id2,$ad)  ){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮|تم تعطيل التواصل ،",
]); 
unlink("tw.txt");
}
if($text and !in_array($from_id,$ebu) and !in_array($chat_id,$ad) and $chat_id != $admin and $tws == "on"){
bot('forwardMessage',[
'chat_id'=>$admin,
'from_chat_id'=>$chat_id,
'message_id'=>$update->message->message_id,
'text'=>$text,
]);
}
if($text and $message->reply_to_message && $text!="/info" && $text!="/ban" && $text!="/unban" && $text!="/forward" and !$data ){
bot('sendMessage',[
'chat_id'=>$message->reply_to_message->forward_from->id,
'text'=>$text,
]);
}
#اضافه ادمن
if($data == "admin" and $chat_id2 == $admin){
file_put_contents("com.txt","ad");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮| حسننا الان قم برسال ايدي العضو،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "ad" and $text != "/start" and $chat_id == $admin){
file_put_contents("admin2.txt",$text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"📮| تم حفظ ايدي العضو،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"🌻| تم رفعك ادمن بواسط صاحب البوت،",
'parse_mode'=>'MarkDown',
]);
unlink("com.txt");
}
#حظر
if($data == "bn" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","bn");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"💘| حسننا الان قم برسال ايدي العضو،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "bn" and $text != "/start" and in_array($chat_id,$ad)  ){
$myfile2 = fopen("blocklist.txt", "a") or die("Unable to open file!");	
fwrite($myfile2, "$text\n");
fclose($myfile2);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📨| تم حظر العضو بنجاح،",
]);
bot('sendmessage',[
'chat_id'=>$text,
'text'=>"📨| عذرا عزيزي تم حظرك،",
]);
unlink("com.txt");
}
#الغاء حظر
$listt = file_get_contents("blocklist.txt");
if($data == "unbn" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","unbn");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮| حسننا الان قم برسال ايدي العضو،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "unbn" and $text != "/start" and in_array($chat_id,$ad)  ){
$newlist = str_replace($text,"",$listt);
file_put_contents("blocklist.txt",$newlist);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🌻| تم آلغآء حظر العضو بنجاح،",
]);
bot('sendmessage',[
'chat_id'=>$text,
'text'=>"🌻| عزيزي تم آلغآء آلحظر عنك،",
]);
unlink("com.txt");
}
#معلومات
if($data == "info" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","info");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🎁| حسننا الان قم برسال ايدي العضو،
🌻| #ملاحظه يجب العضو يكون مشترك في لبوت مسبقا،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "info" and $text != "/start"and in_array($chat_id,$ad)  ){
$ine = json_decode(file_get_contents("http://api.telegram.org/bot".API_KEY."/getChat?chat_id=$text"));
$infe4 =$ine->result->first_name;
$infe2 =$ine->result->id;
$infe3 =$ine->result->username;
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"*🎯| INFO MEMBER*
🔖| Name 💬 : *$infe4* \n 🎧| User 💌 : [@$infe3] \n 📚| Id 🎄 : `$infe2`",
'reply_to_message_id'=>$message->message_id,
'parse_mode'=>'MarkDown', 
]);
unlink("com.txt");
}
#معلومات بالمعرف
if($data == "infous" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","infus");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسسنا الان ارسل معرف العضو الذي تريد استخراج معلوماته",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
#لمحمد سامي
if($bot == "infus" and $text != "/start"and in_array($chat_id,$ad)){
$get = json_decode(file_get_contents("https://mohammed-api.000webhostapp.com/Madeline?UserName=$text"));
$getinfo = $get->info;
$getId           =  $getinfo->UserId;
$getname           = $getinfo->FirstName;
$getuser           = $getinfo->UserName;
$getabout          = $getinfo->About;
$getDate           = $getinfo->Date;
$getTime           = $getinfo->Time;
$getChannel        = $getinfo->Channel;
bot("SendMessage",[
'chat_id'=>$chat_id,
'text'=>"
الايدي : $getId
اليوزر : @$getuser     
الاسم : $getname     
النبذه : $getabout     
التاريخ الان [ توقيت بغداد ] : $getDate
الوقت الان [توقيت بغداد ] : $getTime        ",
]);
unlink('com.txt');
}
#شتراك اجباري1
if($data == "add2" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","ab");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📦| حسـننا عزيزي قم برسال معرف قناتك مـندون ل @
📥| كمثال : `I8F8I`",
'parse_mode'=>"Markdown",
]);
}
if($bot == "ab" and $text != "/h" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("chc.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🎯| حسننا عزيزي تم حفظ قناتك الان قم برفعي مشرف في قناتك .
📮| قناتك : @$text.
لرجوع اضغط /start.",
'reply_to_message_id'=>$message->message_id,
]);
unlink("com.txt");
}
#شـترآك اجباري1
if($data == "add1" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","al");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📦| حسـننا عزيزي قم برسال معرف قناتك مـندون ل @
📚| كمثال : `I8F8I`",
'parse_mode'=>"Markdown",
]);
}

if($bot == "al" and $text != "/h" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("ch.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🎯| حسننا عزيزي تم حفظ قناتك الان قم برفعي مشرف في قناتك .
📮| قناتك : @$text.
لرجوع اضغط /start.",
'reply_to_message_id'=>$message->message_id,
]);
unlink("com.txt");
}
#شتراك خاص
if($data == "add"  and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","vv");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📌| حسننا عزيزي قم برسال ايدي قناتك !
📮| كمثال : `-1001416392355` !
📎| آن لم تعرف كيفه استخراج ايدي قناتك كل ماعليك قم برسال توجيه من قناتك لهاذ البوت ! @X59BoT !
لرجوع اضغط /start.",
'parse_mode'=>"Markdown",
]);
}

if($bot == "vv" and $text != "/o" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("com.txt","alo");
file_put_contents("id.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✂| تم حفظ ايدي قناتك !
📛| حسننا الان قم برسال رابط قناتك !
لرجوع اضغط /start.",
'reply_to_message_id'=>$message->message_id,
]);
}
if($bot == "alo" and $text != "/o" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("rabt.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"💛| تم حفظ رابط القناة .
📚| رابط قناتك : `[$text]`
🔖| آيدي قناتك : `$all`
🔖| آلآن قم برفع لبوت مشرفي في قناتك
لرجوع اضغط /start.",
'parse_mode'=>"Markdown",
'reply_to_message_id'=>$message->message_id,
]);
unlink("com.txt");
}
#حذف قنوات
if($data == "remch" and in_array($chat_id2,$ad)  ){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📦| تم حذف جميع القنوات،",
'parse_mode'=>"Markdown",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
unlink("rabt.txt");
unlink("id.txt");
unlink("ch.txt");
unlink("chc.txt");
}
#آذآعه MarkDown
if($data == "MarkDown" and in_array($chat_id2,$ad) ){
file_put_contents("com.txt","sendm");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسننا يمكنك يمكنك ارسال رساله و استخدام MarkDown .",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$alshh3 = fgets($ali);
if($bot == "sendm" and in_array($chat_id,$ad) ){
bot('sendMessage', [
'chat_id' =>$alshh3,
'text'=>$text,
'parse_mode'=>"html",
'disable_web_page_preview' =>"true"
]);
unlink("com.txt");
}
}

#اذاعه HTML
if($data == "HTML" and in_array($chat_id2,$ad) ){
file_put_contents("com.txt","sendh");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسننا عزيزي يمكنك ارسال رساله و استخدام HTML .",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$alshh3 = fgets($ali);
if($bot == "sendh" and in_array($chat_id,$ad) ){
bot('sendMessage', [
'chat_id' =>$alshh3,
'text'=>$text,
'parse_mode'=>"html",
'disable_web_page_preview' =>"true"
]);
unlink("com.txt");
}
}
#اذاعه مجموعات
$gy = explode("\n",file_get_contents("group.txt"));
if($data == "sndgp" and in_array($chat_id2,$ad) ){
file_put_contents("com.txt","sendap");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسننا ارسل رسالتك لكي اقوم برساله لل جميع مجموعات.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "send" and in_array($chat_id,$ad)  ){
foreach ($gy as $id){
bot('sendmessage',[
'chat_id'=>$id,
'text'=>$text,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);
}
unlink('com.txt');
}
#اذاعه للكل
$mee = explode("\n",file_get_contents("alsh/Alsh.txt"));
if($data == "sendall" and in_array($chat_id2,$ad) ){
file_put_contents("com.txt","sendap");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسننا ارسل رسالتك لكي اقوم برساله لل جميع مجموعات و اعضاء.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "sendap" and in_array($chat_id,$ad)  ){
foreach ($gy as $id){
bot('sendmessage',[
'chat_id'=>$id,
'text'=>$text,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);
foreach ($mee as $idd){
bot('sendmessage',[
'chat_id'=>$id,
'text'=>$text,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);
}
unlink('com.txt');
}
}
#اذاعه
if($data == "bc" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","send");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>" ارسل رسالتك الان عزيزي 🎯.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$alshh3 = fgets($ali);
if($bot == "send" and in_array($chat_id,$ad)  ){
bot('sendMessage', [
'chat_id' =>$alshh3,
'text'=>$text,
'disable_web_page_preview' =>"true"
]);
unlink("com.txt");
}
}
$tx = file_get_contents("alh.txt");
if($data == "inln" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","sn");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسـننآ آلآن ارسل نص تريد نشرة ك منشور شفاف 🎁. #ملاحظه يمكنك استخدام الماركدوان ايضا",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "sn" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("alh.txt","$text");
file_put_contents("com.txt","snn");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"حسننا الان استخدم🎄.
text = link
text = link + text = link
نص = رابط
نص = رابط + نص = رابط",
'reply_to_message_id'=>$message->message_id,
]);
}
$i=0;
$keyboard = [];
$keyboard["inline_keyboard"] = [];
$rows = explode("\n",$text);
foreach($rows as $row){
$j=0;
$keyboard["inline_keyboard"][$i]=[];
$bottons = explode("+",$row);
foreach($bottons as $botton){
$alsh = explode("=",$botton."=");
$Ibotton = ["text" => trim($alsh[0]), "url" => trim($alsh[1])];
$keyboard["inline_keyboard"][$i][$j] = $Ibotton;
$j++;                }                $i++;            }
$reply_markup=json_encode($keyboard);
if($bot == "snn" and $text != "/start" and in_array($chat_id,$ad)  ){
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$alshh = fgets($ali);
bot('sendmessage',[
'chat_id'=>$alshh,
'text'=>$tx,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'reply_markup'=>($reply_markup)
]);
}
unlink("com.txt");
unlink("alh.txt");
}
if($data == "for" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","fd");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>" ارسل توجيهك الان عزيزي 📌.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "fd" and $text != "/start" and in_array($chat_id,$ad)  ){
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$ali2 = fgets($ali);
bot('forwardMessage',[
 'chat_id'=>$ali2,
 'from_chat_id'=>$chat_id,
 'message_id'=>$message->message_id,
 ]);
 unlink("com.txt");
 }
 }
 if($data == "med" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","mide");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🔖| حسـننآ الان ارسل احد ميديا،
📌| مثلا : صور،فيديو،ملف،اغنيه،ملصق،ملف صوتي،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
#اذاعه ب ميديا
 if($message->video and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
 $ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
bot('sendvideo',['chat_id'=>$aly,'video'=>$message->video->file_id,'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,]);
bot('sendmessage',[ 
'chat_id'=>$chat_id, 'text'=>"تم نشر الفيديو '📚!",]); }unlink("com.txt"); }
if($message->document and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
bot('Senddocument',['chat_id'=>$aly,'document'=>$message->document->file_id,'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
]);bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الملف او متحركه '🎻!", ]); } unlink("com.txt");}
 if($message->audio and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
 	$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
 bot('sendaudio',[    'chat_id'=>$aly,    'audio'=>$message->audio->file_id,    'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
 ]); bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الاغنيه '🎺!", ]); } unlink("com.txt");}
if($message->photo and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
	$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
    bot('sendPhoto',[      'chat_id'=>$aly,      'photo'=>$message->photo[0]->file_id,      'caption'=>$message->caption,      'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
    ]);bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الصورة '📇!", ]); } unlink("com.txt");}
if($message->voice and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
	$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
    bot('sendvoice',[     'chat_id'=>$aly,      'voice'=>$message->voice->file_id,     'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
      ]);      bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الاغنيه '📜!", ]); } unlink("com.txt");}
      if($message->sticker and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
      	$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
bot('sendsticker',['chat_id'=>$aly,'sticker'=>$message->sticker->file_id
]);bot('sendmessage',['chat_id'=>$chat_id, 'text'=>"تم نشر الملصق '📂!", ]); }unlink("com.txt"); }
if($data == "get"  and in_array($chat_id2,$ad)){
$AliZip14 = "abba.cf"; //مسار استضافتك
date_default_timezone_set("Asia/Baghdad");
$AliZip13 = date("{h-i-s}");
AliZip('../', "Backup-$AliZip13.zip");
bot('senddocument',[
'chat_id'=>$chat_id2,
'document'=>"https://$AliZip14/Backup-$AliZip13.zip",
'caption'=>"Backup. 📦
Today's date : ".date('Y/m/d')." 📆
The Time is : ".date('h:i A')." ⏰
File size : ".AliZip1(filesize("Backup-$AliZip13.zip"))." 🏷",
'reply_to_message_id'=>$AliZip18,
]);
unlink("Backup-$AliZip13.zip");
}
if($data == "upmem" and in_array($chat_id2,$ad)){
$memZip14 = "abba.cf"; //مسار استضافتك
date_default_timezone_set("Asia/Baghdad");
$memZip13 = date("{h-i-s}");
AliZip('alsh', "Mem-$memZip13.zip");
bot('senddocument',[
'chat_id'=>$chat_id2,
'document'=>"https://$memZip14/Mem-$memZip13.zip",
'caption'=>"Mem. 📦
Today's date : ".date('Y/m/d')." 📆
The Time is : ".date('h:i A')." ⏰
File size : ".AliZip1(filesize("Mem-$memZip13.zip"))." 🏷",
]);
unlink("Mem-$memZip13.zip");
}
#رفع نسخه
if($data == "puo" and in_array($chat_id2,$ad) ){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسـننآ ارسل ملف الان لاكن ارسل صيغ ملف بل txt.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
$repad = $message->reply_to_message->document;
$aduo = $repad->file_id;
if(isset($repad) and in_array($chat_id,$ad)){
$url = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY.'/getFile?file_id='.$aduo),true);
$path = $url['result']['file_path'];
$file = 'https://api.telegram.org/file/bot'.API_KEY.'/'.$path;
$okey = file_put_contents("alsh/Alsh.txt",file_get_contents($file));
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"تم رفع نسخه بنجاح.",
]);
}
#الاشعار
$gg = file_get_contents("onn.txt");
if($gg == "on" and $chat_id != $admin and !$data){
bot("sendmessage",[
"chat_id"=>$admin,
"text"=>"- عضو جديد قام بالدخول الى البوت ، 🛡
- الاسم ، [$chat_id](tg://user?id=$chat_id) ، 🦕
- المعرف ، [@$user](tg://user?id=$chat_id) ، 🐢
- الايدي ، [$chat_id](tg://user?id=$chat_id) ، 🐝 
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
]);
}
#حفظ كود
if($data == "setphp" and in_array($chat_id2,$ad) ){
file_put_contents("com.txt","set");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسـننآ ارسل الكود الان.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "set" and in_array($chat_id,$ad)  ){
file_put_contents("php.php","<?php $text ?>");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"تم حفظ الكود." ,
'parse_mode'=>"Markdown",
]);
unlink('com.txt');
}
if($data == "delphp" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","set");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"تم حذف الكود..",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
unlink("php.php");
}
if($text == "/start"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=> "

• اهلا بك عزيزي  $name  ❤️
• - في بوت الخدمات الجديد 👖؛
- • البوت يحتوي عل كلشي شي تلزمه في قسم الستوريات 👜؛
 • - كل هاذ الاوامر مجانيه وسريعه جدا 👒؛

آلبوت يحتوي علهہ‌‏ آقسـآمـ آلتآليهہ‌‏ 💜؛
اضغط على احد الاوامر التالية 😉👇🏻
/A1 (لعرض قائمة البصمات) ❤️
/A2 (لعرض قائمة المقاطع) 💚

",
'parse_mode'=>"MARKDOWN",
'reply_markup'=>json_encode([
      'inline_keyboard'=>[
[

['text'=>" 🔱 مطور البوت " ,'url'=>"https://t.me/EzZzZz"]
],
]
])
]);
}



if($text == "/A1"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"اهــلا بك عزيزي $name  🖤

• فــي قائــمة البصمات 🎙

 - اضغط ع الأوامر التاليه لعرض البصمه 🎚
لعــرض بصمه رقم 1 >  /Q1
لعــرض بصمه رقم 2 >  /Q2
لعــرض بصمه رقم 3 >  /Q3
لعــرض بصمه رقم 4 >  /Q4
لعــرض بصمه رقم 5 >  /Q5
لعــرض بصمه رقم 6 >  /Q6
لعــرض بصمه رقم 7 >  /Q7
لعــرض بصمه رقم 8 >  /Q8
لعــرض بصمه رقم 9 >  /Q9
لعــرض بصمه رقم 10 >  /Q10
🖤~~~~~~~~~~~~~~~~~🖤",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/Q1"){
bot( sendaudio ,[
 chat_id =>$chat_id, 
 audio =>"https://t.me/AXZXVP/2",
 'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "/Q2"){
bot( sendaudio ,[
 chat_id =>$chat_id, 
 audio =>"https://t.me/AXZXVP/3",
 'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "/Q3"){
bot( sendaudio ,[
 chat_id =>$chat_id, 
 audio =>"https://t.me/AXZXVP/4",
 'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "/Q4"){
bot( sendaudio ,[
 chat_id =>$chat_id, 
 audio =>"https://t.me/AXZXVP/5",
 'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "/Q5"){
bot( sendaudio ,[
 chat_id =>$chat_id, 
 audio =>"https://t.me/AXZXVP/6",
 'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "/Q6"){
bot( sendaudio ,[
 chat_id =>$chat_id, 
 audio =>"https://t.me/AXZXVP/7",
 'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "/Q7"){
bot( sendaudio ,[
 chat_id =>$chat_id, 
 audio =>"https://t.me/AXZXVP/8",
 'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "/Q8"){
bot( sendaudio ,[
 chat_id =>$chat_id, 
 audio =>"https://t.me/AXZXVP/9",
 'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "/Q9"){
bot( sendaudio ,[
 chat_id =>$chat_id, 
 audio =>"https://t.me/AXZXVP/10",
 'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "/Q10"){
bot( sendaudio ,[
 chat_id =>$chat_id, 
 audio =>"https://t.me/AXZXVP/11",
 'reply_to_message_id' =>$message->message_id, 
]);
}
if($text == "/A2"){
bot('sendMessage',[
'chat_id'=>$chat_id, 
'text'=>"• اهــلا بك عزيزي $name  💛

• فــي قائــمة الفديوهات 📹

 - اضغط ع الأوامر التاليه لعرض الفيديو 🎥
لعــرض الفيديو رقم 1 >  /X1
لعــرض الفيديو رقم 2 >  /X2
لعــرض الفيديو رقم 3 >  /X3
لعــرض الفيديو رقم 4 >  /X4
لعــرض الفيديو رقم 5 >  /X5
لعــرض الفيديو رقم 6 >  /X6
لعــرض الفيديو رقم 7 >  /X7
لعــرض الفيديو رقم 8 >  /X8
لعــرض الفيديو رقم 9 >  /X9
لعــرض الفيديو رقم 10 >  /X10
لعــرض الفيديو رقم 11 >  /X11
لعــرض الفيديو رقم 12 >  /X12
لعــرض الفيديو رقم 13 >  /X13
لعــرض الفيديو رقم 14 >  /X14
لعــرض الفيديو رقم 15 >  /X15
لعــرض الفيديو رقم 16 >  /X16
لعــرض الفيديو رقم 17 >  /X17
لعــرض الفيديو رقم 18 >  /X18
لعــرض الفيديو رقم 19 >  /X19
لعــرض الفيديو رقم 20 >  /X20
💛~~~~~~~~~~~~~~~~💛",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X1"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/2",
'caption'=>"ٲحببتك بقـلب ٲم تعـلقـت بطفلها ٲلـوحيد ♥️
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X2"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/3",
'caption'=>"من أراد البقاء فآبسط له قلبك
ومن أراد الرحيل،فآبسط له الطريق💗
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X3"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/4",
'caption'=>"إفهمني كما تُريد,لكن لا تُحملني ذنب سوء فهمك 🖤
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X4"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/5",
'caption'=>"ردتك حبيب قسمه ونصيب واقضي العمر وياك 🖤
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X5"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/6",
'caption'=>"- فقط عانق من يتقبَل عالمك الأَسود  🖤
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X6"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/7",
'caption'=>"أنا لم اتعود على إخبار احدهم بآفعله يؤلمني، 💔
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X7"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/8",
'caption'=>"‏تعشق الأنثى من يُعيدها طفلة مُدلله 🖤،
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X8"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/10",
'caption'=>"هذا ليس أنا هذا ما تبقّى مني 🤍
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X9"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/11",
'caption'=>"ــ خله على بالك تبقى طيري 🕊💚
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X10"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/13",
'caption'=>"لم أحبك بعقل أنا أحبّبتك بجنوُن أهل الأرض 🌻💚
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X11"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/66",
'caption'=>"- كانت جميلة للحد الذي لا حّد لهُ 💛🌩.
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X12"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/70",
'caption'=>"- في حيـأة كُل امرآة يـوجد رجـل وآحـد يُمكنهـا معـه ان تصبـح كامِلـة ♥️🧿💍
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X13"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/74",
'caption'=>"سأكون الأمان الذي لا يتخلئ عنك يومآ💜
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X14"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/76",
'caption'=>"انهُ لخاطر ضَواها كلشّي طفيُت! ❤️
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X15"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/78",
'caption'=>"يا أكثر من كُلش حلوة
لو ردتي تكطعين الوردة
الغصن البيها يگلج فدوة♥️🌿.
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X16"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/80",
'caption'=>"𝑰𝒔 𝒊𝒕 𝒏𝒐𝒕 𝒓𝒊𝒈𝒉𝒕 𝒇𝒐𝒓 𝒕𝒉𝒆 𝒍𝒐𝒗𝒆𝒓 𝒕𝒐 𝒍𝒊𝒗𝒆 𝒊𝒏 𝒕𝒉𝒆 𝒂𝒓𝒎𝒔 𝒐𝒇 𝒉𝒊𝒔 𝒃𝒆𝒍𝒐𝒗𝒆𝒅?...
أليس من حق المحب أن يسكن حضن محبوبه؟...
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X17"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/81",
'caption'=>"- يا نايم ابالــي 😌💗
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X18"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/82",
'caption'=>"- لقد رحل الجميع 🙂🖤
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X19"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/83",
'caption'=>"ࢪقـيـقۿ ڪآنها قطـ؏ـۿ سڪࢪ 💛
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}
if($text == "/X20"){
bot('sendVideo',[
'chat_id'=>$chat_id, 
video =>"https://t.me/KQM11/85",
'caption'=>"لقد سمعتت !
بانهه اصبح لك حبيبه اخرى !؟
Me channel ♥️ - @$abbas",
'reply_to_message_id'=>$message->message_id, 
]);
}


$sudo = 954452897;
$get = explode("\n", file_get_contents('memberbot.txt'));
if($text == '/start' and !in_array($chat_id, $get)){
file_put_contents('memberbot.txt',"\n" . $chat_id, FILE_APPEND);
}
if($text == '/users' and $id == $sudo){
 $count = count($get);
  bot('sendmessage',[
    'chat_id'=>$chat_id,
    'parse_mode'=>'markdown',
    'text'=>"Your Bot Member : $count",
  ]);
  }
$bc = explode("/bc", $text);
if($bc and $id == $sudo){
for($y=0;$y<count($get); $y++){
bot('sendMessage', [
'chat_id'=>$get[$y],
'text'=>"$bc[1]",
'parse_mode'=>markdown,
'disable_web_page_preview'=>true,
]);
}
}



?>

// تخمط اذكر اسمي حبي #كلاوجي
// قناتي @NONBBN
//معرفي @ll8III