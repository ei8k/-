﻿
<?php 
// ملف كتابتي ذا تريد تنشر عيف حقوق
// لتصير فاشل ، 😒
//لــ @TTTITT
//قناة @I2O2I
ob_start();
$API_KEY = '1223278326:AAFyooEKbgpmDc5-dCcCzbvJqT9db_pd13A'; 
define('API_KEY',$API_KEY);
echo "<a href='https://api.telegram.org/bot$API_KEY/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']."'>setwebhook</a>"; 
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);       
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//====================@i2o2i===================//
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$alo = $message->chat->id;
$text = $message->text;
$name = $message->from->first_name;
$message_id = $update->callback_query->message->message_id;
$chat_id = $message->chat->id;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$message_id2 = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$u = explode("\n",file_get_contents("memb.txt"));
$c = count($u)-1;
$modxe = file_get_contents("usr.txt");
$chs = file_get_contents("ch.txt");
$ad = file_get_contents("ids.txt");
$by = file_get_contents("buy.txt");
$buyy = "@$by";
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$message = $update->message;
$username = $message->from->username;
$message_id2 = $update->callback_query->message->message_id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$Name = $update->callback_query->from->first_name;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$text = $message->text;
$useree = $update->callback_query->message->chat->id;
$username = $message->from->username;
$fn = $message->from->first_name;
$user_id = $message->from->id;
$admin = "912331667";
$MROAN = file_get_contents("MROAN.txt");
$MROAN0 = file_get_contents("MROAN0.txt");
$MROAN1= file_get_contents("MROAN1.txt");
$MROAN5 = file_get_contents("MROAN2.txt");
$MROAN6 = file_get_contents("MROAN3.txt");
$MROAN20 = json_decode(file_get_contents('php://input'));
$MROAN18 = $update->message;
$MROAN13 = $MROAN18->chat->id;
$MROAN17 = $MROAN18->text;
$MROAN19 = $MROAN20->callback_query->data;
$MROAN12 = $MROAN20->callback_query->message->chat->id;
$MROAN14 =  $MROAN20->callback_query->message->message_id;
$MROAN15 = $MROAN18->from->first_name;
$MROAN16 = $MROAN18->from->username;
$MROAN11 = $MROAN18->from->id;
$MROAN2 = explode("\n",file_get_contents("MROAN4.txt"));
$MROAN3 = count($MROAN2)-1;
if ($MROAN18 && !in_array($MROAN11, $MROAN2)) {
    file_put_contents("MROAN4.txt", $MROAN11."\n",FILE_APPEND);
  }
$MROAN9 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$MROAN0&user_id=".$MROAN11);
$MROAN10 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$MROAN1&user_id=".$MROAN11);
if($MROAN18 && (strpos($MROAN9,'"status":"left"') or strpos($MROAN9,'"Bad Request: USER_ID_INVALID"') or strpos($MROAN9,'"status":"kicked"') or strpos($MROAN10,'"status":"left"') or strpos($MROAN10,'"Bad Request: USER_ID_INVALID"') or strpos($MROAN10,'"status":"kicked"'))!== false){
bot('sendMessage', [
'chat_id'=>$MROAN13,
'text'=>'- ▫️ عذراً عزيزي  ، 🔰
▪️ يجب عليك الإشتراك في قناة المطور أولاً ⚜️؛

- اشترك ثم ارسل { /start }📛!

'.$MROAN0.'
'.$MROAN1,
]);return false;}
if($MROAN17 == "/admin" and $MROAN11 == $admin){
bot("sendmessage",[
"chat_id"=>$MROAN13,
"text"=>"مرحبآ بك ،  [$fn](tg://user?id=$chat_id)
- هذه لوحة التحكم الخاصة بك ، 🔰
- يمكنك التحكم بجميع اوامر البوت من هنا ، 🐬
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
'reply_to_message_id'=>$message->message_id,
 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- أوامر الإشتراك الإجباري الأول ، 📢' ,'callback_data'=>"MROAN"]],
[['text'=>'• وضع قناة ، 🌚🤞🏻' ,'callback_data'=>"MROAN0"],['text'=>'• حذف قناة ، 🌚🤙🏻' ,'callback_data'=>"delete11"]],
[['text'=>'- أوامر الإشتراك الإجباري الثاني ، 📢' ,'callback_data'=>"MROAN"]],
[['text'=>'• وضع قناة ، 🌝🤞🏻' ,'callback_data'=>"MROAN2"],['text'=>'• حذف قناة ، 🌝🤙🏻' ,'callback_data'=>"delete22"]],
[['text'=>'- عرض قنوات الإشتراك ، 📛' ,'callback_data'=>"MROAN4"]],
[['text'=>'- أوامر الإذاعه ، 🗣' ,'callback_data'=>"MROAN"]],
[['text'=>'• رسالة توجيه ، ☝️🏻💚' ,'callback_data'=>"MROAN5"],['text'=>'• رسالة نصية ، ☝️🏻💛' ,'callback_data'=>"MROAN6"]],
[['text'=>'- عدد المشتركين ، 🐳' ,'callback_data'=>"MROAN7"]],
[['text'=>'- التنبيه عند دخول أحد للبوت ، ⚠️' ,'callback_data'=>"MROAN"]],
[['text'=>'• تفعيل التنبيه ، ✅' ,'callback_data'=>"MROAN9"],['text'=>'• تعطيل التنبيه ، ❎' ,'callback_data'=>"MROAN10"]],
[['text'=>'- توجيه رسائل من الأعضاء ، 🔁' ,'callback_data'=>"MROAN"]],
[['text'=>'• تفعيل التوجيه ، ✅' ,'callback_data'=>"MROAN11"],['text'=>'• تعطيل التوجيه ، ❎' ,'callback_data'=>"MROAN12"]],
   ] 
   ])
]);
}
if($MROAN19 == "MROAN" ){
bot('EditMessageText',[
'chat_id'=>$MROAN12,
'message_id'=>$MROAN14,
"text"=>"  • مرحبا بك ، [$Name](tg://user?id=$chat_id2)
- هذه لوحة التحكم الخاصة بك ، 🔰
- يمكنك التحكم بجميع اوامر البوت من هنا ، 🐬
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- أوامر الإشتراك الإجباري الأول ، 📢' ,'callback_data'=>"MROAN"]],
[['text'=>'• وضع قناة ، 🌚🤞🏻' ,'callback_data'=>"MROAN0"],['text'=>'• حذف قناة ، 🌚🤙🏻' ,'callback_data'=>"delete11"]],
[['text'=>'- أوامر الإشتراك الإجباري الثاني ، 📢' ,'callback_data'=>"MROAN"]],
[['text'=>'• وضع قناة ، 🌝🤞🏻' ,'callback_data'=>"MROAN2"],['text'=>'• حذف قناة ، 🌝🤙🏻' ,'callback_data'=>"delete22"]],
[['text'=>'- عرض قنوات الإشتراك ، 📛' ,'callback_data'=>"MROAN4"]],
[['text'=>'- أوامر الإذاعه ، 🗣' ,'callback_data'=>"MROAN"]],
[['text'=>'• رسالة توجيه ، ☝️🏻💚' ,'callback_data'=>"MROAN5"],['text'=>'• رسالة نصية ، ☝️🏻💛' ,'callback_data'=>"MROAN6"]],
[['text'=>'- عدد المشتركين ، 🐳' ,'callback_data'=>"MROAN7"]],
[['text'=>'- التنبيه عند دخول أحد للبوت ، ⚠️' ,'callback_data'=>"MROAN"]],
[['text'=>'• تفعيل التنبيه ، ✅' ,'callback_data'=>"MROAN9"],['text'=>'• تعطيل التنبيه ، ❎' ,'callback_data'=>"MROAN10"]],
[['text'=>'- توجيه رسائل من الأعضاء ، 🔁' ,'callback_data'=>"MROAN"]],
[['text'=>'• تفعيل التوجيه ، ✅' ,'callback_data'=>"MROAN11"],['text'=>'• تعطيل التوجيه ، ❎' ,'callback_data'=>"MROAN12"]],
   ] 
   ])
]);
unlink("MROAN.txt");
}
if($MROAN19 == "MROAN0"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- حسناً ، الآن قم بإرسال معرف قناتك ليتم وضعه في خدمة الإشتراك الإجباري للقناة الأولى ، 📢
#مثال :
▪️@Watan_e',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN.txt","MROAN0");
}
if($MROAN17 and $MROAN == "MROAN0" and $MROAN11 == $admin){
bot("sendmessage",[
"chat_id"=>$MROAN13,
"text"=>'- لقد تم وضع القناة بنجاح ، 📣
- قم برفع البوت أدمن داخل القناة ، 🗞',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN0.txt","$MROAN17");
unlink("MROAN.txt");
}
if($MROAN19 == "delete11"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- حسناً هل أنت متأكد من أنك تريد حذف القناة من الإشتراك الإجباري ، 🚫
',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'• لا ، ❎', 'callback_data'=>'MROAN'],
['text'=>'• نعم ، ✅','callback_data'=>'MROAN1'],
]    
]])
]);    
}
if($MROAN19 == "MROAN1"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- لقد تم حذف القناة الاولى من الإشتراك الإجباري بنجاح ، 📮',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
️[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
unlink("MROAN0.txt");
}
if($MROAN19 == "MROAN2"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- حسناً ، الآن قم بإرسال معرف قناتك ليتم وضعه في خدمة الإشتراك الإجباري للقناة الثانية ، 📢
#مثال :
▪️@Watan_e',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN.txt","MROAN1");
}
if($MROAN17 and $MROAN == "MROAN1" and $MROAN11 == $admin){
bot("sendmessage",[
"chat_id"=>$MROAN13,
"text"=>'- لقد تم وضع القناة بنجاح ، 📣
- قم برفع البوت أدمن داخل القناة ، 🗞',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN1.txt","$MROAN17");
unlink("MROAN.txt");
}
if($MROAN19 == "delete22"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- حسناً هل أنت متأكد من أنك تريد حذف القناة من الإشتراك الإجباري ، 🚫',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'• لا ، ❎', 'callback_data'=>'MROAN'],
['text'=>'• نعم ، ✅','callback_data'=>'MROAN3'],
]    
]])
]);    
}
if($MROAN19 == "MROAN3"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- لقد تم حذف القناة الثانية من الإشتراك الإجباري بنجاح ، 📮',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
unlink("MROAN1.txt");
}
if($MROAN19 == "MROAN4"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>"- هذه قائمة القنوات الأشتراك الاجباري ، 🔰
- القناة الاولى ،  $MROAN0 📢 
- القناة الثانية ،  $MROAN1 📣
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
}
if($MROAN19 == "MROAN5"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>"~ أرسل رسالتك وسيتم توجيهها لـ [ $MROAN3 ] مشترك ، 🐙 ",
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN.txt","MROAN2");
}
if($MROAN18 and $MROAN == "MROAN2" and $MROAN11 == $admin){
bot("sendmessage",[
"chat_id"=>$MROAN13,
"text"=>'- تم التوجيه بنجاح 🦕',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
for($i=0;$i<count($MROAN2); $i++){
bot('forwardMessage', [
'chat_id'=>$MROAN2[$i],
'from_chat_id'=>$MROAN11,
'message_id'=>$MROAN18->message_id
]);
unlink("MROAN.txt");
}
}
if($MROAN19 == "MROAN6"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>"~ أرسل رسالتك وسيتم إرسالها لـ [ $MROAN3 ] مشترك ، 🐠",
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN.txt","MROAN3");
}
if($MROAN17 and $MROAN == "MROAN3" and $MROAN11 == $admin){
bot("sendmessage",[
"chat_id"=>$MROAN13,
"text"=>'- تم النشر بنجاح 🐋',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
for($i=0;$i<count($MROAN2); $i++){
bot('sendMessage', [
'chat_id'=>$MROAN2[$i],
'text'=>$MROAN17
]);
unlink("MROAN.txt");
}
}
if($MROAN19 == "MROAN7"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>"- عدد مشتركين البوت  [ $MROAN3 ] مشترك ، 🦑",
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
}
if($MROAN19 == "MROAN9"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- تم تفعيل دخول المشتركين ، 🐎',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN2.txt","MROAN");
}
if($MROAN17 == "/start" and $MROAN5 == "MROAN" and $MROAN11 != $admin){
bot("sendmessage",[
"chat_id"=>$admin,
"text"=>"- عضو جديد قام بالدخول الى البوت ، 🛡
- الاسم ، [$MROAN15](tg://user?id=$chat_id) ، 🦕
- المعرف ، [@$MROAN16](tg://user?id=$chat_id) ، 🐢
- الايدي ، [$MROAN11](tg://user?id=$chat_id) ، 🐝 
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
~  عدد المشتركين ، { $MROAN3 } ، 🦑 ",
 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
]);
}
if($MROAN19 == "MROAN10"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- تم تعطيل دخول المشتركين ، 🦍 ',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
unlink("MROAN2.txt");
}
if($MROAN19 == "MROAN11"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- تم تفعيل توجيه الرسائل ، 🦇',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN3.txt","MROAN");
}
if($MROAN18 and $MROAN6 == "MROAN" and $MROAN11 != $admin){
bot('forwardMessage', [
'chat_id'=>$admin,
'from_chat_id'=>$MROAN11,
'message_id'=>$MROAN18->message_id
]);
}
if($MROAN18 and $MROAN6 == "MROAN" and $MROAN11 == $admin){
bot('sendMessage',[
'chat_id'=>$MROAN18->reply_to_message->forward_from->id,
    'text'=>$MROAN17,
    ]);
}
if($MROAN19 == "MROAN12"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- تم تعطيل توجيه الرسائل ، 🐌',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
unlink("MROAN3.txt");
}


//====================@i2o2i===================//
//لــ ستارت
if($text == '/start'){ 
bot('sendMessage', [
'chat_id'=>$alo,
'text'=>"• اهــلا بك عزيزي💛  [$name](tg://user?id=$id) 
في بوت العاب الاول عله تليجرام ، 🔋
البوت في 3 العاب متميزة وجميله ، 🌜
يمكنك لعب و ستمتاع يحتوي عله العاب تاليه ، ⭐️
1 ~ معاني ، ♥️
2 ~ الاسرع ، 💛
3 ~ ترتيب ، ♥️",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'معاني ، 🌛','callback_data'=>'ab'],['text'=>'الاسرع ، ⛅️','callback_data'=>'aa']], 
[['text'=>'ترتيب ، ⭐️','callback_data'=>'ak']], 
[['text'=>'لشراء بوت مماثل  ” 🥤️', 'url'=>'https://t.me/EzZzZz '],['text'=>'قناة البوت ” 🥤️', 'url'=>'t.me/RRRRYR']],]])]);}
if($data == 'l2'){
  bot('EditMessageText',[
    'chat_id'=>$chat_id2,
    'message_id'=>$message_id,
    'text'=>"اهلا بك عزيزي ، 💛
 في بوت العاب الاول عله تليجرام ، 🔋
البوت في 3 العاب متميزة وجميله ، 🌜
يمكنك لعب و ستمتاع يحتوي عله العاب تاليه ، ⭐️
1 ~ معاني ، ♥️
2 ~ الاسرع ، 💛
3 ~ ترتيب ، ♥️",
    'reply_markup'=>json_encode([
      'inline_keyboard'=>[
        [['text'=>'معاني ، 🌛','callback_data'=>'ab'],['text'=>'الاسرع ، ⛅️','callback_data'=>'aa']], 
[['text'=>'ترتيب ، ⭐️','callback_data'=>'ak']], 
[['text'=>'لشراء بوت مماثل  ” 🥤️', 'url'=>'https://t.me/EzZzZz '],['text'=>'قناة البوت ” 🥤️', 'url'=>'https://t.me/RRRRYR']],]])]);}
if($data == 'ab'){
  bot('EditMessageText',[
    'chat_id'=>$chat_id2,
    'message_id'=>$message_id,
    'text'=>"لقد اخترته قسم العاب معاني ، ♥️
    حسننا عزيزي انتبه لستخراج! ⚒️
    لعبه ارسل كلمه { معاني} او { معنة } وستمتع ، 💛",
    'reply_markup'=>json_encode([
      'inline_keyboard'=>[
      [['text'=>'رجوع ، 💚','callback_data'=>'l2']],]])]);}
      if($data == 'aa'){
  bot('EditMessageText',[
    'chat_id'=>$chat_id2,
    'message_id'=>$message_id,
    'text'=>"لقد اخترته قسم العاب الاسرع ، ♥️
    حسننا عزيزي انتبه لستخراج! ⚒️
    لعبه ارسل كلمه { الاسرع } او { اسرع } وستمتع ، 💙",
    'reply_markup'=>json_encode([
      'inline_keyboard'=>[
      [['text'=>'رجوع ، 💚','callback_data'=>'l2']],]])]);}
      if($data == 'ak'){
  bot('EditMessageText',[
    'chat_id'=>$chat_id2,
    'message_id'=>$message_id,
    'text'=>"لقد اخترته قسم العاب ترتيب ، ♥️
    حسننا عزيزي انتبه لستخراج! ⚒️
    لعبه ارسل كلمه { عبارة } او { ترتيب } وستمتع ، 💜",
    'reply_markup'=>json_encode([
      'inline_keyboard'=>[
      [['text'=>'رجوع ، 💚','callback_data'=>'l2']],]])]);}
      //====================@i2o2i===================//
//ترتيب
$ali = array(' العبارة ، 🌛 :- [ ل س ا ق ت ب ا ] '
,' العبارة ، 🌜 :- [ ه ا ر س ي ]'
,'العبارة ، 🌛 :- [ ر و ح س ]'
,'العبارة ، 🌜 :- [ ن ف ه ق ]'
,'العبارة ، 🌛 :- [ و ن ي ا ف  ]'
,'العبارة ، 🌜 :- [  ن و ه ب ز  ]'
,'العبارة ، 🌛 : [ر ك و س ت ن ا ي ]'
,'العبارة ، 🌜:- [ ا ع ل ق ا ر ]'
,'العبارة ، 🌛 :- [ و هـ ك ه ]'
,'العبارة ، 🌜- [ ف ي س ه ن ]'
,'العبارة ، 🌛 :- [ ج ا د ج  ه ]'
,' العبارة ، 🌜 - [ س م ر د ه ]'
,'العبارة ، 🌛 :- [ ا ن ا و ل ]'
,'العبارة ، 🌜 :- [ ه غ ف ر ]'
,' العبارة ، 🌛 :- [ ج ه ث ل ا ]'
,' العبارة ، 🌜 :- [ خ م ب ط ]'
,'العبارة ، 🌛 : [ ع ا ل ي و ]'
,'العبارة ، 🌜 [ ك ا م ل ]'
,'العبارة ، 🌛 [ ح ا و ي ن ]'
,'العبارة ، 🌜 : [ ا د س ]'
,'العبارة ، 🌛 : [ ل ب ك ]'
,'العبارة ، 🌜 : [ ف ش ة ]'
);
$tttitt = array_rand($ali, 1);
if($text =="ترتيب" or $text =="عبارة"or $text =="كلمه"or $text =="عباره"){
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$ali[$tttitt],
'reply_to_message_id'=>$message->message_id
]);
}
// ملف كتابتي ذا تريد تنشر عيف حقوق
// لتصير فاشل ، 😒
//لــ @TTTITT
//قناة @I2O2I
if($text == 'سحور' or $text == 'سياره' or $text == 'شفة' or $text == 'كلب' or $text == 'اسد' or $text == 'حيوان' or $text == 'علاوي' or $text == 'كلام'  or $text == 'استقبال'  or $text == 'قنفه'  or $text == 'ايفون'  or $text == 'بزونه' or  $text == 'مطبخ' or $text == 'كرستيانو' or $text == 'دجاجه' or $text == 'مدرسه' or $text == 'الوان' or $text == 'غرفه' or $text == 'ثلاجه' or $text == 'كهوه' or $text == 'سفينه' or $text == 'العراق'){
$alaw = array('هاذي اجابه صح ، ♥️
ارسل كلمه { ترتيب }',
'اجابتك صحيحة ، 💛
ارسل كلمه { ترتيب}',
'جوابك صح ، 😍
ارسل كلمه { ترتيب }',
'جوابك صح صح صح ، ⭐️
اارسل كلمه { ترتيب }',);
$php = array_rand($alaw, 1);
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$alaw[$php],
'reply_to_message_id'=>$message->message_id
]);
}
//====================@i2o2i===================//
//الاسرع
$alis = array('اسرع واحد يدز { 😜 }'
,'اسرع واحد يدز { 🏦 }'
,'اسرع واحد يدز { 🏥 }'
,'اسرع واحد يدز { 🐢 }'
,'اسرع واحد يدز { 🐀 }'
,'اسرع واحد يدز { 🐁 }'
,'اسرع واحد يدز { 🐱 }'
,'اسرع واحد يدز { 🐩 }'
,'اسرع واحد يدز { 😨 }'
,'اسرع واحد يدز { 😴 }'
,'اسرع واحد يدز { 🔧 }'
,'اسرع واحد يدز { 🏇 }'
,'اسرع واحد يدز { 🗼 }'
,'اسرع واحد يدز { 🔨 }'
,'اسرع واحد يدز { 🎈 }'
,'اسرع واحد يدز { 🔛 }'
,'اسرع واحد يدز { ⏳ }'
,'اسرع واحد يدز { 🚰 }'
,'اسرع واحد يدز { ⛎ }'
,'اسرع واحد يدز { 💮 }'
,'اسرع واحد يدز { ➿ }'
,'اسرع واحد يدز { 🗿 }'
,'اسرع واحد يدز { 💙 }'
,'اسرع واحد يدز { 🍖 }'
,'اسرع واحد يدز { 🍕 }'
,'اسرع واحد يدز { 🍟 }'
,'اسرع واحد يدز { 🍄 }'
,'اسرع واحد يدز { 🌜 }'
,'اسرع واحد يدز { 🌛 }'
,'اسرع واحد يدز { 🌎 }'
,'اسرع واحد يدز { 💧 }'
,'اسرع واحد يدز { ⚡ }'
);
$tttit = array_rand($alis, 1);
if($text =="الاسرع" or $text =="الٲسرع"or $text =="اسرع"or $text =="سرعه"){
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$alis[$tttit],
'reply_to_message_id'=>$message->message_id
]);
}
//====================@i2o2i===================//
if($text == '😈'or $text == '😜' or $text == '🐩' or $text == '🐱' or $text == '🐁' or $text == '🐀' or $text == '🐢' or $text == '🏥' or $text == '🏦'  or $text == '😨'  or $text == '😴'  or $text == '🔧'  or $text == '🏇' or  $text == '🗼' or $text == '🔨' or $text == '🎈' or $text == '🔛' or $text == '⏳' or $text == '🚰' or $text == '⛎' or $text == '💮' or $text == '➿' or $text == '🗿' or $text == '🍖' or $text == '💙' or $text == '🍕' or $text == '🍟' or $text == '🍄' or $text == '🌜' or $text == '🌛' or $text == '🌎' or $text == '💧' or $text == '⚡'){
$alawi = array('حسننا عزيزي انته الاسرع، ♥️
ارسل كلمه { الاسرع }',
'لقد فزت انت الاسرع  ، 💛
ارسل كلمه { الاسرع }',
' شهل سرعه لك ، 😍
ارسل كلمه { الاسرع }',
'جوابك صح صح صح ، ⭐️
اارسل كلمه { الاسرع }',);
$php = array_rand($alawi, 1);
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$alawi[$php],
'reply_to_message_id'=>$message->message_id
]);
}
//معاني
$alit = array('اسرع واحد يدز { 😜 }'
,'ما اسم هاذ الشئ :- ~ 🚀 ~'
,'ما اسم هاذ الشئ :- ~ ⚽ ~'
,'ما اسم هاذ الشئ :- ~ ?? ~'
,'ما اسم هاذ الشئ :- ~ 📙 ~'
,'ما اسم هاذ الشئ :- ~ ⌚ ~'
,'ما اسم هاذ الشئ :- ~ 🗼 ~'
,'ما اسم هاذ الشئ :- ~ 🐍 ~'
,'ما اسم هاذ الشئ :- ~ 🐈 ~'
,'ما اسم هاذ الشئ :- ~ 🐒 ~'
,'ما اسم هاذ الشئ :- ~ 💜 ~'
,'ما اسم هاذ الشئ :- ~ 🐄 ~'
,'ما اسم هاذ الشئ :- ~ 💰 ~'
,'ما اسم هاذ الشئ :- ~ 🚇 ~'
,'ما اسم هاذ الشئ :- ~ 🐇 ~'
,'ما اسم هاذ الشئ :- ~ 🐟 ~'
,'كم يساوي : - 55 - 12 = ？'
,'كم يساوي : -  7 × 4 + 25 = ? '
,'كم يساوي : -  37 × 4 = ？'
,'كم يساوي : - 2 ÷ 40 = ? '
,'كم يساوي : - 32 + 90 = ? '
);
$ttti = array_rand($alit, 1);
if($text =="معاني" or $text =="معانى"or $text =="معأني"or $text =="معنة"){
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$alit[$ttti],
'reply_to_message_id'=>$message->message_id
]);
}
//====================@i2o2i===================//
if($text == 'قمر'or $text == 'حافله' or $text == 'قرد' or $text == 'قط' or $text == 'ثعبان' or $text == 'قطه' or $text == 'برج' or $text == '..' or $text == 'ساعه'  or $text == 'ساعة'  or $text == 'كتاب'  or $text == 'نمله'  or $text == 'نملة' or  $text == 'كره قدم' or $text == 'كرة قدم' or $text == 'صاروخ' or $text == '43' or $text == '122' or $text == '20' or $text == '148' or $text == '47' or $text == 'قلب' or $text == 'بقره' or $text == 'بقرة' or $text == 'مال' or $text == 'قطار' or $text == 'ارنب' or $text == 'سمكه' or $text == 'سمكة'){
$ala = array('حسننا عزيزي انته هاذ معنه صحيح، ♥️
ارسل كلمه { معاني }',
'لقد فزت هاذ معنه صحيح  ، 💛
ارسل كلمه { معاني }',
' شهل ذكاء هاذ معنه,صحيح   ، 😍
ارسل كلمه { معاني }',
'جوابك صح صح صح ، ⭐️
اارسل كلمه { معاني }',);
$php = array_rand($ala, 1);
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$ala[$php],
'reply_to_message_id'=>$message->message_id
]);
}