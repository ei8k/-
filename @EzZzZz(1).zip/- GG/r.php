/*
By ~ @KKYKKN 
Ch ~ @HLOOBOT 
*/
<?php
date_default_timezone_set('Asia/Damascus');
$API_KEY= '1292236609:AAHr68vrNiOxVKA9XouJ5Hq-tVh5nz7eJsQ';
define('API_KEY',$API_KEY);
function bot($method,$datas=[]){
    $yhyanesb = http_build_query($datas);
        $url = "https://api.telegram.org/bot".API_KEY."/".$method."?$yhyanesb";
        $yhyanesb_Sy = file_get_contents($url);
        return json_decode($yhyanesb_Sy);
}
@$update = json_decode(file_get_contents('php://input'));
@$message = $update->message;
@$text = $message->text;
@$chat_id = $message->chat->id;
@$name1 = $message->from->first_name;
@$name2 = $message->from->last_name;
@$username = $message->from->username;
@$from_id = $message->from->id;
@$admin_id = "1010918290"; // your id 
@$admin_user = "EzZzZz"; // your user
@$name = "$name1 $name2";
@$hloobot = "@TeamKeK"; //UserName The Channel
@$Channel = str_replace("@","","$hloobot");
@$BIO = "
- @EzZzZz 💛

- @TheDSTOR 💛
 
- @SZXZS 💛

- @KiNGBrlin 💛

- @eiiiii 💛
";  //BIO The Channel
$h = date('h');
$date = date('Y/n/d');
$time = date('h:i');
$day = date('D');
if($h == '1'){$hour = '🕐';}else if($h == '2'){$hour = '🕑';}else if($h == '3'){$hour = '🕒';}else if($h == '4'){$hour = '🕓';}else if($h == '5'){$hour = '🕔';}else if($h == '6'){$hour = '🕕';}else if($h == '7'){$hour = '🕖';}else if($h == '8'){$hour = '🕗';}else if($h == '9'){$hour = '🕘';}else if($h == '10'){$hour = '🕙';}else if($h == '11'){$hour = '🕚';}else if($h == '12'){$hour = '🕛';}
@$yhya = "📅::$date \n $hour::$time \n $day";
if(true) {
   bot('setChatDescription', [
  'chat_id'=>$hloobot, 
  'description'=>"
  $BIO
  ┄─┅═ـ═┅─
  $yhya
 "
]) ;
}
if($text  !="/start"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
أهلا بك يا $name في بوت وضع الساعة 🕧 والتاريخ 📆 في بايو القناة 🖥️
",
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>"admin 👨‍💻",'url'=>"https://t.me/$admin_user"]],
[['text'=>"Channel 🖥",'url'=>"https://t.me/$Channel"]],
]
])
]);
}
if($text =="/start"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
اهلا بك يا  [$name](https://t.me/$username) في بوت وضع ساعة في بايو القناة 🕒☑
"
]);
}
echo "$yhya
'Channel':'@hloobot'";
?>