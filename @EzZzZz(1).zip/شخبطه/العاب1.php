﻿
<?php 
// ملف كتابتي ذا تريد تنشر عيف حقوق
// لتصير فاشل ، 😒
//لــ @TTTITT
//قناة @I2O2I
ob_start();
$API_KEY = '1201007429:AAEp7XZtTEkCTU3Vuai5Q7VzK7akya4M3eU'; 
define('API_KEY',$API_KEY);
echo "<a href='https://api.telegram.org/bot$API_KEY/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']."'>setwebhook</a>"; 
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);       
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//====================@i2o2i===================//
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$alo = $message->chat->id;
$text = $message->text;
$name = $message->from->first_name;
$message_id = $update->callback_query->message->message_id;
$chat_id = $message->chat->id;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$message_id2 = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$u = explode("\n",file_get_contents("memb.txt"));
$c = count($u)-1;
$modxe = file_get_contents("usr.txt");
$chs = file_get_contents("ch.txt");
$ad = file_get_contents("ids.txt");
$by = file_get_contents("buy.txt");
$chk = "@ThephpBots";       
$buyy = "@$by";
if($text == "/start"){$from_id = $message->from->id;
$join = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$chk&user_id=".$from_id);
if($message && (strpos($join,'"status":"left"') or strpos($join,'"Bad Request: USER_ID_INVALID"') or strpos($join,'"status":"kicked"'))!== false){
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"• عـذراََ ! 🤚🏿
لستخدام البوت عليك اشتراك في قنوات البوت 📡🚸
CH » { $chk }
عند الاشتراك اضغط {/start } مرة اخرة",
]);return false;}
bot('sendMessage',['chat_id'=>$chat_id, 'text'=>"",'reply_to_message_id'=>$message->$message_id,]);}
//====================@i2o2i===================//
//لــ ستارت
if($text == '/start'){ 
bot('sendMessage', [
'chat_id'=>$alo,
'text'=>"• اهــلا بك عزيزي💛  [$name](tg://user?id=$id) 
في بوت العاب الاول عله تليجرام ، 🔋
البوت في 3 العاب متميزة وجميله ، 🌜
يمكنك لعب و ستمتاع يحتوي عله العاب تاليه ، ⭐️
1 ~ معاني ، ♥️
2 ~ الاسرع ، 💛
3 ~ ترتيب ، ♥️",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'معاني ، 🌛','callback_data'=>'ab'],['text'=>'الاسرع ، ⛅️','callback_data'=>'aa']], 
[['text'=>'ترتيب ، ⭐️','callback_data'=>'ak']], 
[['text'=>'لشراء بوت مماثل  ” 🥤️', 'url'=>'https://t.me/EzZzZz '],['text'=>'قناة البوت ” 🥤️', 'url'=>'t.me/thephpbots']],]])]);}
if($data == 'l2'){
  bot('EditMessageText',[
    'chat_id'=>$chat_id2,
    'message_id'=>$message_id,
    'text'=>"اهلا بك عزيزي ، 💛
 في بوت العاب الاول عله تليجرام ، 🔋
البوت في 3 العاب متميزة وجميله ، 🌜
يمكنك لعب و ستمتاع يحتوي عله العاب تاليه ، ⭐️
1 ~ معاني ، ♥️
2 ~ الاسرع ، 💛
3 ~ ترتيب ، ♥️",
    'reply_markup'=>json_encode([
      'inline_keyboard'=>[
        [['text'=>'معاني ، 🌛','callback_data'=>'ab'],['text'=>'الاسرع ، ⛅️','callback_data'=>'aa']], 
[['text'=>'ترتيب ، ⭐️','callback_data'=>'ak']], 
[['text'=>'لشراء بوت مماثل  ” 🥤️', 'url'=>'https://t.me/EzZzZz '],['text'=>'قناة البوت ” 🥤️', 'url'=>'https://t.me/ThePHPBots']],]])]);}
if($data == 'ab'){
  bot('EditMessageText',[
    'chat_id'=>$chat_id2,
    'message_id'=>$message_id,
    'text'=>"لقد اخترته قسم العاب معاني ، ♥️
    حسننا عزيزي انتبه لستخراج! ⚒️
    لعبه ارسل كلمه { معاني} او { معنة } وستمتع ، 💛",
    'reply_markup'=>json_encode([
      'inline_keyboard'=>[
      [['text'=>'رجوع ، 💚','callback_data'=>'l2']],]])]);}
      if($data == 'aa'){
  bot('EditMessageText',[
    'chat_id'=>$chat_id2,
    'message_id'=>$message_id,
    'text'=>"لقد اخترته قسم العاب الاسرع ، ♥️
    حسننا عزيزي انتبه لستخراج! ⚒️
    لعبه ارسل كلمه { الاسرع } او { اسرع } وستمتع ، 💙",
    'reply_markup'=>json_encode([
      'inline_keyboard'=>[
      [['text'=>'رجوع ، 💚','callback_data'=>'l2']],]])]);}
      if($data == 'ak'){
  bot('EditMessageText',[
    'chat_id'=>$chat_id2,
    'message_id'=>$message_id,
    'text'=>"لقد اخترته قسم العاب ترتيب ، ♥️
    حسننا عزيزي انتبه لستخراج! ⚒️
    لعبه ارسل كلمه { عبارة } او { ترتيب } وستمتع ، 💜",
    'reply_markup'=>json_encode([
      'inline_keyboard'=>[
      [['text'=>'رجوع ، 💚','callback_data'=>'l2']],]])]);}
      //====================@i2o2i===================//
//ترتيب
$ali = array(' العبارة ، 🌛 :- [ ل س ا ق ت ب ا ] '
,' العبارة ، 🌜 :- [ ه ا ر س ي ]'
,'العبارة ، 🌛 :- [ ر و ح س ]'
,'العبارة ، 🌜 :- [ ن ف ه ق ]'
,'العبارة ، 🌛 :- [ و ن ي ا ف  ]'
,'العبارة ، 🌜 :- [  ن و ه ب ز  ]'
,'العبارة ، 🌛 : [ر ك و س ت ن ا ي ]'
,'العبارة ، 🌜:- [ ا ع ل ق ا ر ]'
,'العبارة ، 🌛 :- [ و هـ ك ه ]'
,'العبارة ، 🌜- [ ف ي س ه ن ]'
,'العبارة ، 🌛 :- [ ج ا د ج  ه ]'
,' العبارة ، 🌜 - [ س م ر د ه ]'
,'العبارة ، 🌛 :- [ ا ن ا و ل ]'
,'العبارة ، 🌜 :- [ ه غ ف ر ]'
,' العبارة ، 🌛 :- [ ج ه ث ل ا ]'
,' العبارة ، 🌜 :- [ خ م ب ط ]'
,'العبارة ، 🌛 : [ ع ا ل ي و ]'
,'العبارة ، 🌜 [ ك ا م ل ]'
,'العبارة ، 🌛 [ ح ا و ي ن ]'
,'العبارة ، 🌜 : [ ا د س ]'
,'العبارة ، 🌛 : [ ل ب ك ]'
,'العبارة ، 🌜 : [ ف ش ة ]'
);
$tttitt = array_rand($ali, 1);
if($text =="ترتيب" or $text =="عبارة"or $text =="كلمه"or $text =="عباره"){
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$ali[$tttitt],
'reply_to_message_id'=>$message->message_id
]);
}
// ملف كتابتي ذا تريد تنشر عيف حقوق
// لتصير فاشل ، 😒
//لــ @TTTITT
//قناة @I2O2I
if($text == 'سحور' or $text == 'سياره' or $text == 'شفة' or $text == 'كلب' or $text == 'اسد' or $text == 'حيوان' or $text == 'علاوي' or $text == 'كلام'  or $text == 'استقبال'  or $text == 'قنفه'  or $text == 'ايفون'  or $text == 'بزونه' or  $text == 'مطبخ' or $text == 'كرستيانو' or $text == 'دجاجه' or $text == 'مدرسه' or $text == 'الوان' or $text == 'غرفه' or $text == 'ثلاجه' or $text == 'كهوه' or $text == 'سفينه' or $text == 'العراق'){
$alaw = array('هاذي اجابه صح ، ♥️
ارسل كلمه { ترتيب }',
'اجابتك صحيحة ، 💛
ارسل كلمه { ترتيب}',
'جوابك صح ، 😍
ارسل كلمه { ترتيب }',
'جوابك صح صح صح ، ⭐️
اارسل كلمه { ترتيب }',);
$php = array_rand($alaw, 1);
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$alaw[$php],
'reply_to_message_id'=>$message->message_id
]);
}
//====================@i2o2i===================//
//الاسرع
$alis = array('اسرع واحد يدز { 😜 }'
,'اسرع واحد يدز { 🏦 }'
,'اسرع واحد يدز { 🏥 }'
,'اسرع واحد يدز { 🐢 }'
,'اسرع واحد يدز { 🐀 }'
,'اسرع واحد يدز { 🐁 }'
,'اسرع واحد يدز { 🐱 }'
,'اسرع واحد يدز { 🐩 }'
,'اسرع واحد يدز { 😨 }'
,'اسرع واحد يدز { 😴 }'
,'اسرع واحد يدز { 🔧 }'
,'اسرع واحد يدز { 🏇 }'
,'اسرع واحد يدز { 🗼 }'
,'اسرع واحد يدز { 🔨 }'
,'اسرع واحد يدز { 🎈 }'
,'اسرع واحد يدز { 🔛 }'
,'اسرع واحد يدز { ⏳ }'
,'اسرع واحد يدز { 🚰 }'
,'اسرع واحد يدز { ⛎ }'
,'اسرع واحد يدز { 💮 }'
,'اسرع واحد يدز { ➿ }'
,'اسرع واحد يدز { 🗿 }'
,'اسرع واحد يدز { 💙 }'
,'اسرع واحد يدز { 🍖 }'
,'اسرع واحد يدز { 🍕 }'
,'اسرع واحد يدز { 🍟 }'
,'اسرع واحد يدز { 🍄 }'
,'اسرع واحد يدز { 🌜 }'
,'اسرع واحد يدز { 🌛 }'
,'اسرع واحد يدز { 🌎 }'
,'اسرع واحد يدز { 💧 }'
,'اسرع واحد يدز { ⚡ }'
);
$tttit = array_rand($alis, 1);
if($text =="الاسرع" or $text =="الٲسرع"or $text =="اسرع"or $text =="سرعه"){
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$alis[$tttit],
'reply_to_message_id'=>$message->message_id
]);
}
//====================@i2o2i===================//
if($text == '😈'or $text == '😜' or $text == '🐩' or $text == '🐱' or $text == '🐁' or $text == '🐀' or $text == '🐢' or $text == '🏥' or $text == '🏦'  or $text == '😨'  or $text == '😴'  or $text == '🔧'  or $text == '🏇' or  $text == '🗼' or $text == '🔨' or $text == '🎈' or $text == '🔛' or $text == '⏳' or $text == '🚰' or $text == '⛎' or $text == '💮' or $text == '➿' or $text == '🗿' or $text == '🍖' or $text == '💙' or $text == '🍕' or $text == '🍟' or $text == '🍄' or $text == '🌜' or $text == '🌛' or $text == '🌎' or $text == '💧' or $text == '⚡'){
$alawi = array('حسننا عزيزي انته الاسرع، ♥️
ارسل كلمه { الاسرع }',
'لقد فزت انت الاسرع  ، 💛
ارسل كلمه { الاسرع }',
' شهل سرعه لك ، 😍
ارسل كلمه { الاسرع }',
'جوابك صح صح صح ، ⭐️
اارسل كلمه { الاسرع }',);
$php = array_rand($alawi, 1);
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$alawi[$php],
'reply_to_message_id'=>$message->message_id
]);
}
//معاني
$alit = array('اسرع واحد يدز { 😜 }'
,'ما اسم هاذ الشئ :- ~ 🚀 ~'
,'ما اسم هاذ الشئ :- ~ ⚽ ~'
,'ما اسم هاذ الشئ :- ~ ?? ~'
,'ما اسم هاذ الشئ :- ~ 📙 ~'
,'ما اسم هاذ الشئ :- ~ ⌚ ~'
,'ما اسم هاذ الشئ :- ~ 🗼 ~'
,'ما اسم هاذ الشئ :- ~ 🐍 ~'
,'ما اسم هاذ الشئ :- ~ 🐈 ~'
,'ما اسم هاذ الشئ :- ~ 🐒 ~'
,'ما اسم هاذ الشئ :- ~ 💜 ~'
,'ما اسم هاذ الشئ :- ~ 🐄 ~'
,'ما اسم هاذ الشئ :- ~ 💰 ~'
,'ما اسم هاذ الشئ :- ~ 🚇 ~'
,'ما اسم هاذ الشئ :- ~ 🐇 ~'
,'ما اسم هاذ الشئ :- ~ 🐟 ~'
,'كم يساوي : - 55 - 12 = ？'
,'كم يساوي : -  7 × 4 + 25 = ? '
,'كم يساوي : -  37 × 4 = ？'
,'كم يساوي : - 2 ÷ 40 = ? '
,'كم يساوي : - 32 + 90 = ? '
);
$ttti = array_rand($alit, 1);
if($text =="معاني" or $text =="معانى"or $text =="معأني"or $text =="معنة"){
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$alit[$ttti],
'reply_to_message_id'=>$message->message_id
]);
}
//====================@i2o2i===================//
if($text == 'قمر'or $text == 'حافله' or $text == 'قرد' or $text == 'قط' or $text == 'ثعبان' or $text == 'قطه' or $text == 'برج' or $text == '..' or $text == 'ساعه'  or $text == 'ساعة'  or $text == 'كتاب'  or $text == 'نمله'  or $text == 'نملة' or  $text == 'كره قدم' or $text == 'كرة قدم' or $text == 'صاروخ' or $text == '43' or $text == '122' or $text == '20' or $text == '148' or $text == '47' or $text == 'قلب' or $text == 'بقره' or $text == 'بقرة' or $text == 'مال' or $text == 'قطار' or $text == 'ارنب' or $text == 'سمكه' or $text == 'سمكة'){
$ala = array('حسننا عزيزي انته هاذ معنه صحيح، ♥️
ارسل كلمه { معاني }',
'لقد فزت هاذ معنه صحيح  ، 💛
ارسل كلمه { معاني }',
' شهل ذكاء هاذ معنه,صحيح   ، 😍
ارسل كلمه { معاني }',
'جوابك صح صح صح ، ⭐️
اارسل كلمه { معاني }',);
$php = array_rand($ala, 1);
bot('sendMessage',[
'chat_id'=>$alo,
'text'=>$ala[$php],
'reply_to_message_id'=>$message->message_id
]);
}
//====================@i2o2i===================//
$MASTAFAFILES = 1010918290; //ايديك;
if($text == '/admin' and $chat_id == $MASTAFAFILES){ 
bot('sendMessage',[ 
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'chat_id'=>$chat_id, 
'text'=>' أهلا بك عزيزي المدير
في قائمة الأوامر الخاصة بك؛
إضغط على أحد الأوامر لتنفيذه الآن',
'reply_markup'=>json_encode([ 
'keyboard'=>[ 
[
['text'=>'❖￤نشر عام 📢'],['text'=>'❖￤نشر توجيه 🔁']
],
[
['text'=>'❖￤نشر ماركدوان 📣']
],
[ 
['text'=>'❖￤عدد البوتات 🤖'],['text'=>'❖￤المشتركين 👥']
],
[
['text'=>'❖￤الأحصائيات 📊']
],
] 
]) 
]); 
}
 //====================@i2o2i===================//
$MASTAFAFILES = 1010918290; 
$MA3TAFA = explode("\n",file_get_contents("MASTAFA.txt"));
$MASTAFA = count($MA3TAFA)-1;
$MASTAFA_DEV = file_get_contents("MASTAFA_DEV.txt");
if ($update && !in_array($chat_id, $MA3TAFA)) {
file_put_contents("MASTAFA.txt", $chat_id."\n",FILE_APPEND);
}
if($text == "❖￤المشتركين 👥" and $chat_id == $MASTAFAFILES){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤عدد مشتركين بوتك سيدي المطور هو { $MASTAFA } مشترك ؛ 👥"
]);
}

 //====================@i2o2i===================//
$count = count(scandir('botss')) - 2;
if($text == "❖￤عدد البوتات 🤖" and $chat_id == $MASTAFAFILES){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤عدد البوتات المصنوعة سيدي المطور هو { $count$botss} بوت ؛ 👥"
]);
}
if($text == "❖￤الأحصائيات 📊" and $chat_id == $MASTAFAFILES){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤اليك الاحصائيات 📈
📍¦ عدد البوتات المصنوعة { $count$botss} بوت ؛ 🤖
📍¦ عدد المشتركين هو { $MASTAFA }"
]);
}
 //====================@i2o2i===================//
if($text == "❖￤نشر عام 📢" and $chat_id == $MASTAFAFILES){
file_put_contents("MASTAFA_DEV.txt", "MASTAFA");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤ارسل رسالتك الان سيدي المطور وسيتم ارسالها الى { $MASTAFA } مشترك ؛ 📬"
]);
}
 //====================@i2o2i===================//
if($text != "❖￤نشر عام 📢" and $MASTAFA_DEV == "MASTAFA" and $chat_id == $MASTAFAFILES){
for ($i=0; $i < count($MA3TAFA); $i++) { 
bot('sendMessage',[
'chat_id'=>$MA3TAFA[$i],
'text'=>$text,
]);
}
unlink("MASTAFA_DEV.txt");
}
 //====================@i2o2i===================//
if($text == "❖￤نشر ماركدوان 📣" and $chat_id == $MASTAFAFILES){
file_put_contents("MASTAFA_DEV.txt", "MASTAFA1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤ارسل رسالتك الان سيدي المطور وسيتم ارسالها الى { $MASTAFA } مشترك ؛ 📬"
]);
}
 //====================@i2o2i===================//
if($text != "❖￤نشر ماركدوان 📣" and $MASTAFA_DEV == "MASTAFA1" and $chat_id == $MASTAFAFILES){
for ($i=0; $i < count($MA3TAFA); $i++) { 
bot('sendMessage',[
'chat_id'=>$MA3TAFA[$i],
'text'=>$text,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);
}
unlink("MASTAFA_DEV.txt");
}
$from = $message->from->id;
$message_id = $update->message->id;
$chat_id = $message->chat->id;
if($text == "❖￤نشر توجيه 🔁" and $chat_id == $MASTAFAFILES){
file_put_contents("MASTAFA_DEV.txt", "MASTAFA2");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤ارسل رسالتك الان سيدي المطور وسيتم ارسالها الى { $MASTAFA } مشترك ؛ 📬",]);}
 //====================@i2o2i===================//
if($text != "❖￤نشر توجيه 🔁" and $MASTAFA_DEV == "MASTAFA2" and $chat_id == $MASTAFAFILES){
for($i=0;$i<count($MA3TAFA); $i++){
bot('forwardMessage', [
'chat_id' => $MA3TAFA[$i],
'from_chat_id'=>$from,
'message_id'=>$message->message_id
]);
}
unlink("MASTAFA_DEV.txt");
}
// ملف كتابتي ذا تريد تنشر عيف حقوق
// لتصير فاشل ، 😒
//لــ @TTTITT
//قناة @I2O2I