// ملف بوت تمويل ناروكي ؛💡//
//فكره الملف يزيد اعضاء القنوات وقناتك//



<?php
ob_start();
define('API_KEY','964180069:AAHtSnN9YDQmydptcLnM4GK2pGlXtLsEryE');
echo "https://api.telegram.org/bot/naroky";
//فاكشن //
function php88 ($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

$Dev = array("00","1010918290","000");
$usernamebot = "EAZzbot";
$channel = "ThephpBots";
$admin = 1010918290;
$channelcode = "-1001406798442"; // ايدي القناة الي ترسل بيها لهدايا
$token = API_KEY;
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$textmassage = $message->text;
$firstname = $update->callback_query->from->first_name;
$usernames = $update->callback_query->from->username;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$name = $update->message->from->first_name;
$membercall = $update->callback_query->id;

$data = $update->callback_query->data;
$messageid = $update->callback_query->message->message_id;
$tc = $update->message->chat->type;
$gpname = $update->callback_query->message->chat->title;
$forward_from = $update->message->forward_from;
$forward_from_id = $forward_from->id;
$forward_from_username = $forward_from->username;
$forward_from_first_name = $forward_from->first_name;
$reply = $update->message->reply_to_message->forward_from->id;
$reply_username = $update->message->reply_to_message->forward_from->username;
$reply_first = $update->message->reply_to_message->forward_from->first_name;

$forchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@".$channel."&user_id=".$from_id));
$tch = $forchannel->result->status;
$forchannelq = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@".$channel."&user_id=".$fromid));
$tchq = $forchannelq->result->status;

function SendMessage($chat_id, $text){
php88 ('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$text,
'parse_mode'=>'MarkDown']);
}
 function Forward($berekoja,$azchejaei,$kodompayam)
{
php88 ('ForwardMessage',[
'chat_id'=>$berekoja,
'from_chat_id'=>$azchejaei,
'message_id'=>$kodompayam
]);
}
function  getUserProfilePhotos($token,$from_id) {
  $url = 'https://api.telegram.org/bot'.$token.'/getUserProfilePhotos?user_id='.$from_id;
  $result = file_get_contents($url);
  $result = json_decode ($result);
  $result = $result->result;
  return $result;
}
function getChatMembersCount($chat_id,$token) {
  $url = 'https://api.telegram.org/bot'.$token.'/getChatMembersCount?chat_id=@'.$chat_id;
  $result = file_get_contents($url);
  $result = json_decode ($result);
  $result = $result->result;
  return $result;
}
function getChatstats($chat_id,$token) {
  $url = 'https://api.telegram.org/bot'.$token.'/getChatAdministrators?chat_id=@'.$chat_id;
  $result = file_get_contents($url);
  $result = json_decode ($result);
  $result = $result->ok;
  return $result;
}

@$user = json_decode(file_get_contents("data/user.json"),true);
@$juser = json_decode(file_get_contents("data/$from_id.json"),true);
@$cuser = json_decode(file_get_contents("data/$fromid.json"),true);

if(!in_array($from_id, $user["userlist"]) == true) {
$user["userlist"][]="$from_id";
$user = json_encode($user,true);
file_put_contents("data/user.json",$user);
    }

if(in_array($from_id, $user["blocklist"])) {
php88 ('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"- انت محظور من البوت ياعزيزي ، ⚖ !
- بسبب عدم اتباعك قوانين البوت ؛ لا تقم بارسال الرسائل مرة اخرى ، 🔱
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
'reply_markup'=>json_encode(['KeyboardRemove'=>[
],'remove_keyboard'=>true
])
    		]);
}
if($textmassage=="/start" && $tc == "private"){	
if(in_array($from_id, $user["userlist"]) == true) {
php88 ('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"اهلا بك يا : [$name](tg://user?id=$chat_id) 💰
اجمع النقاط واستبدلها بلأعضاء 😌🌸
🆔 : #$from_id",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
   [['text'=>"جمع نقاط 💰",'callback_data'=>'takecoin'],['text'=>"طلب اعضاء 👤",'callback_data'=>'takemember']],
      [['text'=>"قنواتي 💡",'callback_data'=>'order'],['text'=>"شرح البوت ⁉️",'callback_data'=>'m1']],
      [['text'=>"طلباتي 🛎",'callback_data'=>'m5'],['text'=>"تحويل النقاط 📤",'callback_data'=>'sendcoin']],
      [['text'=>"احصائيات الرابط والنقاط 💸",'callback_data'=>'a8']],
  	],
	  	'resize_keyboard'=>true,
  	])
  	]);
$juser["userfild"]["$from_id"]["file"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
}
else
{
php88 ('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"اهلا بك يا : [$name](tg://user?id=$chat_id) 💰
اجمع النقاط واستبدلها بلأعضاء 😌🌸
🆔 : #$from_id",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
   [['text'=>"جمع نقاط 💰",'callback_data'=>'takecoin'],['text'=>"طلب اعضاء 👤",'callback_data'=>'takemember']],
      [['text'=>"قنواتي 💡",'callback_data'=>'order'],['text'=>"شرح البوت ⁉️",'callback_data'=>'m1']],
      [['text'=>"طلباتي 🛎",'callback_data'=>'m5'],['text'=>"تحويل النقاط 📤",'callback_data'=>'sendcoin']],
      [['text'=>"احصائيات الرابط والنقاط 💸",'callback_data'=>'a8']],
  	],
	  	'resize_keyboard'=>true,
  	])
  	]);
$juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["userfild"]["$from_id"]["invite"]="0";
$juser["userfild"]["$from_id"]["coin"]="0";
$juser["userfild"]["$from_id"]["setchannel"]="لا يوجد !";
$juser["userfild"]["$from_id"]["setmember"]="لا يوجد !";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
elseif(strpos($textmassage , '/start ') !== false  ) {
$start = str_replace("/start ","",$textmassage);
if(in_array($from_id, $user["userlist"])) {
php88 ('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"لا يمكنك الدخول الى الرابط الخاص بك 😉 
قم بمشاركتة مع الاصدقاء للحصول ع نقودك 📥

عدد نقود دخول الرابط هية » 5 نقاط",
	   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
   [['text'=>"جمع نقاط 💰",'callback_data'=>'takecoin'],['text'=>"طلب اعضاء 👤",'callback_data'=>'takemember']],
      [['text'=>"قنواتي 💡",'callback_data'=>'order'],['text'=>"شرح البوت ⁉️",'callback_data'=>'m1']],
      [['text'=>"طلباتي 🛎",'callback_data'=>'m5'],['text'=>"تحويل النقاط 📤",'callback_data'=>'sendcoin']],
      [['text'=>"احصائيات الرابط والنقاط 💸",'callback_data'=>'a8']],
  	],
	  	'resize_keyboard'=>true,
  	])
  	]);	
}
else 
{
$juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$inuser = json_decode(file_get_contents("data/$start.json"),true);
$member = $inuser["userfild"]["$start"]["invite"];
$coin = $inuser["userfild"]["$start"]["coin"];
$memberplus = $member + 1;
$coinplus = $coin  + 5;
	php88 ('sendmessage',[
	'chat_id'=>$start,
	'text'=>"تم دخول عضو من خلال رابطك الخاص 😃

عدد الاعضاء الذي استخدمو رابطك » $memberplus
عدد النقاط الخاصة بك » $coinplus",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
 php88 ('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"اهلا بك يا : [$name](tg://user?id=$chat_id) 💰
اجمع النقاط واستبدلها بلأعضاء 😌🌸
🆔 : #$from_id",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
   [['text'=>"جمع نقاط 💰",'callback_data'=>'takecoin'],['text'=>"طلب اعضاء 👤",'callback_data'=>'takemember']],
      [['text'=>"قنواتي 💡",'callback_data'=>'order'],['text'=>"شرح البوت ⁉️",'callback_data'=>'m1']],
      [['text'=>"طلباتي 🛎",'callback_data'=>'m5'],['text'=>"تحويل النقاط 📤",'callback_data'=>'sendcoin']],
      [['text'=>"احصائيات الرابط والنقاط 💸",'callback_data'=>'a8']],
  	],
	  	'resize_keyboard'=>true,
  	])
  	]);	
$inuser["userfild"]["$start"]["invite"]="$memberplus";
$inuser["userfild"]["$start"]["coin"]="$coinplus";
$inuser = json_encode($inuser,true);
file_put_contents("data/$start.json",$inuser);
$juser["userfild"]["$from_id"]["invite"]="0";
$juser["userfild"]["$from_id"]["coin"]="0";
$juser["userfild"]["$from_id"]["setchannel"]="لا يوجد !";
$juser["userfild"]["$from_id"]["setmember"]="لا يوجد !";
$juser["userfild"]["$from_id"]["inviter"]="$start";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
}
}
elseif($cuser["userfild"]["$fromid"]["channeljoin"] == true){
$allchannel = $cuser["userfild"]["$fromid"]["channeljoin"];
for($z = 0;$z <= count($allchannel) -1;$z++){
$getchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@".$allchannel[$z]."&user_id=".$fromid));
$okchannel = $getchannel->result->status;
if($okchannel != 'member' && $okchannel != 'creator' && $okchannel != 'administrator'){
break;
}
}
if($allchannel[$z] == true){
     php88 ('answercallbackquery', [
              'callback_query_id' =>$membercall,
            'text' => "- بسبب مغادرة القناة ؛ @$allchannel[$z] ، تم خصم 2 من نقاطك ، ⚠️ .",
            'show_alert' =>false
         ]);
unset($cuser["userfild"]["$fromid"]["channeljoin"][$z]);
$cuser["userfild"]["$fromid"]["channeljoin"]=array_values($cuser["userfild"]["$fromid"]["channeljoin"]);  
$coin = $cuser["userfild"]["$fromid"]["coin"];
$pluscoin = $coin - 2;
$cuser["userfild"]["$fromid"]["coin"]="$pluscoin";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);      
}

if($allchannel[$z] == true){
     php88 ('SendMessage', [
              'chat_id'=>$chatid,
            'text' => "• لقد قمت بمغادرة بعض القنوات وقمت باخذ النقاط مقابل الانضمام ؛ وبسبب ذلك تم خصم 2 من النقاط لكل قناة من القنوات التي قمت بالمغادرة منها ، 🇮🇶
 
• تستطيع اعادة النقاط التي تم خصمها من نقاطك بأعادة الاشتراك في القنوات التي قمت بالمغادرة منها قم بالاشتراك ثم اضغط على تحديث ؛ @$allchannel[$z] ، 🐬 !",
            'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [['text'=>"- تحديث ،  '",'callback_data'=>'takecoin']]
                     ]
               ])
         ]);  
unset($cuser["userfild"]["$fromid"]["channeljoin"][$z]);
$cuser["userfild"]["$fromid"]["channeljoin"]=array_values($cuser["userfild"]["$fromid"]["channeljoin"]);  
$coin = $cuser["userfild"]["$fromid"]["coin"];
$pluscoin = $coin + 2;
$cuser["userfild"]["$fromid"]["coin"]="$pluscoin";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);      
}
}

if($data=="panel"){
	$coin = $cuser["userfild"]["$fromid"]["coin"];
php88 ('editmessagetext',[
        'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"نقاطك : $coin 💰
اجمع النقاط واستبدلها بلأعضاء 😌🌸",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
   [['text'=>"جمع نقاط 💰",'callback_data'=>'takecoin'],['text'=>"طلب اعضاء 👤",'callback_data'=>'takemember']],
      [['text'=>"قنواتي 💡",'callback_data'=>'order'],['text'=>"شرح البوت ⁉️",'callback_data'=>'m1']],
      [['text'=>"طلباتي 🛎",'callback_data'=>'m5'],['text'=>"تحويل النقاط 📤",'callback_data'=>'sendcoin']],
      [['text'=>"احصائيات الرابط والنقاط 💸",'callback_data'=>'a8']],
  	],
	  	'resize_keyboard'=>true,
  	])
  	]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$cuser["userfild"]["$fromid"]["file"]="none";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
elseif($data=="takecoin" ){
$rules = $cuser["userfild"]["$fromid"]["acceptrules"];
$coin = $cuser["userfild"]["$fromid"]["coin"];
if($rules == false){
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"نقاطك : $coin 💰
الأنضمام بلقنوات 2 💰💡
مشـاركـة الـرابـط 5 💰🌀
الهدية اليـومية 10 💰🎁
➖➖➖➖➖➖➖➖➖➖➖➖",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [['text'=>"انضمام بقنوات 💡",'callback_data'=>'takecoin'],['text'=>"مشاركة الرابط Ⓜ️",'callback_data'=>'a5']],
   [['text'=>"شراء نقاط 💰",'url'=>'t.me/EzZzZz'],['text'=>"الهدية اليومية 🎁",'callback_data'=>'a6']],
   [['text'=>"رجوع 🔙",'callback_data'=>'panel']],
[
				   ],
                     ]
               ])
	]);	
$cuser["userfild"]["$fromid"]["acceptrules"]="true";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
		   }
else
{
if($tchq != 'member' && $tchq != 'creator' && $tchq != 'administrator'){
$join = $cuser["userfild"]["$fromid"]["canceljoin"];
if($join == false){
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"أشترك في قناة البوت الاساسية وأحصل
على 10 نقاط هدية مجانية من البوت 😉
القناة » @$channel",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [['text'=>"تحقق من الانضمام ♻️",'callback_data'=>'mainchannel']],
[['text'=>"أبلاغ 📛",'callback_data'=>'badchannel'],['text'=>"تخطي القناة ⏩",'callback_data'=>'takecoin']],
[['text'=>"رجوع 🔙",'callback_data'=>'panel']],
                     ]
               ])
			   ]);
$cuser["userfild"]["$fromid"]["canceljoin"]="true";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);		   
}
else
{
$allchannel = $user["channellist"];
for($z = 0;$z <= count($allchannel);$z++){
$getchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=".$allchannel[$z]."&user_id=".$fromid));
$okchannel = $getchannel->result->status;
if($okchannel != 'member' && $okchannel != 'creator' && $okchannel != 'administrator'){
break;
}
}
if ($allchannel[$z] == true){
$coin = $cuser["userfild"]["$fromid"]["coin"];
$coin = $cuser["userfild"]["$fromid"]["coin"];
$url = file_get_contents("https://api.telegram.org/bot$token/getChat?chat_id=$allchannel[$z]");
$getchat = json_decode($url, true);
$name = $getchat["result"]["title"]; 
$username = $getchat["result"]["username"]; 
$id = $getchat["result"]["id"]; 
$description = $getchat["result"]["description"];
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"نقاطك : $coin 💰
انضم بـ @$username 
وستحصل على 2 نقاط 🌝✌🏻
يرجى الابلاغ عن القنوات المخالفة 📛
➖➖➖➖➖➖➖➖➖➖➖➖",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [['text'=>"تحقق من الانضمام ♻️",'callback_data'=>'truechannel']],
[['text'=>"أبلاغ 📛",'callback_data'=>'badchannel'],['text'=>"تخطي القناة ⏩",'callback_data'=>'takecoin']],
[['text'=>"رجوع 🔙",'callback_data'=>'panel']],
                     ]
               ])
			   ]);
$cuser["userfild"]["$fromid"]["getjoin"]="$username";
$cuser["userfild"]["$fromid"]["arraychannel"]="$z";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);	
}
else
{
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"انتهت القنوات المضافة يمكنك الان
مشاركة رابطك مع صديق والحصول
على 5 نقاط 😃",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
				   ['text'=>"تحديث القنوات 😇",'callback_data'=>'takecoin'],['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
			   ]);
}
}
}
else
{
$allchannel = $user["channellist"];
for($z = 0;$z <= count($allchannel);$z++){
$getchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=".$allchannel[$z]."&user_id=".$fromid));
$okchannel = $getchannel->result->status;
if($okchannel != 'member' && $okchannel != 'creator' && $okchannel != 'administrator'){
break;
}
}
if ($allchannel[$z] == true){
$coin = $cuser["userfild"]["$fromid"]["coin"];
$url = file_get_contents("https://api.telegram.org/bot$token/getChat?chat_id=$allchannel[$z]");
$getchat = json_decode($url, true);
$name = $getchat["result"]["title"]; 
$username = $getchat["result"]["username"]; 
$id = $getchat["result"]["id"]; 
$description = $getchat["result"]["description"];
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"نقاطك : $coin 💰
انضم بـ @$username 
وستحصل على 2 نقاط 🌝✌🏻
يرجى الابلاغ عن القنوات المخالفة 📛
➖➖➖➖➖➖➖➖➖➖➖➖",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [['text'=>"تحقق من الانضمام ♻️",'callback_data'=>'truechannel']],
[['text'=>"أبلاغ 📛",'callback_data'=>'badchannel'],['text'=>"تخطي القناة ⏩",'callback_data'=>'takecoin']],
[['text'=>"رجوع 🔙",'callback_data'=>'panel']],
                     ]
               ])
			   ]);
$cuser["userfild"]["$fromid"]["getjoin"]="$username";
$cuser["userfild"]["$fromid"]["arraychannel"]="$z";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"انتهت القنوات المضافة يمكنك الان
مشاركة رابطك مع صديق والحصول
على 5 نقاط 😃",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
				   ['text'=>"تحديث القنوات 😇",'callback_data'=>'takecoin'],['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
			   ]);
}
}
}
}
elseif($data=="truechannel" ){
$getjoinchannel = $cuser["userfild"]["$fromid"]["getjoin"];
$getchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@".$getjoinchannel."&user_id=".$fromid));
$okchannel = $getchannel->result->status;
if($okchannel != 'member' && $okchannel != 'creator' && $okchannel != 'administrator'){
        php88 ('answercallbackquery', [
            'callback_query_id' =>$membercall,
            'text' => "• قم بألاشتراك في القناة اولا ؛ ثم اضغط على التالي ، 🔱 !",
            'show_alert' =>true
        ]);
}
else
{
 php88 ('answercallbackquery', [
            'callback_query_id' =>$membercall,
            'text' => "حصلت على نقطــتين 🥺🤸‍♀",
            'show_alert' =>false
				   ]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$coin = $cuser["userfild"]["$fromid"]["coin"];
$arraychannel = $cuser["userfild"]["$fromid"]["arraychannel"];
$coinchannel = $user["setmemberlist"];
$channelincoin = $coinchannel[$arraychannel];
$downchannel = $channelincoin - 1;
$pluscoin = $coin + 2;
$cuser["userfild"]["$fromid"]["channeljoin"][]="$getjoinchannel";
$cuser["userfild"]["$fromid"]["coin"]="$pluscoin";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
if($downchannel > 0){
@$user = json_decode(file_get_contents("data/user.json"),true);
$user["setmemberlist"]["$arraychannel"]="$downchannel";
$user["setmemberlist"]=array_values($user["setmemberlist"]); 
$user = json_encode($user,true);
file_put_contents("data/user.json",$user);
@$user = json_decode(file_get_contents("data/user.json"),true);
$allchannel = $user["channellist"];
for($z = 0;$z <= count($allchannel);$z++){
$getchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=".$allchannel[$z]."&user_id=".$fromid));
$okchannel = $getchannel->result->status;
if($okchannel != 'member' && $okchannel != 'creator' && $okchannel != 'administrator'){
break;
}
}
if ($allchannel[$z] == true){
$coin = $cuser["userfild"]["$fromid"]["coin"];
$url = file_get_contents("https://api.telegram.org/bot$token/getChat?chat_id=$allchannel[$z]");
$getchat = json_decode($url, true);
$name = $getchat["result"]["title"]; 
$username = $getchat["result"]["username"]; 
$id = $getchat["result"]["id"]; 
$description = $getchat["result"]["description"];
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"نقاطك : $coin 💰
انضم بـ @$username 
وستحصل على 2 نقاط 🌝✌🏻
يرجى الابلاغ عن القنوات المخالفة 📛
➖➖➖➖➖➖➖➖➖➖➖➖",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [['text'=>"تحقق من الانضمام ♻️",'callback_data'=>'truechannel']],
[['text'=>"أبلاغ 📛",'callback_data'=>'badchannel'],['text'=>"تخطي القناة ⏩",'callback_data'=>'takecoin']],
[['text'=>"رجوع 🔙",'callback_data'=>'panel']],
                     ]
               ])
			   ]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$cuser["userfild"]["$fromid"]["getjoin"]="$username";
$cuser["userfild"]["$fromid"]["arraychannel"]="$z";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"انتهت القنوات المضافة يمكنك الان
مشاركة رابطك مع صديق والحصول
على 5 نقاط 😃",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
				   ['text'=>"تحديث القنوات 😇",'callback_data'=>'takecoin'],['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
			   ]);
}
}
else
{
unset($user["setmemberlist"]["$arraychannel"]);
unset($user["channellist"]["$arraychannel"]);
$user["channellist"]=array_values($user["channellist"]); 
$user["setmemberlist"]=array_values($user["setmemberlist"]);  
$user = json_encode($user,true);
file_put_contents("data/user.json",$user);
@$user = json_decode(file_get_contents("data/user.json"),true);
$allchannel = $user["channellist"];
for($z = 0;$z <= count($allchannel);$z++){
$getchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=".$allchannel[$z]."&user_id=".$fromid));
$okchannel = $getchannel->result->status;
if($okchannel != 'member' && $okchannel != 'creator' && $okchannel != 'administrator'){
break;
}
}
if ($allchannel[$z] == true){
$coin = $cuser["userfild"]["$fromid"]["coin"];
$url = file_get_contents("https://api.telegram.org/bot$token/getChat?chat_id=$allchannel[$z]");
$getchat = json_decode($url, true);
$name = $getchat["result"]["title"]; 
$username = $getchat["result"]["username"]; 
$id = $getchat["result"]["id"]; 
$description = $getchat["result"]["description"];
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"نقاطك : $coin 💰
انضم بـ @$username 
وستحصل على 2 نقاط 🌝✌🏻
يرجى الابلاغ عن القنوات المخالفة 📛
➖➖➖➖➖➖➖➖➖➖➖➖",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [['text'=>"تحقق من الانضمام ♻️",'callback_data'=>'truechannel']],
[['text'=>"أبلاغ 📛",'callback_data'=>'badchannel'],['text'=>"تخطي القناة ⏩",'callback_data'=>'takecoin']],
[['text'=>"رجوع 🔙",'callback_data'=>'panel']],
                     ]
               ])
			   ]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$cuser["userfild"]["$fromid"]["getjoin"]="$username";
$cuser["userfild"]["$fromid"]["arraychannel"]="$z";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"انتهت القنوات المضافة يمكنك الان
مشاركة رابطك مع صديق والحصول
على 5 نقاط 😃",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
				   ['text'=>"تحديث القنوات 😇",'callback_data'=>'takecoin'],['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
			   ]);
}
}
}
}
elseif($data=="nextchannel" ){
 php88 ('answercallbackquery', [
            'callback_query_id' =>$membercall,
            'text' => "- انتظر قليلا ... 📌 !",
            'show_alert' =>false
        ]);
$arraychannel = $cuser["userfild"]["$fromid"]["arraychannel"];
$plusarraychannel = $arraychannel + 1 ;
$allchannel = $user["channellist"];
for($z = $plusarraychannel;$z <= count($allchannel);$z++){
$getchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=".$allchannel[$z]."&user_id=".$fromid));
$okchannel = $getchannel->result->status;
if($okchannel != 'member' && $okchannel != 'creator' && $okchannel != 'administrator'){
break;
}
}
if ($allchannel[$z] == true){
$coin = $cuser["userfild"]["$fromid"]["coin"];
$url = file_get_contents("https://api.telegram.org/bot$token/getChat?chat_id=$allchannel[$z]");
$getchat = json_decode($url, true);
$name = $getchat["result"]["title"]; 
$username = $getchat["result"]["username"]; 
$id = $getchat["result"]["id"]; 
$description = $getchat["result"]["description"];
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"نقاطك : $coin 💰
انضم بـ @$username 
وستحصل على 2 نقاط 🌝✌🏻
يرجى الابلاغ عن القنوات المخالفة 📛
➖➖➖➖➖➖➖➖➖➖➖➖",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [['text'=>"تحقق من الانضمام ♻️",'callback_data'=>'truechannel']],
[['text'=>"أبلاغ 📛",'callback_data'=>'badchannel'],['text'=>"تخطي القناة ⏩",'callback_data'=>'takecoin']],
[['text'=>"رجوع 🔙",'callback_data'=>'panel']],
                     ]
               ])
			   ]);
$cuser["userfild"]["$fromid"]["getjoin"]="$username";
$cuser["userfild"]["$fromid"]["arraychannel"]="$z";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"- انتهت القنوات المضافةه ؛ يرجى المحاولة مرى اخرة في تجميع النقاط ، او قم بمشاركة الرابط بدل عن الاشتراك في القنوات ، 📻 ' !",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
				   ['text'=>"تحديث القنوات 😇",'callback_data'=>'takecoin'],['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
			   ]);
}
}
elseif($data=="mainchannel" ){
$getchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@".$channel."&user_id=".$fromid));
$okchannel = $getchannel->result->status;
if($okchannel != 'member' && $okchannel != 'creator' && $okchannel != 'administrator'){
        php88 ('answercallbackquery', [
            'callback_query_id' =>$membercall,
            'text' => "• قم بألاشتراك في القناة اولا ؛ ثم اضغط على التالي ، 🔱 !",
            'show_alert' =>true
        ]);
}
else
{
 php88 ('answercallbackquery', [
            'callback_query_id' =>$membercall,
            'text' => "حصلت على نقطــتين 🥺🤸‍♀",
            'show_alert' =>false
        ]);
$coin = $cuser["userfild"]["$fromid"]["coin"];
$pluscoin = $coin + 2;
$cuser["userfild"]["$fromid"]["coin"]="$pluscoin";
$cuser["userfild"]["$fromid"]["channeljoin"][]="$channel";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
@$user = json_decode(file_get_contents("data/user.json"),true);
$allchannel = $user["channellist"];
for($z = 0;$z <= count($allchannel);$z++){
$getchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=".$allchannel[$z]."&user_id=".$fromid));
$okchannel = $getchannel->result->status;
if($okchannel != 'member' && $okchannel != 'creator' && $okchannel != 'administrator'){
$omm = $allchannel[$z];
break;
}
}
if ($allchannel[$z] == true){
$coin = $cuser["userfild"]["$fromid"]["coin"];
$url = file_get_contents("https://api.telegram.org/bot$token/getChat?chat_id=$allchannel[$z]");
$getchat = json_decode($url, true);
$name = $getchat["result"]["title"]; 
$username = $getchat["result"]["username"]; 
$id = $getchat["result"]["id"]; 
$description = $getchat["result"]["description"];
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"نقاطك : $coin 💰
انضم بـ @$username 
وستحصل على 2 نقاط 🌝✌🏻
يرجى الابلاغ عن القنوات المخالفة 📛
➖➖➖➖➖➖➖➖➖➖➖➖",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [['text'=>"تحقق من الانضمام ♻️",'callback_data'=>'truechannel']],
[['text'=>"أبلاغ 📛",'callback_data'=>'badchannel'],['text'=>"تخطي القناة ⏩",'callback_data'=>'takecoin']],
[['text'=>"رجوع 🔙",'callback_data'=>'panel']],
                     ]
               ])
			   ]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$cuser["userfild"]["$fromid"]["getjoin"]="$username";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
else
{
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"انتهت القنوات المضافة يمكنك الان
مشاركة رابطك مع صديق والحصول
على 5 نقاط 😃",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
				   ['text'=>"تحديث القنوات 😇",'callback_data'=>'takecoin'],['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
			   ]);
}
}
}
elseif($data=="badchannel"){
$getjoinchannel = $cuser["userfild"]["$fromid"]["getjoin"];
	 php88 ('answercallbackquery', [
	            'callback_query_id' =>$membercall,
            'text' => "تم تقديم طلب الحذف من البوت سيراجع مسؤل البوت الطلب, يرجى تقديم تبليغ عن القناة داخل التليكرام ليتم حذفها نهائيا 📛",
            'show_alert' =>true
        ]);
	php88 ('sendmessage',[
	'chat_id'=>$Dev[0],
	'text'=>"- ابلاغ جديد عن قناة غير ملتزمة او انحرافية في البوت ، معرف القناة ؛ @$getjoinchannel !

	﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
• معلومات العضو الذي قام بالابلاغ عن القناة ؛ 👇🏿♥️ ؛

▫️ الايدي ؛ $fromid ،
◾️ المعرف ؛ @$usernames ،",
  	]);		
}
elseif($data=="accont"){
$invite = $cuser["userfild"]["$fromid"]["invite"];
$coin = $cuser["userfild"]["$fromid"]["coin"];
$setchannel = $cuser["userfild"]["$fromid"]["setchannel"];
$setmember = $cuser["userfild"]["$fromid"]["setmember"];
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"• جميع احصائيات النقاط الخاصةه بك ؛ 💛👇🏿 ' 
      
◾️ عدد النقاط ؛ $coin
▫️ اخر قناة قمت بتمويلها ؛ $setchannel
◾️ عدد الاعضاء الذي قمت بطلبهم للقناة ؛ $setmember
▫️ عدد الذين قامو باستخدام رابطك ؛ $invite
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
• معلومات حسابك الشخصي ؛ 📌'

◾️ الاسم ؛ $firstname
▫️ المعرف ؛ @$usernames
◾️ الايدي ؛ $fromid",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   				   [['text'=>"- القنوات التي تم الاشتراك فيها ، 📭 '",'callback_data'=>'mechannel']],
[['text'=>"- القنوات التي تم تمويلها من البوت ، ⚖ '",'callback_data'=>'order']
				   ],
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
			   ]);	
}
elseif($data=="mechannel"){
$allchannel = $cuser["userfild"]["$fromid"]["channeljoin"];
for($z = 0;$z <= count($allchannel)-1;$z++){
$result = $at.$result."📍 "."@".$allchannel[$z]."\n";
}
if($result == true){
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"- لستةه القنوات التي قمت بالاشتراك فيها ، 💛👇🏿؛
	
$result

• ملاحظة : عند مغادرتك قناة واحدة سوف يتم خصم 2 من نقاطك ' بسبب المغادرة ؛ لذلك وجب التنبيه ، 📂 '",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
				   ]
            ])           
  	]);		
}	
else
{
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"- انت لم تقم بالاشتراك في أي قناة من قنوات البوت ياعزيزي ؛ يرجى الاشتراك وتجميع النقاط ومن بعدها الضغط على زر القنوات التي تم الاشتراك فيها ، 🚸 .
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel'],['text'=>"جمع نقاط 💰",'callback_data'=>'takecoin']
				   ],
				   ]
            ])           
  	]);		
}
}
elseif($data=="order"){
$allchannel = $cuser["userfild"]["$fromid"]["listorder"];
for($z = 0;$z <= count($allchannel)-1;$z++){
$result = $at.$result."📍 ".$allchannel[$z]."  عضو"."\n";
}
if($result == true){
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"القنوات التي تم تمويلها من خلال البوت 😎

$result",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
				   ]
            ])           
  	]);		
}
else
{
$coin = $cuser["userfild"]["$fromid"]["coin"];
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"- عذرا ياعزيزي انت لم تقم بتمويل أي قناة من قنواتك ؛ لانك لا تمتلك النقاط او تمتلك ولكنك لم تقم بالتمويل .. اذا كانت لديك نقاط كافية لشراء الاعضاء اضغط على الزر الموجود بالاسفل ، 🇮🇶 ' 
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel'],['text'=>"- شراء الاعضاء ، 💸 '",'callback_data'=>'takemember']
				   ],
				   ]
            ])           
  	]);		
}
}
elseif($data=="member"){
$invite = $cuser["userfild"]["$fromid"]["invite"];
$coin = $cuser["userfild"]["$fromid"]["coin"];
		php88 ('sendMessage',[
	'chat_id'=>$chatid,
	'text'=>"- بوت زيادة الاعضاء للقنوات ، ⚖ !

- يمكنك جمع النقاط وزيادة اعضاء قناتك اعضاء حقيقيين من خلال البوت باليوم 500 عضو واكثر وكلشي مضمون ، 📻 !

- قم بالدخول الى البوت من خلال الرابط التالي لا تقم بتفويت هذه الفرصةه العظيمةه ، 👇🏿♥️ ؛
https://t.me/$usernamebot?start=$fromid",
    		]);
	php88 ('sendmessage',[
	'chat_id'=>$chatid,
	'text'=>"- قم بمشاركةه الرابط الذي في الاعلى واحصل على النقاط بكل سهولة ؛ دون الاشتراك في القنوات قم بارسال رابطك الى جميع المجموعات والقنوات واحصل على النقاط ، 🐬 !

• عدد النقاط الخاصةه بك ؛ $coin
• عدد الذين قامو بالدخول الى رابطك ؛ $invite",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
				   ]
            ])           
  	]);			
}
elseif($data=="sendcoin"){	

php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
	'text'=>"- لارسال النقاط الى مستخدم اخر يجب ان يكون المستخدم مشترك في البوت وبعدها قم بارسال ايدي المستخدم لارسال النقاط اليه ، 📌 !
	
	- او قم بأرسال توجيه رسالة من رسائل المستخدم الذي تريد ارسال النقاط اليه الى البوت ، 💬 '
	﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
				   ]
            ])           
  	]);	
$cuser["userfild"]["$fromid"]["file"]="sendcoin";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);		
}
elseif ($juser["userfild"]["$from_id"]["file"] == 'sendcoin') {
$coin = $juser["userfild"]["$from_id"]["coin"];
if($forward_from == true){
if($forward_from_id != $from_id){
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"• تم العثور على المستخدم معلومات المستخدم ، 💚👇🏿؛

▫️ الاسم ؛ $forward_from_first_name
◾️ المعرف ؛ @$forward_from_username
▫️ الايدي ؛  $forward_from_id

- الان قم بارسال العدد الذي تريد تحويله الى المستخدم ،
- عدد النقاط الخاصةه بك ؛ $coin ",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
$juser["userfild"]["$from_id"]["file"]="setsendcoin";
$juser["userfild"]["$from_id"]["sendcoinid"]="$forward_from_id";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
}
else
{
	php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"• لا يمكن ارسال نقاطك الى نفسك ياعزيزي ؛ ارسل ايدي المستخدم فقط ، 🌟 !",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
}
}
else
{
if($textmassage != $from_id){
if(is_numeric($textmassage)){
$stat = file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$textmassage&user_id=".$textmassage);
$statjson = json_decode($stat, true);
$status = $statjson['ok'];
if($status == 1){
$name = $statjson['result']['user']['first_name'];
$username = $statjson['result']['user']['username'];
$id = $statjson['result']['user']['id'];
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"• تم العثور على المستخدم معلومات المستخدم ، 💚👇🏿؛

▫️ الاسم ؛ $name
◾️ المعرف ؛ @$usrrname
▫️ الايدي ؛  $id

- الان قم بارسال العدد الذي تريد تحويله الى المستخدم ،
- عدد النقاط الخاصةه بك ؛ $coin ",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
$juser["userfild"]["$from_id"]["file"]="setsendcoin";
$juser["userfild"]["$from_id"]["sendcoinid"]="$textmassage";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
}
else
{
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"- الايدي الخاص بالمستخدم غير صحيح ، 🔱
- قم بالتاكد من الايدي وارسالة مرة اخرى الى البوت ، 🕊 !",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
}
}
else
{
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"• ايدي العضو غير صحيح او المستخدم غير مشترك في البوت يرجى التاكد من الايدي او قم بالاشتراك في البوت ، 🔰؛
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
}
}
else
{
	php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"- لا يمكن الارسال لنفسك ؛ ⚠️
- قم بالارسال لصديق او لحسابك الثاني ، ☑️
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);	
}
}
}	
elseif($juser["userfild"]["$from_id"]["file"] == "setsendcoin"){
$coin = $juser["userfild"]["$from_id"]["coin"];
$userid = $juser["userfild"]["$from_id"]["sendcoinid"];
$inuser = json_decode(file_get_contents("data/$userid.json"),true);
$coinuser = $inuser["userfild"]["$userid"]["coin"];
if($textmassage <= $coin && $coin > 0){
$coinplus = $coin - $textmassage;
$sendcoinplus = $coinuser + $textmassage;
	php88 ('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"- تم ارسال النقاط الى المستخدم بنجاح ، ⚖ !
- المعلومات العامةه للعضو والنقاط ، 📌 ؛

▫️ ايدي العضو ؛ $userid
◾️ عدد النقاط التي تم ارسالها ؛ $textmassage
▫️ عدد نقاطك الآن ؛ $coinplus",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
				   ]
            ])           
  	]);	
		php88 ('sendmessage',[
	'chat_id'=>$userid,
	'text'=>"- تم ارسال $textmassage من النقاط اليك ، 🌟 !
- معلومات العضو الذي قام بأرسال النقاط اليك ، 🔱 ؛

◾️ ايدي العضو ؛ $from_id
▫️ المعرف ؛ @$username",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
				   ]
            ])           
  	]);	
$juser["userfild"]["$from_id"]["file"]="none";
$juser["userfild"]["$from_id"]["coin"]="$coinplus";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
$inuser["userfild"]["$userid"]["coin"]="$sendcoinplus";
$inuser = json_encode($inuser,true);
file_put_contents("data/$userid.json",$inuser);	
}
else
{
	php88 ('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"- عدد النقاط الذي تود ارسالة اقل من عدد نقاطك ، 🐬 !
- اقصى عدد يمكنك ارساله ؛ $coin",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
				   ]
            ])           
  	]);	
}
}

elseif($data=="takemember"){
$coin = $cuser["userfild"]["$fromid"]["coin"];
if($coin >= 10){
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"الان قم بأرسال معرف القناة ؛ ⁉️ !
مثال ؛ @$channel ",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
			   ]);	
$cuser["userfild"]["$fromid"]["file"]="setchannel";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);	
}
else
{
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"- يجب ان يكون العدد اكثر من 10 نقاط ،  🇮🇶 '

- عدد النقاط الحالي ؛ $coin ",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel'],['text'=>"جمع نقاط 💰",'callback_data'=>'takecoin']
				   ],
                     ]
               ])
			   ]);	
}
}
elseif ($juser["userfild"]["$from_id"]["file"] == 'setchannel') {
if(preg_match('/^(@)(.*)/s',$textmassage)){
$coin = $juser["userfild"]["$from_id"]["coin"];
$max = $coin / 3;
$maxmember = floor($max);
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"قم بأرسال عدد الاعضاء الان ليتم لتمويل 😉
قناتك : $textmassage 📥
نقاطك : $coin 💰
أسعار النقاط كما يلي في الاسفل 😌🌸

20 = 6 عضو      |💰|    30 = 10 عضو
40 = 13 عضو    |💰|    50 = 16 عضو
60 = 20 عضو    |💰|    70 = 23 عضو
80 = 26 عضو    |💰|    90 = 30 عضو
100 = 33 عضو  |💰|    110 = 36 عضو
120 = 40 عضو  |💰|    130 = 43 عضو
140 = 46 عضو  |💰|    150 = 50 عضو

ملاحظة : سعر العضو الواحد بـ 3 نقاط
والمعادلة الرئيسية هية 3÷10 تقوم بـ
تقسيم عدد 3 مع عدد نقاطك للتأكد 😃",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
$juser["userfild"]["$from_id"]["file"]="setmember";
$juser["userfild"]["$from_id"]["setchannel"]="$textmassage";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
}
else
{
	php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"تأكد من معرف القناة الخاصة بك ⁉️
يجب ان يكون هكذا » @$channel ",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
}
}
elseif ($juser["userfild"]["$from_id"]["file"] == 'setmember') {
$coin = $juser["userfild"]["$from_id"]["coin"];
$setchannel = $juser["userfild"]["$from_id"]["setchannel"];
$max = $coin / 3;
$maxmember = floor($max);
if($maxmember >= $textmassage){
$howmember = getChatMembersCount($setchannel,$token);
$endmember = $howmember + $textmassage;
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"• معلومات التمويل الحالي 💯

القناة المراد تمويلها : *$setchannel* ،
العدد المطلوب : *$textmassage* ،
اعضاء القناة الحالي  : *$howmember* ،
عدد الاعضاء بعد التمويل : *$endmember* ،

قم برفع البوت مشرف في القناة ليتم العمل بصورة صحيحة ؛ قم برفع البوت ثم اضغط على زر تأكيد الذي يوجد تحت",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   				   [
['text'=>"تأكيد وموافقة ♨️'",'callback_data'=>'trueorder']
				   ],
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel'],
				   ],
                     ]
               ])
 ]);
$juser["userfild"]["$from_id"]["file"]="none";
$juser["userfild"]["$from_id"]["setmember"]="$textmassage";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
else
{
	php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"• العدد الذي قمت بطلبه اكثر من نقاطك 👤
• لذلك لم يتم استجابة طلبكك 🤞

تأكد من عدد نقودك وعدد الاعضاء الذي طلبتة",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
}
}
elseif($data=="trueorder"){
$setchannel = $cuser["userfild"]["$fromid"]["setchannel"];
$admin = getChatstats(@$setchannel,$token);
if($admin != true){
	       php88 ('answercallbackquery', [
            'callback_query_id' =>$membercall,
            'text' => "أرفع البوت أدمن ليتم تمويلها بشكل آمن 🗣",
            'show_alert' =>true
        ]);
}
else
{
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"• تم وضع قناتك ضمن قنوات التمويل Ⓜ️

يمكنك طلب الهدايا ايضا ؛ ملاحظة اذا قمت بمخالفة قوانين وقواعد وتعليمات البوت سوف نقوم بحذف قناتك تأكد من الذهاب الى المساعدة والقواعد لتجنب الحظر ،✅",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel'],
				   ],
                     ]
               ])
			   ]);	
$coin = $cuser["userfild"]["$fromid"]["coin"];
$setchannel = $cuser["userfild"]["$fromid"]["setchannel"];
$setmember = $cuser["userfild"]["$fromid"]["setmember"];
$pluscoin = $setmember * 3;
$coinplus = $coin - $pluscoin;
$cuser["userfild"]["$fromid"]["coin"]="$coinplus";
$cuser["userfild"]["$fromid"]["listorder"][]="$setchannel -> $setmember";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
$user["channellist"][]="$setchannel";
$user["setmemberlist"][]="$setmember";
$user = json_encode($user,true);
file_put_contents("data/user.json",$user);
}
}

elseif($data=="sup"){
php88 ('editmessagetext',[
                'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"- الدعم وحل المشاكل الموجودة بالبوت ؛

- الرجاء ارسال الشكاوي او المشاكل الموجودة بالبوت ليتم تصحيحها ارسل مشكلتك برسالة واحدة فضلا ؛ 🕊 !

- يمكنك ايضا ارسال الميديا ؛ الصور والملصقات والصوت وغيرها .. ",
                'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
			   ]);	
$cuser["userfild"]["$fromid"]["file"]="sendsup";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);	
}
elseif ($juser["userfild"]["$from_id"]["file"] == 'sendsup') {
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"• تم ارسال رسالتك الى مبرمج البوت ، 
• انتظر الاجابة من فضلك ، ",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
php88 ('ForwardMessage',[
'chat_id'=>$Dev[0],
'from_chat_id'=>$chat_id,
'message_id'=>$message_id
]);
}
	elseif($update->message && $update->message->reply_to_message && in_array($from_id,$Dev) && $tc == "private"){
	php88 ('sendmessage',[
        "chat_id"=>$chat_id,
        "text"=>"- تم ارسال رسالتك الى العضو بنجاح ، 🎌 !
- بواسطه ؛ @$username !"
		]);
	php88 ('sendmessage',[
        "chat_id"=>$reply,
        "text"=>"$textmassage",
'parse_mode'=>'MarkDown'
		]);
}
if(file_get_contents("data/$fromid.txt") == "true"){
$pluscoin = file_get_contents("data/".$fromid."coin.txt");
$inviter = $cuser["userfild"]["$fromid"]["inviter"];
$invitercoin = $pluscoin / 100 * 20;
	       php88 ('answercallbackquery', [
            'callback_query_id' =>$membercall,
            'text' => "📍 اضافة النقود التي تم شراءها ...",
            'show_alert' =>false
        ]);
		         php88 ('sendmessage',[
        	'chat_id'=>$inviter,
        	'text'=>"💰 العدد : $invitercoin !
			
📍 تمت العمليةه بنجاح !!",
               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
$coin = $cuser["userfild"]["$fromid"]["coin"];
$coinplus = $coin + $pluscoin;
$cuser["userfild"]["$fromid"]["coin"]="$coinplus";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
$inuser = json_decode(file_get_contents("data/$inviter.json"),true);
$coininviter = $inuser["userfild"]["$inviter"]["coin"];
$coinplusinviter = $coininviter + $invitercoin ;
$inuser["userfild"]["$inviter"]["coin"]="$coinplusinviter";;
$inuser = json_encode($inuser,true);
file_put_contents("data/$inviter.json",$inuser);
unlink("data/".$fromid."coin.txt");
unlink("data/$fromid.txt");
}


//panel admin


elseif($textmassage=="/panel" or $textmassage=="/admin" or $textmassage=="ادمن"){
if ($tc == "private") {
if (in_array($from_id,$Dev)){
php88 ('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"- اهلا بك عزيزي المطور ، 🧜‍♂ '
- قم باختيار ماتريد من القائمةه التي في الاسفل ، 👅 '
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
         'reply_to_message_id'=>$message_id,
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [['text'=>"- عدد الاعضاء ، 👤 '"]],
[['text'=>"- رسالة للكل ، 🎒 '"],['text'=>"- توجيه للكل ، 🧜‍♂ '"]],
[['text'=>"- عرض القنوات ، 🔱 '"],['text'=>"- حذف قناة ، 📛 '"]],
[['text'=>"📍 نقاط للكل"],['text'=>"- ارسال نقاط ، 🕊 '"]],

   ],
      'resize_keyboard'=>true
   ])
 ]);
}
}
}
elseif($textmassage=="رجوع 🔙"){
if ($tc == "private") {
if (in_array($from_id,$Dev)){
php88 ('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"- اهلا بك عزيزي المطور ، 🧜‍♂ '
- قم باختيار ماتريد من القائمةه التي في الاسفل ، 👅 '
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
         'reply_to_message_id'=>$message_id,
	  'reply_markup'=>json_encode([
    'keyboard'=>[
	  	  	 [['text'=>"- عدد الاعضاء ، 👤 '"]],
[['text'=>"- رسالة للكل ، 🎒 '"],['text'=>"- توجيه للكل ، 🧜‍♂ '"]],
[['text'=>"- عرض القنوات ، 🔱 '"],['text'=>"- حذف قناة ، 📛 '"]],
[['text'=>"📍 نقاط للكل"],['text'=>"- ارسال نقاط ، 🕊 '"]],

   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["$from_id"]["file"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
}
elseif($textmassage=="- عدد الاعضاء ، 👤 '"){
if (in_array($from_id,$Dev)){
$all = count($user["userlist"]);
$order = count($user["channellist"]);
				php88 ('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"• اهلا بك يا عزيزي المطور ؛ @username !

◾️ عدد الاعضاء ؛ $all ،
▫️ عدد القنوات بقائمةه التمويل ؛ $order .
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
                'hide_keyboard'=>true,
		]);
		}
}

elseif ($textmassage == "- رسالة للكل ، 🎒 '" ) {
if (in_array($from_id,$Dev)){
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"- اهلا بك يا ؛ @$username !
- الان قم بارسال الرسالة ليتم ارسالها للكل ، 🇮🇶 '",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"رجوع 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["$from_id"]["file"]="sendtoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
}
}
elseif ($juser["userfild"]["$from_id"]["file"] == 'sendtoall') {
$juser["userfild"]["$from_id"]["file"]="none";
$numbers = $user["userlist"];
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
if ($textmassage != "رجوع 🔙") {
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"- تم ارسال الرسالة الى جميع مشتركين البوت بنجاح بواسطة ؛ @$username ، 📢 !",
	  'reply_to_message_id'=>$message_id,
 ]);
for($z = 0;$z <= count($numbers)-1;$z++){
     php88 ('sendmessage',[
          'chat_id'=>$numbers[$z],        
		  'text'=>"$textmassage
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
        ]);
}
}
}
elseif ($textmassage == "- توجيه للكل ، 🧜‍♂ '" ) {
if (in_array($from_id,$Dev)){
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"- اهلا بك يا ؛ @$username !
- الان قم بارسال التوجيه ليتم ارسالة للكل ، 🇮🇶 '",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"رجوع 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["$from_id"]["file"]="fortoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
elseif ($juser["userfild"]["$from_id"]["file"] == 'fortoall') {
$juser["userfild"]["$from_id"]["file"]="none";
$numbers = $user["userlist"];
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
if ($textmassage != "رجوع 🔙") {
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"- تم ارسال التوجيه الى جميع مشتركين البوت بنجاح بواسطة ؛ @$username ، 📢 !",
	  'reply_to_message_id'=>$message_id,
 ]);
for($z = 0;$z <= count($numbers)-1;$z++){
Forward($numbers[$z], $chat_id,$message_id);
}
}
}
elseif($textmassage=="- عرض القنوات ، 🔱 '"){
if (in_array($from_id,$Dev)){
$order = $user["channellist"];
$ordercount = count($user["channellist"]);
for($z = 0;$z <= count($order)-1;$z++){
$result = $result.$order[$z]."\n";
}
				php88 ('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"- اهلا بك ؛ @$username !! 

◾️ عدد القنوات التي تحت التمويل ؛ $ordercount
		▫️ لستةه معرفات القنوات التي تحت التمويل ؛ 📌
$result",
                'hide_keyboard'=>true,
		]);
		}
}
elseif($textmassage=="- حذف قناة ، 📛 '"){
if (in_array($from_id,$Dev)){
				php88 ('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"- حسنا ياعزيزي ؛ @$username !
- الان قم بارسال معرف القناة التي تود حذفها ، 🔘
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
  'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"رجوع 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
		]);
$juser["userfild"]["$from_id"]["file"]="remorder";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
		}
}
elseif ($juser["userfild"]["$from_id"]["file"] == 'remorder') {
if ($textmassage != "رجوع 🔙") {
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"- تم حذف القناة من البوت بنجاح ، ⚠️
- بواسطة ؛ @$username ، !",
	  'reply_to_message_id'=>$message_id,
 ]);
$how = array_search($textmassage,$user["channellist"]);
unset($user["setmemberlist"][$how]);
unset($user["channellist"][$how]);
$user["channellist"]=array_values($user["channellist"]); 
$user["setmemberlist"]=array_values($user["setmemberlist"]);
$user = json_encode($user,true);
file_put_contents("data/user.json",$user);  
$juser["userfild"]["$from_id"]["file"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
elseif($textmassage=="- ارسال نقاط ، 🕊 '"){
if (in_array($from_id,$Dev)){
				php88 ('sendmessage',[
		'chat_id'=>$chat_id,
		'text'=>"ارسل ايدي العضو الذي تريد الاىسال اليه او ارسل توجيه من العضو",
  'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"رجوع 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
		]);
$juser["userfild"]["$from_id"]["file"]="adminsendcoin";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
		}
}
elseif ($juser["userfild"]["$from_id"]["file"] == 'adminsendcoin') {
if ($textmassage != "رجوع 🔙") {
if ($forward_from == true) {
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"حسنا عزيزي المطور

الايدي : $forward_from_id
المعرف : @$forward_from_username

دز عدد النقاط الان",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"رجوع 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["idforsend"]="$forward_from_id";
$juser["userfild"]["$from_id"]["file"]="sethowsendcoin";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
}
else
{
	         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"ارسل العدد الذي تريد ارسالة الى صاحب الايدي : $textmassage",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"رجوع 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["idforsend"]="$textmassage";
$juser["userfild"]["$from_id"]["file"]="sethowsendcoin";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
}
}
}
elseif ($juser["userfild"]["$from_id"]["file"] == 'sethowsendcoin') {
if ($textmassage != "رجوع 🔙") {
$id = $juser["idforsend"];
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"📍 العدد $textmassage تم الارسال الى : $id بنجاح ^_^",
	  'reply_to_message_id'=>$message_id,
 ]);
          php88 ('sendmessage',[
        	'chat_id'=>$id,
        	'text'=>"تم استلام » $textmassage نقطة 💰
من أدآرة البوت حظا موفقآ 😀",
			               'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
 ]);
$inuser = json_decode(file_get_contents("data/$id.json"),true);
$coin = $inuser["userfild"]["$id"]["coin"];
$coinplus = $coin + $textmassage;
$inuser["userfild"]["$id"]["coin"]="$coinplus";
$inuser = json_encode($inuser,true);
file_put_contents("data/$id.json",$inuser);
}
}

elseif ($textmassage == '📍 نقاط للكل' ) {
if (in_array($from_id,$Dev)){
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"ادخل العدد الذي تريده للنقود",
	  'reply_to_message_id'=>$message_id,
	   'reply_markup'=>json_encode([
    'keyboard'=>[
	[
	['text'=>"رجوع 🔙"] 
	]
   ],
      'resize_keyboard'=>true
   ])
 ]);
$juser["userfild"]["$from_id"]["file"]="sendcointoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);		
}
}
elseif ($juser["userfild"]["$from_id"]["file"] == 'sendcointoall') {
$juser["userfild"]["$from_id"]["file"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);	
if ($textmassage != "رجوع 🔙") {
$numbers = $user["userlist"];
         php88 ('sendmessage',[
        	'chat_id'=>$chat_id,
        	'text'=>"نم ارسال النقاط للجميع ✔️",
	  'reply_to_message_id'=>$message_id,
 ]);
for($z = 0;$z <= count($numbers)-1;$z++){
   php88 ('sendmessage',[
          'chat_id'=>$numbers[$z],        
		  'text'=>"هدية يومية من قبل أدآرة البوت مبلغ 📥
الهدية هوه » $textmassage 😉",
          'reply_markup'=>json_encode([
                   'inline_keyboard'=>[
				   [
['text'=>"رجوع 🔙",'callback_data'=>'panel']
				   ],
                     ]
               ])
        ]);
$juser = json_decode(file_get_contents("data/$numbers[$z].json"),true);
$coin = $juser["userfild"]["$numbers[$z]"]["coin"];
$coinplus = $coin + $textmassage;
$juser["userfild"]["$numbers[$z]"]["coin"]="$coinplus";
$juser = json_encode($juser,true);
file_put_contents("data/$numbers[$z].json",$juser);	
}
}
}
elseif($update->message->text != true){ 
	php88 ('sendmessage',[
	'chat_id'=>$chat_id,
	'text'=>"• يرجى استخدام ازرار البوت فقط ارسل /start لرؤيةه الازرار ، للاستفسار او لشراء النقاط عليك مراسلة المبرمج ؛ @$username ، 💌 !",
	  	]);
}
if($data=="m1"){
php88 ('editmessagetext',[
        'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"طريقة عمل البوت تكون بتحويل النقاط الى اعضاء تضيفهم الى قناتك 👥
تكسب النقاط من خلال :
 الانضمام بقنوات (2💰) 
*يعطيك 2 💰 مقابل انضمامك لقناة واحده ☝🏻
*في حال كنت قد غادرت احدى القنوات الي اخذت نقاط مقابل الانضمام فيها فلن تتمكن من طلب اعضاء حتى تقوم بلرجوع اليها 😅

مشاركة الرابط (5💰) 
*يعطيك (5💰) مقابل كل شخص جديد يدخل البوت من خلال رابطك Ⓜ️

الهدية اليومية ( 10 💰 )
* يعطيك  ( 10 💰 ) كل يوم لا تنسى ان تأخذها 🎁

بعد ان تقوم بجمع ع الاقل 30 نقطة اضغط على طلب اعضاء 👤
 يتم تحويل النقاط الى اعضاء بهذا المقياس 🔰
 3 💰 = 1 👤
 30 💰 = 10 👤 
بعد ان تقوم بطلب الاعضاء 👤 سيتم تثبيت قناتك في  ( الانضمام بقنوات 💡 )
  سينضم الاعضاء بقناتك مقابل 2💰 نقاط تضاف لهم
بعد اكتمال دخول الاعضاء سيتم اعلامك بأنتهاء طلبك وانتهاء دخول العدد الذي طلبته 😼",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
[['text'=>"جمع نقاط 💰",'callback_data'=>'takecoin'],['text'=>"طلب اعضاء 👤",'callback_data'=>'takemember']],
[['text'=>"الاستخدام المثالي 🌞",'callback_data'=>'m2']],
      [['text'=>"رجوع 🔙",'callback_data'=>'panel']],
  	],
	  	'resize_keyboard'=>true,
  	])
  	]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$cuser["userfild"]["$fromid"]["file"]="none";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
if($data=="m2"){
php88 ('editmessagetext',[
        'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"✳️ اقراء بتركيز لكي لتحقق اكبر استفاده  
ننصح بأنشاء حساب تليكرام جديد تستعمل فيه هذا البوت لكي تجمع النقاط وتطلب الاعضاء بدلاً من استخدام حسابك الاساسي لئن اذا استعملت حسابك الاساسي في الانضمام للقنوات لكي تجمع النقاط ستتراكم القنوات في حسابك بشكل مزعج لكن بأنشاء حساب جديد تخصصه فقط لهذا العمل فتراكم القنوات لن يزعجك 
✳️ طريقة انشاء حساب تليكرام جديد سهله للغاية فقط شاهد الفيديو 😁🔰",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
[['text'=>"ارسل الفيديو 📥",'callback_data'=>'m3']],
      [['text'=>"رجوع 🔙",'callback_data'=>'panel']],
  	],
	  	'resize_keyboard'=>true,
  	])
  	]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$cuser["userfild"]["$fromid"]["file"]="none";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
if($data=="m3"){
php88 ('editmessagetext',[
        'chat_id'=>$chatid,
     'message_id'=>$messageid,
  	]);
  php88 ('sendvideo',[
        'chat_id'=>$chatid,
     'message_id'=>$messageid,
     'video'=>"https://t.me/kvfyxnh/1140",
     'caption'=>"✳️ بعد ان تحصل على الرقم الامريكي تفتح بي حساب تليكرام سيصل كود التفعيل على البرنامج ( TextNow )

✳️ اضغط على اسم البرنامج للتنزيل 🔰",
  'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
[['text'=>"TextNow 📥",'callback_data'=>'m4']],
      [['text'=>"رجوع 🔙",'callback_data'=>'panel']],
  	],
	  	'resize_keyboard'=>true,
  	])
  	]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$cuser["userfild"]["$fromid"]["file"]="none";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
if($data=="m4"){
php88 ('editmessagetext',[
        'chat_id'=>$chatid,
     'message_id'=>$messageid,
  	]);
  php88 ('sendDocument',[
        'chat_id'=>$chatid,
     'message_id'=>$messageid,
     'document'=>"https://t.me/kvfyxnh/1141",
  	]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$cuser["userfild"]["$fromid"]["file"]="none";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
if($data=="m5"){
$setchannel = $juser["userfild"]["$from_id"]["setchannel"];
php88 ('editmessagetext',[
        'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"الطلب الحالي لهذا القناة يمكنك طلب المزيد او شراء النقود 😉👍

القناة المراد تمويلها : *$setchannel* ",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
      [['text'=>"رجوع 🔙",'callback_data'=>'panel']],
  	],
	  	'resize_keyboard'=>true,
  	])
  	]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$cuser["userfild"]["$fromid"]["file"]="none";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
if($data=="a8"){
$invite = $cuser["userfild"]["$fromid"]["invite"];
$coin = $cuser["userfild"]["$fromid"]["coin"];
$setchannel = $cuser["userfild"]["$fromid"]["setchannel"];
$setmember = $cuser["userfild"]["$fromid"]["setmember"];
php88 ('editmessagetext',[
        'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"نقاطك : $coin 💰
الأنضمام بلقنوات 2 💰💡
مشـاركـة الـرابـط 5 💰🌀
الهدية اليـومية 10 💰🎁
اخر تمويل لك $setchannel 🎗
العدد الذي طلبتة هو $setmember 📥
عداد الرابط الخاص بك $invite
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
• معلومات حسابك الشخصي ؛ 📌'

◾️ الاسم ؛ $firstname
▫️ المعرف ؛ @$usernames
◾️ الايدي ؛ $fromid
➖➖➖➖➖➖➖➖➖➖➖➖",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
      [['text'=>"انضمام بقنوات 💡",'callback_data'=>'takecoin'],['text'=>"مشاركة الرابط Ⓜ️",'callback_data'=>'a5']],
   [['text'=>"شراء نقاط 💰",'url'=>'t.me/EzZzZz'],['text'=>"الهدية اليومية 🎁",'callback_data'=>'a6']],
   [['text'=>"رجوع 🔙",'callback_data'=>'panel']],
  	],
	  	'resize_keyboard'=>true,
  	])
  	]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$cuser["userfild"]["$fromid"]["file"]="none";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}
if($data=="a5"){
	$coin = $cuser["userfild"]["$fromid"]["coin"];
php88 ('editmessagetext',[
        'chat_id'=>$chatid,
     'message_id'=>$messageid,
               'text'=>"قم بمشاركة الرابط الخاص بك وكل شخص جديد يدخل على البوت من خلال رابطك ستحتسب نقطة لك 5 💰

https://t.me/$usernamebot?start=$fromid
 
نقاطك : $coin 💰",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
   [['text'=>"رجوع 🔙",'callback_data'=>'panel']],
  	],
	  	'resize_keyboard'=>true,
  	])
  	]);
$cuser = json_decode(file_get_contents("data/$fromid.json"),true);
$cuser["userfild"]["$fromid"]["file"]="none";
$cuser = json_encode($cuser,true);
file_put_contents("data/$fromid.json",$cuser);
}


 
if(preg_match('/^(@)(.*)/s' , $text, $mtch)){
$PHP88 = json_decode(file_get_contents("http://api.telegram.org/bot".API_KEY."/getChat?chat_id=$text"))->result;
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"
*Name* : *$ch->title*
*ID* : *$PHP88->id*
*User* : @$PHP88->username
*Bio* : *$PHP88->description*
",
'reply_to_message_id'=>$message->message_id,
'disable_web_page_preview'=> true ,
 'parse_mode'=>"Markdown",
]);}


unlink("error_log");
// ملف بوت تمويل ناروكي ؛💡//
//فكره الملف يزيد اعضاء القنوات وقناتك//


?>