<?php 
ob_start();
$API_KEY = "1161426805:AAFshCFMsJgtFtbX3I8v4mp_ZBtnbrYGFv8";#توكن البوت
define('API_KEY',$API_KEY);
echo "<a href='https://api.telegram.org/bot$API_KEY/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']."'>setwebhook</a>";
echo file_get_contents("https://api.telegram.org/bot$API_KEY/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']);
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url); curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{return json_decode($res);}}
#         iKETO BOOS         #
$update   = json_decode(file_get_contents('php://input'));
$message  = $update->message;
$text     = $message->text;
$message_id2 = $update->callback_query->message->message_id;
$chat_id  = $message->chat->id;
$name     = $message->from->first_name;
$user     = $message->from->username;
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
$a = strtolower($text);
$message = $update->message;
$message = $update->message;
$username = $message->from->username;
$message_id2 = $update->callback_query->message->message_id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$Name = $update->callback_query->from->first_name;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$text = $message->text;
$useree = $update->callback_query->message->chat->id;
$username = $message->from->username;
$fn = $message->from->first_name;
$user_id = $message->from->id;
$admin = "1010918290";
$MROAN = file_get_contents("MROAN.txt");
$MROAN0 = file_get_contents("MROAN0.txt");
$MROAN1= file_get_contents("MROAN1.txt");
$MROAN5 = file_get_contents("MROAN2.txt");
$MROAN6 = file_get_contents("MROAN3.txt");
$MROAN20 = json_decode(file_get_contents('php://input'));
$MROAN18 = $update->message;
$MROAN13 = $MROAN18->chat->id;
$MROAN17 = $MROAN18->text;
$MROAN19 = $MROAN20->callback_query->data;
$MROAN12 = $MROAN20->callback_query->message->chat->id;
$MROAN14 =  $MROAN20->callback_query->message->message_id;
$MROAN15 = $MROAN18->from->first_name;
$MROAN16 = $MROAN18->from->username;
$MROAN11 = $MROAN18->from->id;
$MROAN2 = explode("\n",file_get_contents("MROAN4.txt"));
$MROAN3 = count($MROAN2)-1;
if ($MROAN18 && !in_array($MROAN11, $MROAN2)) {
    file_put_contents("MROAN4.txt", $MROAN11."\n",FILE_APPEND);
  }
$MROAN9 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$MROAN0&user_id=".$MROAN11);
$MROAN10 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$MROAN1&user_id=".$MROAN11);
if($MROAN18 && (strpos($MROAN9,'"status":"left"') or strpos($MROAN9,'"Bad Request: USER_ID_INVALID"') or strpos($MROAN9,'"status":"kicked"') or strpos($MROAN10,'"status":"left"') or strpos($MROAN10,'"Bad Request: USER_ID_INVALID"') or strpos($MROAN10,'"status":"kicked"'))!== false){
bot('sendMessage', [
'chat_id'=>$MROAN13,
'text'=>'- ▫️ عذراً عزيزي  ، 🔰
▪️ يجب عليك الإشتراك في قناة المطور أولاً ⚜️؛

- اشترك ثم ارسل { /start }📛!

'.$MROAN0.'
'.$MROAN1,
]);return false;}
if($MROAN17 == "/admin" and $MROAN11 == $admin){
bot("sendmessage",[
"chat_id"=>$MROAN13,
"text"=>"مرحبآ بك ،  [$fn](tg://user?id=$chat_id)
- هذه لوحة التحكم الخاصة بك ، 🔰
- يمكنك التحكم بجميع اوامر البوت من هنا ، 🐬
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
'reply_to_message_id'=>$message->message_id,
 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- أوامر الإشتراك الإجباري الأول ، 📢' ,'callback_data'=>"MROAN"]],
[['text'=>'• وضع قناة ، 🌚🤞🏻' ,'callback_data'=>"MROAN0"],['text'=>'• حذف قناة ، 🌚🤙🏻' ,'callback_data'=>"delete11"]],
[['text'=>'- أوامر الإشتراك الإجباري الثاني ، 📢' ,'callback_data'=>"MROAN"]],
[['text'=>'• وضع قناة ، 🌝🤞🏻' ,'callback_data'=>"MROAN2"],['text'=>'• حذف قناة ، 🌝🤙🏻' ,'callback_data'=>"delete22"]],
[['text'=>'- عرض قنوات الإشتراك ، 📛' ,'callback_data'=>"MROAN4"]],
[['text'=>'- أوامر الإذاعه ، 🗣' ,'callback_data'=>"MROAN"]],
[['text'=>'• رسالة توجيه ، ☝️🏻💚' ,'callback_data'=>"MROAN5"],['text'=>'• رسالة نصية ، ☝️🏻💛' ,'callback_data'=>"MROAN6"]],
[['text'=>'- عدد المشتركين ، 🐳' ,'callback_data'=>"MROAN7"]],
[['text'=>'- التنبيه عند دخول أحد للبوت ، ⚠️' ,'callback_data'=>"MROAN"]],
[['text'=>'• تفعيل التنبيه ، ✅' ,'callback_data'=>"MROAN9"],['text'=>'• تعطيل التنبيه ، ❎' ,'callback_data'=>"MROAN10"]],
[['text'=>'- توجيه رسائل من الأعضاء ، 🔁' ,'callback_data'=>"MROAN"]],
[['text'=>'• تفعيل التوجيه ، ✅' ,'callback_data'=>"MROAN11"],['text'=>'• تعطيل التوجيه ، ❎' ,'callback_data'=>"MROAN12"]],
   ] 
   ])
]);
}
if($MROAN19 == "MROAN" ){
bot('EditMessageText',[
'chat_id'=>$MROAN12,
'message_id'=>$MROAN14,
"text"=>"  • مرحبا بك ، [$Name](tg://user?id=$chat_id2)
- هذه لوحة التحكم الخاصة بك ، 🔰
- يمكنك التحكم بجميع اوامر البوت من هنا ، 🐬
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- أوامر الإشتراك الإجباري الأول ، 📢' ,'callback_data'=>"MROAN"]],
[['text'=>'• وضع قناة ، 🌚🤞🏻' ,'callback_data'=>"MROAN0"],['text'=>'• حذف قناة ، 🌚🤙🏻' ,'callback_data'=>"delete11"]],
[['text'=>'- أوامر الإشتراك الإجباري الثاني ، 📢' ,'callback_data'=>"MROAN"]],
[['text'=>'• وضع قناة ، 🌝🤞🏻' ,'callback_data'=>"MROAN2"],['text'=>'• حذف قناة ، 🌝🤙🏻' ,'callback_data'=>"delete22"]],
[['text'=>'- عرض قنوات الإشتراك ، 📛' ,'callback_data'=>"MROAN4"]],
[['text'=>'- أوامر الإذاعه ، 🗣' ,'callback_data'=>"MROAN"]],
[['text'=>'• رسالة توجيه ، ☝️🏻💚' ,'callback_data'=>"MROAN5"],['text'=>'• رسالة نصية ، ☝️🏻💛' ,'callback_data'=>"MROAN6"]],
[['text'=>'- عدد المشتركين ، 🐳' ,'callback_data'=>"MROAN7"]],
[['text'=>'- التنبيه عند دخول أحد للبوت ، ⚠️' ,'callback_data'=>"MROAN"]],
[['text'=>'• تفعيل التنبيه ، ✅' ,'callback_data'=>"MROAN9"],['text'=>'• تعطيل التنبيه ، ❎' ,'callback_data'=>"MROAN10"]],
[['text'=>'- توجيه رسائل من الأعضاء ، 🔁' ,'callback_data'=>"MROAN"]],
[['text'=>'• تفعيل التوجيه ، ✅' ,'callback_data'=>"MROAN11"],['text'=>'• تعطيل التوجيه ، ❎' ,'callback_data'=>"MROAN12"]],
   ] 
   ])
]);
unlink("MROAN.txt");
}
if($MROAN19 == "MROAN0"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- حسناً ، الآن قم بإرسال معرف قناتك ليتم وضعه في خدمة الإشتراك الإجباري للقناة الأولى ، 📢
#مثال :
▪️@Watan_e',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN.txt","MROAN0");
}
if($MROAN17 and $MROAN == "MROAN0" and $MROAN11 == $admin){
bot("sendmessage",[
"chat_id"=>$MROAN13,
"text"=>'- لقد تم وضع القناة بنجاح ، 📣
- قم برفع البوت أدمن داخل القناة ، 🗞',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN0.txt","$MROAN17");
unlink("MROAN.txt");
}
if($MROAN19 == "delete11"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- حسناً هل أنت متأكد من أنك تريد حذف القناة من الإشتراك الإجباري ، 🚫
',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'• لا ، ❎', 'callback_data'=>'MROAN'],
['text'=>'• نعم ، ✅','callback_data'=>'MROAN1'],
]    
]])
]);    
}
if($MROAN19 == "MROAN1"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- لقد تم حذف القناة الاولى من الإشتراك الإجباري بنجاح ، 📮',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
️[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
unlink("MROAN0.txt");
}
if($MROAN19 == "MROAN2"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- حسناً ، الآن قم بإرسال معرف قناتك ليتم وضعه في خدمة الإشتراك الإجباري للقناة الثانية ، 📢
#مثال :
▪️@Watan_e',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN.txt","MROAN1");
}
if($MROAN17 and $MROAN == "MROAN1" and $MROAN11 == $admin){
bot("sendmessage",[
"chat_id"=>$MROAN13,
"text"=>'- لقد تم وضع القناة بنجاح ، 📣
- قم برفع البوت أدمن داخل القناة ، 🗞',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN1.txt","$MROAN17");
unlink("MROAN.txt");
}
if($MROAN19 == "delete22"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- حسناً هل أنت متأكد من أنك تريد حذف القناة من الإشتراك الإجباري ، 🚫',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'• لا ، ❎', 'callback_data'=>'MROAN'],
['text'=>'• نعم ، ✅','callback_data'=>'MROAN3'],
]    
]])
]);    
}
if($MROAN19 == "MROAN3"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- لقد تم حذف القناة الثانية من الإشتراك الإجباري بنجاح ، 📮',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
unlink("MROAN1.txt");
}
if($MROAN19 == "MROAN4"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>"- هذه قائمة القنوات الأشتراك الاجباري ، 🔰
- القناة الاولى ،  $MROAN0 📢 
- القناة الثانية ،  $MROAN1 📣
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
}
if($MROAN19 == "MROAN5"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>"~ أرسل رسالتك وسيتم توجيهها لـ [ $MROAN3 ] مشترك ، 🐙 ",
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN.txt","MROAN2");
}
if($MROAN18 and $MROAN == "MROAN2" and $MROAN11 == $admin){
bot("sendmessage",[
"chat_id"=>$MROAN13,
"text"=>'- تم التوجيه بنجاح 🦕',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
for($i=0;$i<count($MROAN2); $i++){
bot('forwardMessage', [
'chat_id'=>$MROAN2[$i],
'from_chat_id'=>$MROAN11,
'message_id'=>$MROAN18->message_id
]);
unlink("MROAN.txt");
}
}
if($MROAN19 == "MROAN6"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>"~ أرسل رسالتك وسيتم إرسالها لـ [ $MROAN3 ] مشترك ، 🐠",
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN.txt","MROAN3");
}
if($MROAN17 and $MROAN == "MROAN3" and $MROAN11 == $admin){
bot("sendmessage",[
"chat_id"=>$MROAN13,
"text"=>'- تم النشر بنجاح 🐋',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
for($i=0;$i<count($MROAN2); $i++){
bot('sendMessage', [
'chat_id'=>$MROAN2[$i],
'text'=>$MROAN17
]);
unlink("MROAN.txt");
}
}
if($MROAN19 == "MROAN7"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>"- عدد مشتركين البوت  [ $MROAN3 ] مشترك ، 🦑",
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
}
if($MROAN19 == "MROAN9"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- تم تفعيل دخول المشتركين ، 🐎',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN2.txt","MROAN");
}
if($MROAN17 == "/start" and $MROAN5 == "MROAN" and $MROAN11 != $admin){
bot("sendmessage",[
"chat_id"=>$admin,
"text"=>"- عضو جديد قام بالدخول الى البوت ، 🛡
- الاسم ، [$MROAN15](tg://user?id=$chat_id) ، 🦕
- المعرف ، [@$MROAN16](tg://user?id=$chat_id) ، 🐢
- الايدي ، [$MROAN11](tg://user?id=$chat_id) ، 🐝 
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
~  عدد المشتركين ، { $MROAN3 } ، 🦑 ",
 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
]);
}
if($MROAN19 == "MROAN10"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- تم تعطيل دخول المشتركين ، 🦍 ',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
unlink("MROAN2.txt");
}
if($MROAN19 == "MROAN11"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- تم تفعيل توجيه الرسائل ، 🦇',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
file_put_contents("MROAN3.txt","MROAN");
}
if($MROAN18 and $MROAN6 == "MROAN" and $MROAN11 != $admin){
bot('forwardMessage', [
'chat_id'=>$admin,
'from_chat_id'=>$MROAN11,
'message_id'=>$MROAN18->message_id
]);
}
if($MROAN18 and $MROAN6 == "MROAN" and $MROAN11 == $admin){
bot('sendMessage',[
'chat_id'=>$MROAN18->reply_to_message->forward_from->id,
    'text'=>$MROAN17,
    ]);
}
if($MROAN19 == "MROAN12"){
bot('EditMessageText',[
    'chat_id'=>$MROAN12,
    'message_id'=>$MROAN14,
'text'=>'- تم تعطيل توجيه الرسائل ، 🐌',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'🔙' ,'callback_data'=>"MROAN"]],
]])
]);
unlink("MROAN.txt");
unlink("MROAN3.txt");
}


if ($text == '/start' && !in_array($chat_id, $band)){
    bot('sendMessage',[
        'chat_id'=>$chat_id,
         'text' => "
         • اهلا بك ، [$name](tg://user?id=$chat_id)
في بوت الزخرفة ؛)
- يمكنك الزخرفهہ‏‏ باللغة الانگليزية فقط ، 
-- -- -- -- - -- -- -- -- -- -- -- -- -- 
W𝐄𝐋𝐂𝐎𝐌𝐄 𝐓𝐎 𝐓𝐇𝐄 𝐃𝐄𝐂𝐎𝐑𝐀𝐓𝐈𝐎𝐍 𝐁𝐎𝐓 C𝐇𝐎𝐎𝐒𝐄 𝐖𝐇𝐀𝐓 𝐘𝐎𝐔 𝐖𝐀𝐍𝐓 𝐅𝐑𝐎𝐌 𝐓𝐇𝐄 𝐁𝐎𝐓𝐓𝐎𝐌 𓊴
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
",
'parse_mode' => "MarkDown", 'disable_web_page_preview' => true, 'reply_markup' => json_encode(['inline_keyboard' => [[['text' => "• اضغط هنا وتابع قناة البوت ، 🔰'", 'url' => "https://t.me/TeamKeK"]], ]]) ]);
}
if($_GET['s']){
    $text = 'sssasa';
    echo $count = count($text); 
}
if($text != '/start'and$text!='/us'and$text!='/rmz'and$text!='/admin'){
  $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
     $k = $text; 
   $k = strtolower('a','𝐴',$text); 
 $k = str_replace('b','𝐵',$k); 
 $k = str_replace('c','𝐶',$k); 
 $k = str_replace('d','𝐷',$k); 
 $k = str_replace('e','𝐸',$k); 
 $k = str_replace('f','𝐹',$k); 
 $k = str_replace('g','𝐺',$k); 
 $k = str_replace('h','𝐻',$k); 
 $k = str_replace('i','𝐼',$k); 
 $k = str_replace('j','𝐽',$k); 
 $k = str_replace('k','𝐾',$k); 
 $k = str_replace('l','𝐿',$k); 
 $k = str_replace('m','𝑀',$k); 
 $k = str_replace('n','𝑁',$k); 
 $k = str_replace('o','𝑂',$k); 
 $k = str_replace('p','𝑃',$k); 
 $k = str_replace('q','𝑄',$k); 
 $k = str_replace('r','𝑅',$k); 
 $k = str_replace('s','𝑆',$k); 
 $k = str_replace('t','𝑇',$k); 
 $k = str_replace('u','𝑈',$k); 
 $k = str_replace('v','𝑉',$k); 
 $k = str_replace('w','𝑊',$k); 
 $k = str_replace('x','𝑋',$k); 
 $k = str_replace('y','𝑌',$k); 
 $k = str_replace('z','𝑍',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
     $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
   $k = $text;
$k = str_replace('a','𝐀',$text); 
 $k = str_replace('b','𝐁',$k); 
 $k = str_replace('c','𝐂',$k); 
 $k = str_replace('d','𝐃',$k); 
 $k = str_replace('e','𝐄',$k); 
 $k = str_replace('f','𝐅',$k); 
 $k = str_replace('g','𝐆',$k); 
 $k = str_replace('h','𝐇',$k); 
 $k = str_replace('i','𝐈',$k); 
 $k = str_replace('j','𝐉',$k); 
 $k = str_replace('k','𝐊',$k); 
 $k = str_replace('l','𝐋',$k); 
 $k = str_replace('m','𝐌',$k); 
 $k = str_replace('n','𝐍',$k); 
 $k = str_replace('o','𝐎',$k); 
 $k = str_replace('p','𝐏',$k); 
 $k = str_replace('q','𝐐',$k); 
 $k = str_replace('r','𝐑',$k); 
 $k = str_replace('s','𝐒',$k); 
 $k = str_replace('t','𝐓',$k); 
 $k = str_replace('u','𝐔',$k); 
 $k = str_replace('v','𝐕',$k); 
 $k = str_replace('w','𝐖',$k); 
 $k = str_replace('x','𝐗',$k); 
 $k = str_replace('y','𝐘',$k); 
 $k = str_replace('z','𝐙',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile  
     ]);
       $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
   $k = $text;
$k = str_replace('a','𝐚',$text); 
 $k = str_replace('b','𝐛',$k); 
 $k = str_replace('c','𝐜',$k); 
 $k = str_replace('d','𝐝',$k); 
 $k = str_replace('e','𝐞',$k); 
 $k = str_replace('f','𝐟',$k); 
 $k = str_replace('g','𝐠',$k); 
 $k = str_replace('h','𝐡',$k); 
 $k = str_replace('i','𝐢',$k); 
 $k = str_replace('j','𝐣',$k); 
 $k = str_replace('k','𝐤',$k); 
 $k = str_replace('l','𝐥',$k); 
 $k = str_replace('m','𝐦',$k); 
 $k = str_replace('n','𝐧',$k); 
 $k = str_replace('o','𝐨',$k); 
 $k = str_replace('p','𝐩',$k); 
 $k = str_replace('q','𝐪',$k); 
 $k = str_replace('r','𝐫',$k); 
 $k = str_replace('s','𝐬',$k); 
 $k = str_replace('t','𝐭',$k); 
 $k = str_replace('u','𝐮',$k); 
 $k = str_replace('v','𝐯',$k); 
 $k = str_replace('w','𝐰',$k); 
 $k = str_replace('x','𝐱',$k); 
 $k = str_replace('y','𝐲',$k); 
 $k = str_replace('z','𝐳',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
       ]);
         $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
   $k = $text;
   $k = str_replace('a','𝖆',$text); 
 $k = str_replace('b','𝖇',$k); 
 $k = str_replace('c','𝖈',$k); 
 $k = str_replace('d','𝖉',$k); 
 $k = str_replace('e','𝖊',$k); 
 $k = str_replace('f','𝖋',$k); 
 $k = str_replace('g','𝖌',$k); 
 $k = str_replace('h','𝖍',$k); 
 $k = str_replace('i','𝖎',$k); 
 $k = str_replace('j','𝖏',$k); 
 $k = str_replace('k','𝖐',$k); 
 $k = str_replace('l','𝖑',$k); 
 $k = str_replace('m','𝖒',$k); 
 $k = str_replace('n','𝖓',$k); 
 $k = str_replace('o','𝖔',$k); 
 $k = str_replace('p','𝖕',$k); 
 $k = str_replace('q','𝖖',$k); 
 $k = str_replace('r','𝖗',$k); 
 $k = str_replace('s','𝖘',$k); 
 $k = str_replace('t','𝖙',$k); 
 $k = str_replace('u','𝖚',$k); 
 $k = str_replace('v','𝖛',$k); 
 $k = str_replace('w','𝖜',$k); 
 $k = str_replace('x','𝖝',$k); 
 $k = str_replace('y','𝖞',$k); 
 $k = str_replace('z','𝖟',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
               ]);
                 $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
     $k = $text;
$k = str_replace('a','𝕬',$text); 
 $k = str_replace('b','𝕭',$k); 
 $k = str_replace('c','𝕮',$k); 
 $k = str_replace('d','𝕯',$k); 
 $k = str_replace('e','𝕰',$k); 
 $k = str_replace('f','𝕱',$k); 
 $k = str_replace('g','𝕲',$k); 
 $k = str_replace('h','𝕳',$k); 
 $k = str_replace('i','𝕴',$k); 
 $k = str_replace('j','𝕵',$k); 
 $k = str_replace('k','𝕶',$k); 
 $k = str_replace('l','𝕷',$k); 
 $k = str_replace('m','𝕸',$k); 
 $k = str_replace('n','𝕹',$k); 
 $k = str_replace('o','𝕺',$k); 
 $k = str_replace('p','𝕻',$k); 
 $k = str_replace('q','𝕼',$k); 
 $k = str_replace('r','𝕽',$k); 
 $k = str_replace('s','𝕾',$k); 
 $k = str_replace('t','𝕿',$k); 
 $k = str_replace('u','𝖀',$k); 
 $k = str_replace('v','𝖁',$k); 
 $k = str_replace('w','𝖂',$k); 
 $k = str_replace('x','𝖃',$k); 
 $k = str_replace('y','𝖄',$k); 
 $k = str_replace('z','𝖅',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile 
   ]); 
   $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);  
  $k = $text;
$k = str_replace('a','ᴬ',$text); 
 $k = str_replace('b','ᴮ',$k); 
 $k = str_replace('c','ᶜ',$k); 
 $k = str_replace('d','ᴰ',$k); 
 $k = str_replace('e','ᴱ',$k); 
 $k = str_replace('f','ᶠ',$k); 
 $k = str_replace('g','ᴳ',$k); 
 $k = str_replace('h','ᴴ',$k); 
 $k = str_replace('i','ᴵ',$k); 
 $k = str_replace('j','ᴶ',$k); 
 $k = str_replace('k','ᴷ',$k); 
 $k = str_replace('l','ᴸ',$k); 
 $k = str_replace('m','ᴹ',$k); 
 $k = str_replace('n','ᴺ',$k); 
 $k = str_replace('o','ᴼ',$k); 
 $k = str_replace('p','ᴾ',$k); 
 $k = str_replace('q','ᵟ',$k); 
 $k = str_replace('r','ᴿ',$k); 
 $k = str_replace('s','ˢ',$k); 
 $k = str_replace('t','ᵀ',$k); 
 $k = str_replace('u','ᵿ',$k); 
 $k = str_replace('v','ᵛ',$k); 
 $k = str_replace('w','ᵂ',$k); 
 $k = str_replace('x','ˣ',$k); 
 $k = str_replace('y','ᵞ',$k); 
 $k = str_replace('z','ᶻ',$k);
   bot('sendMessage',[
    'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]);
     $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
   $k = $text;
   $k = str_replace('a','𝚊',$text); 
 $k = str_replace('b','𝚋',$k); 
 $k = str_replace('c','𝚌',$k); 
 $k = str_replace('d','𝚍',$k); 
 $k = str_replace('e','𝚎',$k); 
 $k = str_replace('f','𝚏',$k); 
 $k = str_replace('g','𝚐',$k); 
 $k = str_replace('h','𝚑',$k); 
 $k = str_replace('i','𝚒',$k); 
 $k = str_replace('j','𝚓',$k); 
 $k = str_replace('k','𝚔',$k); 
 $k = str_replace('l','𝚕',$k); 
 $k = str_replace('m','𝚖',$k); 
 $k = str_replace('n','𝚗',$k); 
 $k = str_replace('o','𝚘',$k); 
 $k = str_replace('p','𝚙',$k); 
 $k = str_replace('q','𝚚',$k); 
 $k = str_replace('r','𝚛',$k); 
 $k = str_replace('s','𝚜',$k); 
 $k = str_replace('t','𝚝',$k); 
 $k = str_replace('u','𝚞',$k); 
 $k = str_replace('v','𝚟',$k); 
 $k = str_replace('w','𝚠',$k); 
 $k = str_replace('x','𝚡',$k); 
 $k = str_replace('y','𝚢',$k); 
 $k = str_replace('z','𝚣',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
    ]); 
      $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
      $k = $text;
$k = str_replace('a','𝙰',$text); 
 $k = str_replace('b','𝙱',$k); 
 $k = str_replace('c','𝙲',$k); 
 $k = str_replace('d','𝙳',$k); 
 $k = str_replace('e','𝙴',$k); 
 $k = str_replace('f','𝙵',$k); 
 $k = str_replace('g','𝙶',$k); 
 $k = str_replace('h','𝙷',$k); 
 $k = str_replace('i','𝙸',$k); 
 $k = str_replace('j','𝙹',$k); 
 $k = str_replace('k','𝙺',$k); 
 $k = str_replace('l','𝙻',$k); 
 $k = str_replace('m','𝙼',$k); 
 $k = str_replace('n','𝙽',$k); 
 $k = str_replace('o','𝙾',$k); 
 $k = str_replace('p','𝙿',$k); 
 $k = str_replace('q','𝚀',$k); 
 $k = str_replace('r','𝚁',$k); 
 $k = str_replace('s','𝚂',$k); 
 $k = str_replace('t','𝚃',$k); 
 $k = str_replace('u','𝚄',$k); 
 $k = str_replace('v','𝚅',$k); 
 $k = str_replace('w','𝚆',$k); 
 $k = str_replace('x','𝚇',$k); 
 $k = str_replace('y','𝚈',$k); 
 $k = str_replace('z','𝚉',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile  
     ]); 
       $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
   $k = $text;
$k = str_replace('a','𝒂',$text); 
 $k = str_replace('b','𝒃',$k); 
 $k = str_replace('c','𝒄',$k); 
 $k = str_replace('d','𝒅',$k); 
 $k = str_replace('e','𝒆',$k); 
 $k = str_replace('f','𝒇',$k); 
 $k = str_replace('g','𝒈',$k); 
 $k = str_replace('h','𝒉',$k); 
 $k = str_replace('i','𝒊',$k); 
 $k = str_replace('j','𝒋',$k); 
 $k = str_replace('k','𝒌',$k); 
 $k = str_replace('l','𝒍',$k); 
 $k = str_replace('m','𝒎',$k); 
 $k = str_replace('n','𝒏',$k); 
 $k = str_replace('o','𝒐',$k); 
 $k = str_replace('p','𝒑',$k); 
 $k = str_replace('q','𝒒',$k); 
 $k = str_replace('r','𝒓',$k); 
 $k = str_replace('s','𝒔',$k); 
 $k = str_replace('t','𝒕',$k); 
 $k = str_replace('u','𝒖',$k); 
 $k = str_replace('v','𝒗',$k); 
 $k = str_replace('w','𝒘',$k); 
 $k = str_replace('x','𝒙',$k); 
 $k = str_replace('y','𝒚',$k); 
 $k = str_replace('z','𝒛',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
             ]);   
               $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
          $k = $text;
$k = str_replace('a','𝑨',$text); 
 $k = str_replace('b','𝑩',$k); 
 $k = str_replace('c','𝑪',$k); 
 $k = str_replace('d','𝑫',$k); 
 $k = str_replace('e','𝑬',$k); 
 $k = str_replace('f','𝑭',$k); 
 $k = str_replace('g','𝑮',$k); 
 $k = str_replace('h','𝑯',$k); 
 $k = str_replace('i','𝑰',$k); 
 $k = str_replace('j','𝑱',$k); 
 $k = str_replace('k','𝑲',$k); 
 $k = str_replace('l','𝑳',$k); 
 $k = str_replace('m','𝑴',$k); 
 $k = str_replace('n','𝑵',$k); 
 $k = str_replace('o','𝑶',$k); 
 $k = str_replace('p','𝑷',$k); 
 $k = str_replace('q','𝑸',$k); 
 $k = str_replace('r','𝑹',$k); 
 $k = str_replace('s','𝑺',$k); 
 $k = str_replace('t','𝑻',$k); 
 $k = str_replace('u','𝑼',$k); 
 $k = str_replace('v','𝑽',$k); 
 $k = str_replace('w','𝑾',$k); 
 $k = str_replace('x','𝑿',$k); 
 $k = str_replace('y','𝒀',$k); 
 $k = str_replace('z','𝒁',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile  
     ]); 
       $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
$k = $text;
$k = str_replace('a','𝑎',$text); 
 $k = str_replace('b','𝑏',$k); 
 $k = str_replace('c','𝑐',$k); 
 $k = str_replace('d','𝑑',$k); 
 $k = str_replace('e','𝑒',$k); 
 $k = str_replace('f','𝑓',$k); 
 $k = str_replace('g','𝑔',$k); 
 $k = str_replace('h','ℎ',$k); 
 $k = str_replace('i','𝑖',$k); 
 $k = str_replace('j','𝑗',$k); 
 $k = str_replace('k','𝑘',$k); 
 $k = str_replace('l','𝑙',$k); 
 $k = str_replace('m','𝑚',$k); 
 $k = str_replace('n','𝑛',$k); 
 $k = str_replace('o','𝑜',$k); 
 $k = str_replace('p','𝑝',$k); 
 $k = str_replace('q','𝑞',$k); 
 $k = str_replace('r','𝑟',$k); 
 $k = str_replace('s','𝑠',$k); 
 $k = str_replace('t','𝑡',$k); 
 $k = str_replace('u','𝑢',$k); 
 $k = str_replace('v','𝑣',$k); 
 $k = str_replace('w','𝑤',$k); 
 $k = str_replace('x','𝑥',$k); 
 $k = str_replace('y','𝑦',$k); 
 $k = str_replace('z','𝑧',$k);
   bot('sendMessage',[
    'chat_id'=>$chat_id,
      'text'=>$k." ".$smile
     ]);  
  $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);  
$k = str_replace('a','𝐴',$text); 
 $k = str_replace('b','𝐵',$k); 
 $k = str_replace('c','𝐶',$k); 
 $k = str_replace('d','𝐷',$k); 
 $k = str_replace('e','𝐸',$k); 
 $k = str_replace('f','𝐹',$k); 
 $k = str_replace('g','𝐺',$k); 
 $k = str_replace('h','𝐻',$k); 
 $k = str_replace('i','𝐼',$k); 
 $k = str_replace('j','𝐽',$k); 
 $k = str_replace('k','𝐾',$k); 
 $k = str_replace('l','𝐿',$k); 
 $k = str_replace('m','𝑀',$k); 
 $k = str_replace('n','𝑁',$k); 
 $k = str_replace('o','𝑂',$k); 
 $k = str_replace('p','𝑃',$k); 
 $k = str_replace('q','𝑄',$k); 
 $k = str_replace('r','𝑅',$k); 
 $k = str_replace('s','𝑆',$k); 
 $k = str_replace('t','𝑇',$k); 
 $k = str_replace('u','𝑈',$k); 
 $k = str_replace('v','𝑉',$k); 
 $k = str_replace('w','𝑊',$k); 
 $k = str_replace('x','𝑋',$k); 
 $k = str_replace('y','𝑌',$k); 
 $k = str_replace('z','𝑍',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile  
         ]);
           $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
        $k = $text;
$k = str_replace('a','𝗮',$text); 
 $k = str_replace('b','𝗯',$k); 
 $k = str_replace('c','𝗰',$k); 
 $k = str_replace('d','𝗱',$k); 
 $k = str_replace('e','𝗲',$k); 
 $k = str_replace('f','𝗳',$k); 
 $k = str_replace('g','𝗴',$k); 
 $k = str_replace('h','𝗵',$k); 
 $k = str_replace('i','𝗶',$k); 
 $k = str_replace('j','𝗷',$k); 
 $k = str_replace('k','𝗸',$k); 
 $k = str_replace('l','𝗹',$k); 
 $k = str_replace('m','𝗺',$k); 
 $k = str_replace('n','𝗻',$k); 
 $k = str_replace('o','𝗼',$k); 
 $k = str_replace('p','𝗽',$k); 
 $k = str_replace('q','𝗾',$k); 
 $k = str_replace('r','𝗿',$k); 
 $k = str_replace('s','𝘀',$k); 
 $k = str_replace('t','𝘁',$k); 
 $k = str_replace('u','𝘂',$k); 
 $k = str_replace('v','𝘃',$k); 
 $k = str_replace('w','𝘄',$k); 
 $k = str_replace('x','𝘅',$k); 
 $k = str_replace('y','𝘆',$k); 
 $k = str_replace('z','𝘇',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile        
        ]);
          $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
        $k = $text;
$k = str_replace('a','𝗔',$text); 
 $k = str_replace('b','𝗕',$k); 
 $k = str_replace('c','𝗖',$k); 
 $k = str_replace('d','𝗗',$k); 
 $k = str_replace('e','𝗘',$k); 
 $k = str_replace('f','𝗙',$k); 
 $k = str_replace('g','𝗚',$k); 
 $k = str_replace('h','𝗛',$k); 
 $k = str_replace('i','𝗜',$k); 
 $k = str_replace('j','𝗝',$k); 
 $k = str_replace('k','𝗞',$k); 
 $k = str_replace('l','𝗟',$k); 
 $k = str_replace('m','𝗠',$k); 
 $k = str_replace('n','𝗡',$k); 
 $k = str_replace('o','𝗢',$k); 
 $k = str_replace('p','𝗣',$k); 
 $k = str_replace('q','𝗤',$k); 
 $k = str_replace('r','𝗥',$k); 
 $k = str_replace('s','𝗦',$k); 
 $k = str_replace('t','𝗧',$k); 
 $k = str_replace('u','𝗨',$k); 
 $k = str_replace('v','𝗩',$k); 
 $k = str_replace('w','𝗪',$k); 
 $k = str_replace('x','𝗫',$k); 
 $k = str_replace('y','𝗬',$k); 
 $k = str_replace('z','𝗭',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
        ]);
          $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
   $k = $text;
$k = str_replace('a','𝓐',$text); 
 $k = str_replace('b','𝓑',$k); 
 $k = str_replace('c','𝓒',$k); 
 $k = str_replace('d','𝓓',$k); 
 $k = str_replace('e','𝓔',$k); 
 $k = str_replace('f','𝓕',$k); 
 $k = str_replace('g','𝓖',$k); 
 $k = str_replace('h','𝓗',$k); 
 $k = str_replace('i','𝓘',$k); 
 $k = str_replace('j','𝓙',$k); 
 $k = str_replace('k','𝓚',$k); 
 $k = str_replace('l','𝓛',$k); 
 $k = str_replace('m','𝓜',$k); 
 $k = str_replace('n','𝓝',$k); 
 $k = str_replace('o','𝓞',$k); 
 $k = str_replace('p','𝓟',$k); 
 $k = str_replace('q','𝓠',$k); 
 $k = str_replace('r','𝓡',$k); 
 $k = str_replace('s','𝓢',$k); 
 $k = str_replace('t','𝓣',$k); 
 $k = str_replace('u','𝓤',$k); 
 $k = str_replace('v','𝓥',$k); 
 $k = str_replace('w','𝓦',$k); 
 $k = str_replace('x','𝓧',$k); 
 $k = str_replace('y','𝓨',$k); 
 $k = str_replace('z','𝓩',$k);
   bot('sendMessage',[
    'chat_id'=>$chat_id,
      'text'=>$k." ".$smile
           ]);
             $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
        $k = $text;
$k = str_replace('a','𝒶',$text); 
 $k = str_replace('b','𝒷',$k); 
 $k = str_replace('c','𝒸',$k); 
 $k = str_replace('d','𝒹',$k); 
 $k = str_replace('e','ℯ',$k); 
 $k = str_replace('f','𝒻',$k); 
 $k = str_replace('g','ℊ',$k); 
 $k = str_replace('h','𝒽',$k); 
 $k = str_replace('i','𝒾',$k); 
 $k = str_replace('j','𝒿',$k); 
 $k = str_replace('k','𝓀',$k); 
 $k = str_replace('l','𝓁',$k); 
 $k = str_replace('m','𝓂',$k); 
 $k = str_replace('n','𝓃',$k); 
 $k = str_replace('o','ℴ',$k); 
 $k = str_replace('p','𝓅',$k); 
 $k = str_replace('q','𝓆',$k); 
 $k = str_replace('r','𝓇',$k); 
 $k = str_replace('s','𝓈',$k); 
 $k = str_replace('t','𝓉',$k); 
 $k = str_replace('u','𝓊',$k); 
 $k = str_replace('v','𝓋',$k); 
 $k = str_replace('w','𝓌',$k); 
 $k = str_replace('x','𝓍',$k); 
 $k = str_replace('y','𝓎',$k); 
 $k = str_replace('z','𝓏',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile   
              ]);
        $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);         
        $k = $text;
$k = str_replace('a','ᗩ',$text); 
 $k = str_replace('b','ᗷ',$k); 
 $k = str_replace('c','ᑕ',$k); 
 $k = str_replace('d','ᗪ',$k); 
 $k = str_replace('e','ᗴ',$k); 
 $k = str_replace('f','ᖴ',$k); 
 $k = str_replace('g','ᘜ',$k); 
 $k = str_replace('h','ᕼ',$k); 
 $k = str_replace('i','I',$k); 
 $k = str_replace('j','ᒍ',$k); 
 $k = str_replace('k','K',$k); 
 $k = str_replace('l','ᒪ',$k); 
 $k = str_replace('m','ᗰ',$k); 
 $k = str_replace('n','ᑎ',$k); 
 $k = str_replace('o','O',$k); 
 $k = str_replace('p','ᑭ',$k); 
 $k = str_replace('q','ᑫ',$k); 
 $k = str_replace('r','ᖇ',$k); 
 $k = str_replace('s','Տ',$k); 
 $k = str_replace('t','T',$k); 
 $k = str_replace('u','ᑌ',$k); 
 $k = str_replace('v','ᐯ',$k); 
 $k = str_replace('w','ᗯ',$k); 
 $k = str_replace('x','᙭',$k); 
 $k = str_replace('y','Y',$k); 
 $k = str_replace('z','ᘔ',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
          ]);
            $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
        $k = $text;
$k = str_replace('a','𝕒',$text); 
 $k = str_replace('b','𝕓',$k); 
 $k = str_replace('c','𝕔',$k); 
 $k = str_replace('d','𝕕',$k); 
 $k = str_replace('e','𝕖',$k); 
 $k = str_replace('f','𝕗',$k); 
 $k = str_replace('g','𝕘',$k); 
 $k = str_replace('h','𝕙',$k); 
 $k = str_replace('i','𝕚',$k); 
 $k = str_replace('j','𝕛',$k); 
 $k = str_replace('k','𝕜',$k); 
 $k = str_replace('l','𝕝',$k); 
 $k = str_replace('m','𝕞',$k); 
 $k = str_replace('n','𝕟',$k); 
 $k = str_replace('o','𝕠',$k); 
 $k = str_replace('p','𝕡',$k); 
 $k = str_replace('q','𝕢',$k); 
 $k = str_replace('r','𝕣',$k); 
 $k = str_replace('s','𝕤',$k); 
 $k = str_replace('t','𝕥',$k); 
 $k = str_replace('u','𝕦',$k); 
 $k = str_replace('v','𝕧',$k); 
 $k = str_replace('w','𝕨',$k); 
 $k = str_replace('x','𝕩',$k); 
 $k = str_replace('y','𝕪',$k); 
 $k = str_replace('z','𝕫',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
         ]);
     $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text);       
        $k = $text;
$k = str_replace('a','𝔸',$text); 
 $k = str_replace('b','𝔹',$k); 
 $k = str_replace('c','ℂ',$k); 
 $k = str_replace('d','𝔻',$k); 
 $k = str_replace('e','𝔼',$k); 
 $k = str_replace('f','𝔽',$k); 
 $k = str_replace('g','𝔾',$k); 
 $k = str_replace('h','ℍ',$k); 
 $k = str_replace('i','𝕀',$k); 
 $k = str_replace('j','𝕁',$k); 
 $k = str_replace('k','𝕂',$k); 
 $k = str_replace('l','𝕃',$k); 
 $k = str_replace('m','𝕄',$k); 
 $k = str_replace('n','ℕ',$k); 
 $k = str_replace('o','𝕆',$k); 
 $k = str_replace('p','ℙ',$k); 
 $k = str_replace('q','ℚ',$k); 
 $k = str_replace('r','ℝ',$k); 
 $k = str_replace('s','𝕊',$k); 
 $k = str_replace('t','𝕋',$k); 
 $k = str_replace('u','𝕌',$k); 
 $k = str_replace('v','𝕍',$k); 
 $k = str_replace('w','𝕎',$k); 
 $k = str_replace('x','𝕏',$k); 
 $k = str_replace('y','𝕐',$k); 
 $k = str_replace('z','ℤ',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile       
  ]);
   
$data = $update->callback_query->data;
$chat_id2 = $update->callback_query->message->chat->id;
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"تمت زخرفهہ‏‏ اسمكك بنجاح ♥🌝",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"- الـرمـوز ☽ -",'callback_data' =>"rmz"]],
],
])
]);
}
if($data =="rmz"){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"
𝟏 𝟐 𝟑 𝟒 𝟓 𝟔 𝟕 𝟖 𝟗 𝟎 🇮🇶 ﷼ ﷻ ﷽ ✞ ッ ッ 彡 Ω ۞ ۩ ✟ 『  』۝ Ξ 道 凸 父 个 ¤ 品 〠 ๛ 𖤍 ᶠᶸᶜᵏᵧₒᵤ ࿐ ⍆ ⍅ ⇭ ༒   𖠃 𖠅 𖠆 𖠊 𖡒 𖡗 𖣩 ꧁ ꧂  〰 𖥓 𖥏 𖥎 𖥌 𖥋 𖥊 𖥈 𖥅 𖥃 𖥂 𖥀 𖤼 𖤹 𖤸 𖤷 𖤶 𖤭 𖤫 𖤪 𖤨 𖤧 𖤥 𖤤 𖤣 𖤢 𖤡 𖤟 𖤞 𖤝 𖤜 𖤛 𖤚 𖤘 𖤙 𖤗 𖤕 𖤓 𖤒 𖤐 ဏ ࿘ ࿗ ࿖ ࿕ ࿑ ࿌ ࿋ ࿊ ࿉ ࿈ ࿇ ࿅ ࿄ ࿃ ࿂ ༼ ༽ ༺ ༻ ༗ ༖ ༕ ⏝ ⏜ ⏎ ၄ ߷ ܛ ׀
𖠀 𖠁 𖠂 𖠅 𖠆 𖠇 𖠈 𖠉 𖠍 𖠎 𖠏 𖠐 𖠑 𖠒 𖠓 𖠔 𖠕 𖠖 𖠗 𖠘 𖠙 𖠚 𖠛 𖠜 𖠝 𖠞 𖠟 𖠠 𖠡 𖠢 𖠣 𖠤 𖠥 𖠦 𖠧 𖠨 𖠩 𖠪 𖠫 𖠬 𖠭 𖠮 𖠯 𖠰 𖠱 𖠲 𖠳 𖠴 𖠵 𖠶 𖠷 𖠸 𖠹 𖠺 𖠻 𖠼 𖠽 𖠾 𖠿 𖡀 𖡁 𖡂 𖡃 𖡄 𖡅 𖡆 𖡇 𖡈 𖡉 𖡊 𖡋 𖡌 𖡍 𖡎 𖡏 𖡐 𖡑 𖡒 𖡓 𖡔 𖡕 𖡖 𖡗 𖡘 𖡙 𖡚 𖡛 𖡜 𖡝 𖡞 𖡟 𖡠 𖡡 𖡢 𖡣 𖡤 𖡥 𖡦 𖡧 𖡨 𖡩 𖡪 𖡫 𖡬 𖡭 𖡮 𖡯 𖡰 𖡱 𖡲 𖡳 𖡴 𖡵 𖡶 𖡷 𖡸 𖡹 𖡺 𖡻 𖡼 𖡽 𖡾 𖡿 𖢀 𖢁 𖢂 𖢃 𖢄 𖢅 𖢆 𖢇 𖢈 𖢉 𖢊 𖢋 𖢌 𖢍 𖢎 𖢏 𖢐 𖢑 𖢒 𖢓 𖢔 𖢕 𖢖 𖢗 𖢘 𖢙 𖢚 𖢛 𖢜 𖢝 𖢞 𖢟 𖢠 𖢡 𖢢 𖢣 𖢤 𖢥 𖢦 𖢧 𖢨 𖢩 𖢪 𖢫 𖢬 𖢭 𖢮 𖢯 𖢰 𖢱 𖢲 𖢳 𖢴 𖢵 𖢶 𖢷 𖢸 𖢹 𖢺 𖢻 𖢼 𖢽 𖢾 𖢿 𖣀 𖣁 𖣂 𖣃 𖣄 𖣅 𖣆 𖣇 𖣈 𖣉 𖣊 𖣋 𖣌 𖣍 𖣎 𖣏 𖣐 𖣑 𖣒 𖣓 ?? 𖣕 𖣖 𖣗 𖣘 𖣙 ?? 𖣛 𖣜 𖣝 𖣞 𖣟 𖣠 𖣡 𖣢 𖣣 𖣤 𖣥 𖣦 𖣧 𖣨 𖣩 𖣪 𖣫 𖣬 𖣭 𖣮 𖣯 𖣰 𖣱 𖣲 𖣳 𖣴 𖣵 𖣶 𖣷 𖣸 𖣹 𖣺 𖣻 𖣼 𖣽 𖣾 𖣿 ᪥︎ ✯︎ 𖣔︎𖧷︎ ߷︎ ༆︎ ༄︎ Ꙭ︎ ⁂︎ ⌘︎☼︎ 𖦹︎ ۞︎ ⍟︎ 𖣘︎ 𓇽︎ 𖦹︎ ❁︎ ᯾︎ ★︎ ☆︎ ✫︎ ✰︎ ᯽︎ ✪︎ 𒊹︎ 𓂸︎ 𓂺︎ ☾︎ ☽︎ ♫︎ ➪︎ ✞︎ シ︎ ㋛︎ ♡︎ ❦︎ ❥︎ ఌ︎ ꨄ︎ 𖨆︎ ᴥ︎ ☹︎ ☻︎ 𑁍︎ ✔︎ ☏︎𓆉︎ ⌫︎ 𓂀︎ 𓁹︎ 𐂂︎ 𐂃︎ 𐂊︎ ଈ︎ 
———————×———————
 𝟢 𝟣 𝟤 𝟥 𝟦 𝟧 𝟨 𝟩 𝟪 𝟫 
 𝟶 𝟷 𝟸 𝟹 𝟺 𝟻 𝟼 𝟽 𝟾  𝟿
 𝟘 𝟙  𝟚  𝟛  𝟜  𝟝 𝟞 𝟟  𝟠 𝟡
 𝟎  𝟏  𝟐  𝟑  𝟒  𝟓  𝟔  𝟕  𝟖  𝟗
０ １ ２ ３ ４ ５ ６ ７８９
———————×——————— 
- @TeamKeK ♥
",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
 'inline_keyboard'=>[
[['text'=>"• رجوع •",'callback_data' =>"home"]],
],
])
]);
if($data =="home"){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"   
اهلا بك ،
بـوت الزخرفهہ‏‏ التمبلر 🍭😻
- يمكنك الزخرفهہ‏‏ باللغة الانگليزية فقط ، 
-- -- -- -- - -- -- -- -- -- -- -- -- -- 
𝐖𝐄𝐋𝐂𝐎𝐌𝐄 𝐓𝐎 𝐓𝐇𝐄 𝐃𝐄𝐂𝐎𝐑𝐀𝐓𝐈𝐎𝐍 𝐁𝐎𝐓 C𝐇𝐎𝐎𝐒𝐄 𝐖𝐇𝐀𝐓 𝐘𝐎𝐔 𝐖𝐀𝐍𝐓 𝐅𝐑𝐎𝐌 𝐓𝐇𝐄 𝐁𝐎𝐓𝐓𝐎𝐌 𓊴
", 
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
 'inline_keyboard'=>[
 [['text'=>"• مـطور الـبوت ༆︎ •", 'url'=>'https://t.me/EzZzZz']],[['text'=>"• قـناة الـبـوت 😻 •", 'url'=>'https://t.me/TeamKeK']]
],
])
]); 
} 
} 