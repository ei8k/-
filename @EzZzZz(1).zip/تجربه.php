<?php  

ob_start(); 

$marcus = "998817210:AAGsEHNVKga3nSc_fzLazgPb6Tz7axBnGbA"; #توكن البوت 

define('API_KEY',$marcus);

echo file_get_contents($Calltele . API_KEY . $webhook . $_SERVER['SERVER_NAME'] . "" . $_SERVER['SCRIPT_NAME']);

function bot($method,$datas=[]){
 
$Calltele ='https://api.telegram.org/bot';

$webhook = '/setwebhook?url=';

$http = http_build_query($datas);

$S = "/";// http_build_return($datas);

$url = $Calltele . API_KEY.$S.$method."?$http";

$http = file_get_contents($url);

return json_decode($http);

if ($text == "/start"){
bot ('SendMessage', [ 
'chat_id' =>$chat_id,
'اهلا بك يا $name في بوت ستوريات انستا ♥🤭'
     
       ]); 
}
        