<?php 
ob_start();
$Marcus = "1375432595:AAEOlTzPN4jK8PtKMzv_gQrzLQ_NGWs8ZOc";
define('API_KEY',$Marcus);
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url); curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}
else
{
return json_decode($res);
}
}

function save($array){
    file_put_contents('marcus.json', json_encode($array));
}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$id = $message->from->id;
$m3rf = "TI7BOT";
$aso = 1010918290;
$admin = 1010918290;
$baageel = -1001461095777; 
$chm = "TeamKeK";
$chat_id = $message->chat->id;
$text = $message->text;
$gg = file_get_contents("onn.txt");
if($gg == "on" && $chat_id != $sudo){
$name = $message->from->first_name;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id2 = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$name = $message->from->first_name;
$user = $message->from->username;
$from_id = $message->from->id;
$tws = file_get_contents("tw.txt");
$admin2 = file_get_contents("admin2.txt");
$ad = array("$admin","$admin2");
$list = file_get_contents("blocklist.txt");
$ebu = explode("\n",$list);
if(in_array($from_id,$ebu)){
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"⛳| عزيزي انت محظور من البوت",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);    
}
#التخزين ايديات
$from_id = $message->from->id;
mkdir("g");
if(isset($message)){
$al = file_get_contents('g.txt');
$alo = explode("\n",$al);
if(!in_array($from_id,$alo)){
$g2 = fopen("g.txt", "a") or die("Unable to open file!");
fwrite($g2, "$from_id\n");
fclose($g2);}}
$sta = file_get_contents("start.txt");

$user = $message->from->username;
if(isset($update->callback_query)){
  $chat_id = $update->callback_query->message->chat->id;
  $message_id = $update->callback_query->message->message_id;
  $data     = $update->callback_query->data;
 $user = $update->callback_query->from->username;
}
$admin =$aso ;
$me = bot('getme',['bot'])->result->username;
$sales = json_decode(file_get_contents('marcus.json'),1);
if($chat_id == $admin){
 if($text == '/admin'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
   'text'=>"- مرحباً عزيزي المطور ( @$user ) 🔥.",
   'reply_markup'=>json_encode([
     'inline_keyboard'=>[
       [['text'=>'- اضف عرض ، 💸','callback_data'=>'add']],
       [['text'=>' - حذف عرض 🗑، ','callback_data'=>'del']]
      ]
    ])
  ]);
  $sales['mode'] = null;
  save($sales);
 }
 if($data == 'add'){
  bot('editMessageText',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    'text'=>'• قم بأرسال اسم العرض ، 📬',
    'reply_markup'=>json_encode([
     'inline_keyboard'=>[
[['text'=>"الغاء الامر❎",'callback_data'=>"sales"]],
]
])
]);
  $sales['mode'] = 'add';
  save($sales);
  exit;
 }
 if($text != '/start' and $text != null and $sales['mode'] == 'add'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
   'text'=>'تم الحفظ ✅. 
~ الان ارسل عدد النقاط ( السعر ) المطلوبة للشراء ، 💸 ... رقم فقط '
  ]);
  $sales['n'] = $text;
  $sales['mode'] = 'addm';
  save($sales);
  exit;
 }
 if($text != '/start' and $text != null and $sales['mode'] == 'addm'){
  $code = substr(str_shuffle('abcdefghijklmnopqrstuvwxyz12345689807'),1,7);
  bot('sendMessage',[
   'chat_id'=>$chat_id,
   'text'=>'

 ~ تم حفظ هذه السلعة بنجاح ، 📃
- اسم السلعة 🔭 :  '.$sales['n'].'
- سعر السلعة 💵 : '.$text.'
- كود السلعة 📠 : '.$code
]);
  
  $sales['sales'][$code]['name'] = $sales['n'];
  $sales['sales'][$code]['price'] = $text;
  $sales['n'] = null;
  $sales['mode'] = null;
  save($sales);
  exit;
 }
elseif($data == 'ww'){
  $reply_markup = [];
  $reply_markup['inline_keyboard'][] = [['text'=>'- السعر ، 💵 ','callback_data'=>'s'],['text'=>'️- الاسم ، 🏷  ','callback_data'=>'s']];
  foreach($sales['sales'] as $code => $sale){
   $reply_markup['inline_keyboard'][] = [['text'=>$sale['price'],'callback_data'=>$code],['text'=>$sale['name'],'callback_data'=>$code]];
  }
  $reply_markup['inline_keyboard'][] = [['text'=>'- رجوع ، 🔙','callback_data'=>'c']];
  $reply_markup = json_encode($reply_markup);
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
~ آهلا وسهلآ بك عزيزي المطور ، 🗜

- هذه لوحة العروض 🛠.

- التي تم اضافتها ⚖.
",
'reply_markup'=>($reply_markup)
  ]);
  $sales[$chat_id]['mode'] = null;
   save($sales);
   exit;
 }
 if($data == 'del'){
  bot('editMessageText',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    'text'=>'• قم بأرسال كود العرض ، 📬',
    'reply_markup'=>json_encode([
     'inline_keyboard'=>[
      [['text'=>'- الغاء ،🛠️\'','callback_data'=>'sales']] 
      ]
    ])
  ]);
  $sales['mode'] = 'del';
  save($sales);
  exit;
 }
 if($text != '/start' and $text != null and $sales['mode'] == 'del'){
  if($sales['sales'][$text] != null){
   bot('sendMessage',[
   'chat_id'=>$chat_id,
   'text'=>'تم حذف العرض ✅. 
   ℹ️┇الاسم : '.$sales['sales'][$text]['name'].'
💵┇السعر : '.$sales['sales'][$text]['price'].'
⛓┇كود العرض : '.$text
  ]);
  unset($sales['sales'][$text]);
  $sales['mode'] = null;
  save($sales);
  exit;
  } else {
   bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>'- الكود الذي ارسلته غير موجود 🚫!'
   ]);
  }
 }
} else {
 if(preg_match('/\/(start)(.*)/', $text)){
  $ex = explode(' ', $text);
  if(isset($ex[1])){
   if(!in_array($chat_id, $sales[$chat_id]['id'])){
    $sales[$ex[1]]['collect'] += 1;
    save($sales);
    bot('sendMessage',[
     'chat_id'=>$ex[1] ,
     'text'=>"
     🔘 لقد قام بالدخول الى الرابط الخاص بك : 
💰 : حصلت على نقطة واحدة 

▪ايدي الشخص : [$chat_id](tg://user?id=$chat_id)
▪عدد نقاطك الان : ".$sales[$ex[1]]['collect'], 

 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
    ]);
    $sales[$chat_id]['id'][] = $chat_id;
    save($sales);
   }
  }
   exit();
  }
  if($sales[$chat_id]['collect'] == null){
   $sales[$chat_id]['collect'] = 0;
   save($sales);
  }
  bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>'
👋🏻 | اهلا بك يا عزيزي

📋 | البوت متخصص لـ بيع العروض المتقدمة من البوت عن طريق تجميع النقاط 💸 ، 

 🔄 | قم بتجميع النقاط و اشتري العرض الذي يعجبك 👌🏻 ، 

• عدد نقاطك الان 💸 :  '.$sales[$chat_id]['collect'],
 'parse_mode'=>"MarkDown",
 'reply_markup'=>json_encode([
    'inline_keyboard'=>[
 
 [['text'=>"العروض المدفوعـة ،🖨",'callback_data'=>"sales"],['text'=>"تجميع نقاط ،💰",'callback_data'=>"col"]],
     [['text'=>"شرح البوت ، 🎥",'callback_data'=>"mysend"]],
[['text'=>"شـراء نقاط ،🛍",'callback_data'=>"sho"],['text'=>"مراسلة المطور ،📬",'callback_data'=>"to"]],[['text'=>'تابع جديدنا من فضلك ،🧸','url'=>'https://t.me/$chm']],
    ] 
   ])
  ]);
 }
   if($data == 'back'){
  bot('editMessageText',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    'text'=>'
👋🏻 | اهلا بك يا عزيزي 

📋 | البوت متخصص لـ بيع العروض المتقدمة من البوت عن طريق تجميع النقاط 💸 ، 

 🔄 | قم بتجميع النقاط و اشتري العرض الذي يعجبك 👌🏻 ، 

• عدد نقاطك الان 💸 :  '.$sales[$chat_id]['collect'],
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
 
 [['text'=>"العروض المدفوعـة ،🖨",'callback_data'=>"sales"],['text'=>"تجميع نقاط ،💰",'callback_data'=>"col"]],
     [['text'=>"شرح البوت ، 🎥",'callback_data'=>"mysend"]],
[['text'=>"شـراء نقاط ،🛍",'callback_data'=>"sho"],['text'=>"مراسلة المطور ،📬",'callback_data'=>"to"]],[['text'=>'تابع جديدنا من فضلك ،🧸','url'=>'https://t.me/$chm']],
    ] 
   ])
  ]);
 }
  if($data == "to"){
    bot('deleteMessage',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    ]);
    bot('SendMessage',[
'chat_id'=>$chat_id,
        'text'=>" 
👋🏻| اهلا بك عزيزي

📋 | ارسل رسالتك كـ{صورة ، فيديو ، ملف ، رسالة صوتية ، الخ ... } ☑️

📨 | و سوف يتم ارسالها للمطور
",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[['text'=>"القائمة الرئيسية 🔙",'callback_data'=>"back"]],
]])
]);   
}
if($data == "mysend"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
عزيزي لـ تعلم كيف استخدام البوت انقر اسفل 📃♥️
",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>"الخطوة الأولى",'callback_data'=>"k1"],['text'=>" القائمة الرئيسية 🔙",'callback_data'=>"back"]],
    ] 
   ])
  ]);
 }
if($data == "k1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
بعد الدخول للبوت إضغط على زر تجميع النقاط وبعدها سيرسل البوت لك رابط خاص بك فقط قم بنسخه و نشره و أي شخص يدخل على الرابط تحصل على 1 نقطة
",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>"الخطوة الثانية",'callback_data'=>"k2"],['text'=>" القائمة الرئيسية 🔙",'callback_data'=>"back"]],
    ] 
   ])
  ]);
 }
if($data == "k2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
بعد جمع عدد جيد من النقاط إضغط على زر العروض المدفوعة وبعدها اختر من قائمه الموجوده { يجب أن يتوافق سعر العرض مع نقاطك } و من ثم اضغط تأكيد
لـ شراء العرض او الغاء 
",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>"الخطوة الثالثة",'callback_data'=>"k3"],['text'=>" القائمة الرئيسية 🔙",'callback_data'=>"back"]],
    ] 
   ])
  ]);
 }
if($data == "k3"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
سوف يصل لنا طلبك يجب عليك مراسلت المطور لـ اعطائك العرض
♥️📜
",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>"لا أستطيع جمع النقاط",'callback_data'=>"k4"],['text'=>" القائمة الرئيسية 🔙",'callback_data'=>"back"]],
    ] 
   ])
  ]);
 }
if($data == "k4"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
إذا لا تستطيع جمع النقاط يمكنك شراؤها...💸
",
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>"شراء نقاط 💸",'callback_data'=>"sho"],['text'=>" القائمة الرئيسية 🔙",'callback_data'=>"back"]],
    ] 
   ])
  ]);
 }

  if($data == "sho"){
    bot('deleteMessage',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    ]);
    bot('SendMessage',[
'chat_id'=>$chat_id,
        'text'=>" 
• مرحبا بك في قسم شراء النقاط 🗞️
• لـ شـراء الـنـقـاط ،،⬇️
• طرق الدفع { اسيا ، اثير ، كوكل }

10 نقطة === 2$  💸
20 نقطة === 4$ 💸
30 نقطة === 6$ 💸
40 نقطة === 8$ 💸
50 نقطة === 10$ 💸
60 نقطة === 12$ 💸
100 نقطة === 20$ 💸
",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"للشراء و التواصل ، 💬","url"=>"t.me/EzZzZz"]],
[['text'=>"القائمة الرئيسية 🔙",'callback_data'=>"back"]],
]])
]);   
}
 if($data == 'col'){
  bot('editMessageText',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    'text'=>'
📋 اهلا بك في قسم تجميع النقاط :
▪لتجميع النقاط قم بأرسال الرابط ادناه لأصدقائك.
▪كل شخص يدخل تحصل على نقطة واحده.
▪اذا كانت طريقة تجميع النقاط معقدة قم بشراء النقاط من المطور.
——————————————————
🌐 الرابط : 
- https://t.me/'.$me.'?start='.$chat_id.'
',
   'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>"• مشاركة الرابط ، 🌐",'switch_inline_query'=>"#$chat_id"]],
[['text'=>"شراء النقاط ، 💸",'callback_data'=>"sho"]],
[['text'=>"القائمة الرئيسية 🔙",'callback_data'=>"back"]],
]])
  ]);
 }elseif($data == 'sales'){
  $reply_markup = [];
  $reply_markup['inline_keyboard'][] = [['text'=>'💵┇السعر ','callback_data'=>'s'],['text'=>'ℹ️┇الاسم ','callback_data'=>'s']];
  foreach($sales['sales'] as $code => $sale){
   $reply_markup['inline_keyboard'][] = [['text'=>$sale['price'],'callback_data'=>$code],['text'=>$sale['name'],'callback_data'=>$code]];
  }
    $reply_markup['inline_keyboard'][] = [['text'=>'-  رجــوع  ، 🔙','callback_data'=>'back']];
  $reply_markup = json_encode($reply_markup);
  bot('editMessageText',[
   'chat_id'=>$chat_id,
   'message_id'=>$message_id,
   'text'=>'- ▪️ اليكم قسم العروض 

• العروض التي يقدمها البوت 🗞️',
   'reply_markup'=>($reply_markup)
  ]);
  $sales[$chat_id]['mode'] = null;
   save($sales);
   exit;
 } elseif($data == 'yes'){
  $price = $sales['sales'][$sales[$chat_id]['mode']]['price'];
  $name = $sales['sales'][$sales[$chat_id]['mode']]['name'];
  bot('editMessageText',[
   'chat_id'=>$chat_id,
   'message_id'=>$message_id,
   'text'=>"
   - تم ارسال طلبك لمطور البوت ، 🛠
- قم بمراسلته للحصول على طلبك ، 📨 ",
  'reply_markup'=>json_encode([
       'inline_keyboard'=>[
[['text'=>"- المطور ، ⚓",'url'=>'t.me/EzZzZz']],
[['text'=>'- القائمة الرئيسية ،🔄\'','callback_data'=>'back']] 
]])
  ]);
$ne = $message->from->first_name;
bot('sendmessage',[
   'chat_id'=>$admin,
   'text'=>"
- العضو ، [$name](tg://user?id=$chat_id)
- قام بشراء  ، $name
-  بسعر  ، $price 📦
",
 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
  ]);
  $sales[$chat_id]['mode'] = null;
  $sales[$chat_id]['collect'] -= $price;
  save($sales);
  exit;
 } else {
   if($data == 's') { exit; }
   $price = $sales['sales'][$data]['price'];
   $name = $sales['sales'][$data]['name'];
   if($price != null){
    if($price <= $sales[$chat_id]['collect']){
     bot('editMessageText',[
      'chat_id'=>$chat_id,
      'message_id'=>$message_id,
      'text'=>"أهل؟ انت متأكد من شراء $name بسعر $price ؟ ، 📮",
      'reply_markup'=>json_encode([
       'inline_keyboard'=>[
        [['text'=>'- تاكيد الشراء، ⁦♥️','callback_data'=>'yes'],['text'=>'- الغاء ،🛠️\'','callback_data'=>'sales']] 
       ] 
      ])
     ]);
     $sales[$chat_id]['mode'] = $data;
     save($sales);
     exit;
    } else {
     bot('answercallbackquery',[
      'callback_query_id' => $update->callback_query->id,
      'text'=>'- للاسف نقاطك غير كافية لـ شراء العرض، 🚫',
      'show_alert'=>true
     ]);
    }
$bot = file_get_contents("com.txt");
if($text == "/start" and in_array($chat_id,$ad)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>" 👋| اهلا بك عزيزي المطور
🔄| يمكنك التحكم بـ البوت 
⚖️| لعرض احصائيات البوت ارسل 
/mem
",
'parse_mode'=>"Markdown",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
       [['text'=>'- اضف عرض ، 💸','callback_data'=>'add'],['text'=>'- حذف عرض 🗑\'','callback_data'=>'del']],
[['text'=>'🔰ارسال نقاط','callback_data'=>'thh'],['text'=>'🗑 حذف نقاط','callback_data'=>'hht']],
[['text'=>'✔ تسليم عرض','callback_data'=>'tsl'],['text'=>'🚫 ارسل تحذير','callback_data'=>'th']],
                                        [['text'=>'✴ارسال هديه','callback_data'=>'coon']],
[["text"=>"تفعيل التواصل ،♥️.","callback_data"=>"utws"],["text"=>"تعطيل التواصل ،📌.","callback_data"=>"ntws"]],
[["text"=>"حظـر عضو ،🛠️.","callback_data"=>"bn"],["text"=>"الغاء حظر العضو ،📦.","callback_data"=>"unbn"]],
[["text"=>"تفعيل اشعار الدخول ،🔖.","callback_data"=>"on"],["text"=>"تعطيل اشعار الدخول ،🎵.","callback_data"=>"off"]],
[["text"=>"مـعلومـآت لعضـو ،🔱.","callback_data"=>"info"],['text'=>'- رؤية العروض 🕹','callback_data'=>'ww']],
[["text"=>"قسم الاذاعه ،💬.","callback_data"=>"bcc"]],
[["text"=>"حذف جميع احصائيات البوت ،📜.","callback_data"=>"delbot"]],
]])
]);   
unlink("com.txt");
}
#رجوع
if($data == "bk" and in_array($chat_id2,$ad)){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>" 👋| اهلا بك عزيزي المطور
🔄| يمكنك التحكم بـ البوت 
⚖️| لعرض احصائيات البوت ارسل 
/mem
",
'parse_mode'=>"Markdown",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
       [['text'=>'- اضف عرض ، 💸','callback_data'=>'add'],['text'=>'- حذف عرض 🗑\'','callback_data'=>'del']],
[['text'=>'🔰ارسال نقاط','callback_data'=>'thh'],['text'=>'🗑 حذف نقاط','callback_data'=>'hht']],
[['text'=>'✔ تسليم عرض','callback_data'=>'tsl'],['text'=>'🚫 ارسل تحذير','callback_data'=>'th']],
                                        [['text'=>'✴ارسال هديه','callback_data'=>'coon']],
[["text"=>"تفعيل التواصل ،♥️.","callback_data"=>"utws"],["text"=>"تعطيل التواصل ،📌.","callback_data"=>"ntws"]],
[["text"=>"حظـر عضو ،🛠️.","callback_data"=>"bn"],["text"=>"الغاء حظر العضو ،📦.","callback_data"=>"unbn"]],
[["text"=>"تفعيل اشعار الدخول ،🔖.","callback_data"=>"on"],["text"=>"تعطيل اشعار الدخول ،🎵.","callback_data"=>"off"]],
[["text"=>"مـعلومـآت لعضـو ،🔱.","callback_data"=>"info"],['text'=>'- رؤية العروض 🕹','callback_data'=>'ww']],
[["text"=>"قسم الاذاعه ،💬.","callback_data"=>"bcc"]],
[["text"=>"حذف جميع احصائيات البوت ،📜.","callback_data"=>"delbot"]],
]])
]);   
unlink("com.txt");
}
  if($data == "thh"){
    bot('deleteMessage',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    ]);
    bot('SendMessage',[
'chat_id'=>$chat_id,
        'text'=>" 
أرسل أيدي الشخص الذي تريد إرسال النقاط له
",
]);
  $sales['mode'] = 'chat';
  save($sales);
  exit;
  }
   if($text != '/start' and $text != null and $sales['mode'] == 'chat'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
 'text'=> "أرسل الكمية التي تريد إرسالها",
 ]);
   $sales['mode'] = 'poi';
   $sales['idd'] = $text;
  save($sales);
  exit;
}
 if($text != '/start' and $text != null and $sales['mode'] == 'poi'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
 'text'=>"تم إضافة $text نقطة إلى حساب ".$sales['idd']." بنجاح ",
]);
  bot('sendmessage',[
   'chat_id'=>$sales['idd'],
  'text'=>"تمت إضافة $text نقطة إلى حسابك في البوت من قبل المطور ",
  ]);
  $sales['mode'] = null;
  $sales[$sales['idd']]['collect'] += $text;
  $sales['idd'] = null;
  save($sales);
  exit;
}
  if($data == "hht"){
    bot('deleteMessage',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    ]);
    bot('SendMessage',[
'chat_id'=>$chat_id,
        'text'=>" 
أرسل أيدي الشخص الذي تريد خصم النقاط منه
",
]);
  $sales['mode'] = 'chat1';
  save($sales);
  exit;
  }
   if($text != '/start' and $text != null and $sales['mode'] == 'chat1'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
 'text'=> "أرسل الكمية التي تريد خصمها",
 ]);
   $sales['mode'] = 'poi1';
   $sales['idd'] = $text;
  save($sales);
  exit;
}
 if($text != '/start' and $text != null and $sales['mode'] == 'poi1'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
 'text'=>"تم خصم $text نقطة من حساب ".$sales['idd']." بنجاح ",
]);
  bot('sendmessage',[
   'chat_id'=>$sales['idd'],
  'text'=>"تمت خصم $text نقطة من حسابك في البوت من قبل المطور ",
  ]);
  $sales['mode'] = null;
  $sales[$sales['idd']]['collect'] -= $text;
  $sales['idd'] = null;
  save($sales);
  exit;
}
  if($data == "tsl"){
    bot('deleteMessage',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    ]);
    bot('SendMessage',[
'chat_id'=>$chat_id,
        'text'=> "
ارسل ايدي الشخص الذي تريد تسليمه العرض
",
]);
  $sales['mode'] = 'chat2';
  save($sales);
  exit;
  }
   if($text != '/start' and $text != null and $sales['mode'] == 'chat2'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
 'text'=> "
أرسل لـي العرض 🔄",
 ]);
   $sales['mode'] = 'poi2';
   $sales['idd'] = $text;
  save($sales);
  exit;
}
 if($text != '/start' and $text != null and $sales['mode'] == 'poi2'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
 'text'=>"تم إرسال الرقم إلى ".$sales['idd']." بنجاح ",
]);
  bot('sendmessage',[
   'chat_id'=>$sales['idd'],
  'text'=>"طلبك يا عزيزي ... ♥️🔄

$text
",
  ]);
  $sales['mode'] = null;
  $sales['idd'] = null;
  save($sales);
  exit;
}
if($text == "رساله خاصه لمستخدم"){
  bot('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"
أرسل أيدي الشخص الذي تريد إرسال الرسالة له
",
]);
  $sales['mode'] = 'chat3';
  save($sales);
  exit;
  }
   if($text != '/start' and $text != null and $sales['mode'] == 'chat3'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
 'text'=> "
أرسل رسالتك",
 ]);
   $sales['mode'] = 'poi3';
   $sales['idd'] = $text;
  save($sales);
  exit;
}
 if($text != '/start' and $text != null and $sales['mode'] == 'poi3'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
 'text'=>"تم إرسال الرسالة إلى ".$sales['idd']." بنجاح ",
]);
  bot('sendmessage',[
   'chat_id'=>$sales['idd'],
  'text'=>"رسالة من الإدارة:

$text",
  ]);
  $sales['mode'] = null;
  $sales['idd'] = null;
  save($sales);
  exit;
}
  if($data == "th"){
    bot('deleteMessage',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    ]);
    bot('SendMessage',[
'chat_id'=>$chat_id,
        'text'=>"
أرسل أيدي الشخص الذي تريد إرسال التحذير له
",
]);
  $sales['mode'] = 'chat4';
  save($sales);
  exit;
  }
   if($text != '/start' and $text != null and $sales['mode'] == 'chat4'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
 'text'=> "
إضغط /Confirm لتأكيد إرسال التحذير",
 ]);
   $sales['mode'] = 'poi4';
   $sales['idd'] = $text;
  save($sales);
  exit;
}
 if($text != '/start' and $text != null and $sales['mode'] == 'poi4'){
  bot('sendMessage',[
   'chat_id'=>$chat_id,
 'text'=>"تم إرسال التحذير إلى ".$sales['idd']." بنجاح ",
]);
  bot('sendmessage',[
   'chat_id'=>$sales['idd'],
  'text'=>"تحذير من الإدارة!
إستعمال حسابات وهمية الدخول لرابطك بها يؤدي إلى حظر حسابك 👉
في حال إستعمال الوهمي سينحظر حسابك... إنتبه... شكرا على تفهمك للموضوع",
  ]);
  $sales['mode'] = null;
  $sales['idd'] = null;
  save($sales);
  exit;
}
#قسم حذف كل
if($data == "delbot" and in_array($chat_id2,$ad)){
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮| عزيزي هل انت متاكد من انك تريد حذف جميع احصائيات البوت،
🎄| #مـلآحظـهہ‏‏ سيتم حذف جميع ايديات الاعضا،الاشتراك الاجباري،اعضا المحظورين،عدد زخارف و....،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"نعم ،📌.","callback_data"=>"dell"],["text"=>"لآ ،📌.","callback_data"=>"bk"]],
]])
]);   
}
if($data == "dell" and in_array($chat_id2,$ad)){
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮| تم حذف جميع احصائيات البوت اصبح الان جديد",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،📌.","callback_data"=>"bk"]],
]])
]);   
unlink("start.txt");
unlink("tw.txt");
unlink("blocklist.txt");
unlink("admin2.txt");
unlink("g.txt");
unlink("rabt.txt");
unlink("id.txt");
unlink("ch.txt");
unlink("chc.txt");
unlink("zkf.txt");
}
#قسم الاذاعه
if($data == "bcc" and in_array($chat_id2,$ad)){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"💛| حسننا الان قم بختيار الاذاعه من فضلك،",
'disable_web_page_preview'=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"ذاعه رساله ?? ","callback_data"=>"set"],["text"=>"ذاعه توجيه","callback_data"=>"for"]],
[["text"=>"أذاعه شفاف 📡","callback_data"=>"inln"],["text"=>"اذاعه ميديا 📡","callback_data"=>"med"]],
[["text"=>"🏠┇العوده ","callback_data"=>"bk"]],
]])
]);   
}
#الاحصائيات
$meb = explode("\n",file_get_contents("g.txt"));
$band = explode("\n",file_get_contents("blocklist.txt"));
$mem = count($meb)-1;
$zktex = count($tkzk)-1;
$bnn = count($band)-1;
if($text == "/mem" and in_array($chat_id,$ad)){
 date_default_timezone_set("Asia/Baghdad");
$getMe = bot('getMe')->result;
$date = $message->date;
$gettime = time();
$sppedtime = $gettime - $date;
$time = date('h:i');
$date = date('y/m/d');
$userbot = "{$getMe->username}";
$userb = strtoupper($userbot);
if ($sppedtime == 3  or $sppedtime < 3) {
$f = "ممتازة 👏🏻";}
if ($sppedtime == 9 or $sppedtime > 9 ) {
$f = "لا بأس 👍🏻";}
if ($sppedtime == 10 or $sppedtime > 10) {
$f = " سئ جدا 👎🏻"; }
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>
"📯||عدد العضاء : *$mem*،
📯||عدد الاعضا المحظورين : *$bnn*،
📯||حاله البوت : *$f*،
📯||الوقت و التاريخ : *20$date - $time*،",
'parse_mode'=>'MarkDown',
'reply_to_message_id'=>$message->message_id,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
#رساله ستارت
if($data == "start" and in_array($chat_id2,$ad)){
file_put_contents("com.txt","start");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📯||حسننا الان قم برسال النص،
🐞| يمكنك ايضا استخدام الماركدوان كمثال،
",
'disable_web_page_preview'=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "start" and $text != "/h" and $text != "/start" and in_array($chat_id,$ad)){
file_put_contents("start.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🎯| تم حفظ نص الاستارت،",
'reply_to_message_id'=>$message->message_id,
]);
unlink("com.txt");
}
#تفعيل اشعار دخول
if($data == "on" and in_array($chat_id2,$ad)){
file_put_contents("onn.txt","on");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"💘| تم تفعيل اشعار الدخول،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
#تعطيل اشعار دخول
if($data == "off" and in_array($chat_id2,$ad)){
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🔖| تم تعطيل الاشعار الدخول،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
unlink('onn.txt');
}
#تفعيل تواصل
if($data == "utws" and in_array($chat_id2,$ad)){
file_put_contents("tw.txt","on");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📦|تم تفعيل التواصل ،",
]); 
}
#تعطيل تواصل
if($data == "ntws" and in_array($chat_id2,$ad)){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"??|تم تعطيل التواصل ،",
]); 
unlink("tw.txt");
}
if($text and !in_array($from_id,$ebu) and !in_array($chat_id,$ad) and $tws == "on"){
bot('forwardMessage',[
'chat_id'=>$admin,
'from_chat_id'=>$chat_id,
'message_id'=>$update->message->message_id,
'text'=>$text,
]);
}
if($text and $message->reply_to_message && $text!="/info" && $text!="/ban" && $text!="/unban" && $text!="/forward" and !$data ){
bot('sendMessage',[
'chat_id'=>$message->reply_to_message->forward_from->id,
'text'=>$text,
]);
}
if($bot == "ad" and $text != "/start" and $chat_id == $admin){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"📮| تم حفظ ايدي العضو،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"📯||تم رفعك ادمن بواسط صاحب البوت،",
'parse_mode'=>'MarkDown',
]);
unlink("com.txt");
file_put_contents("admin2.txt","$text");
}
#مـآيخصـك
if($data == "admin" and $chat_id2 == $admin2){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📯||هاذ الامر لايخصك،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
#حظر
if($data == "bn" and in_array($chat_id2,$ad)){
file_put_contents("com.txt","bn");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"💘| حسننا الان قم برسال ايدي العضو،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "bn" and $text != "/start" and in_array($chat_id,$ad)){
$myfile2 = fopen("blocklist.txt", "a") or die("Unable to open file!");	
fwrite($myfile2, "$text\n");
fclose($myfile2);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📨| تم حظر العضو بنجاح،",
]);
bot('sendmessage',[
'chat_id'=>$text,
'text'=>"📨| عذرا عزيزي تم حظرك،",
]);
unlink("com.txt");
}
#الغاء حظر
$listt = file_get_contents("blocklist.txt");
if($data == "unbn" and in_array($chat_id2,$ad)){
file_put_contents("com.txt","unbn");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮| حسننا الان قم برسال ايدي العضو،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "unbn" and $text != "/start" and in_array($chat_id,$ad)){
$newlist = str_replace($text,"",$listt);
file_put_contents("blocklist.txt",$newlist);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📯||تم آلغآء حظر العضو بنجاح،",
]);
bot('sendmessage',[
'chat_id'=>$text,
'text'=>"📯||عزيزي تم آلغآء آلحظر عنك،",
]);
unlink("com.txt");
}
#معلومات
if($data == "info" and in_array($chat_id2,$ad)){
file_put_contents("com.txt","info");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🎁| حسننا الان قم برسال ايدي العضو،
📯||#ملاحظه يجب العضو يكون مشترك في لبوت مسبقا،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "info" and $text != "/start"and in_array($chat_id,$ad)){
$ine = json_decode(file_get_contents("http://api.telegram.org/bot".API_KEY."/getChat?chat_id=$text"));
$infe4 =$ine->result->first_name;
$infe2 =$ine->result->id;
$infe3 =$ine->result->username;
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"*🎯| INFO MEMBER*
🔖| Name 💬 : *$infe4* \n 🎧| User 💌 : [@$infe3] \n 📚| Id 🎄 : `$infe2`",
'reply_to_message_id'=>$message->message_id,
'parse_mode'=>'MarkDown', 
]);
unlink("com.txt");
}
#اذاعه
if($data == "bc" and in_array($chat_id2,$ad)){
file_put_contents("com.txt","send");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>" ارسل رسالتك الان عزيزي 🎯. #يمكنك استخدام الماركدان ايضا",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
$ali = fopen( "g.txt", 'r');
while(!feof( $ali)){
$gh3 = fgets($ali);
if($bot == "send" and in_array($chat_id,$ad)){
bot('sendMessage', [
'chat_id' =>$gh3,
'text'=>$text,
'parse_mode'=>"MarkDown",
'disable_web_page_preview' =>"true"
]);
unlink("com.txt");
}
}
$tx = file_get_contents("alh.txt");
if($data == "inln" and in_array($chat_id2,$ad)){
file_put_contents("com.txt","sn");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسـننآ آلآن ارسل نص تريد نشرة ك منشور شفاف 🎁. #ملاحظه يمكنك استخدام الماركدوان ايضا",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "sn" and $text != "/start" and in_array($chat_id,$ad)){
file_put_contents("alh.txt","$text");
file_put_contents("com.txt","snn");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"حسننا الان استخدم🎄.
text = link
text = link + text = link
نص = رابط
نص = رابط + نص = رابط",
'reply_to_message_id'=>$message->message_id,
]);
}
$i=0;
$keyboard = [];
$keyboard["inline_keyboard"] = [];
$rows = explode("\n",$text);
foreach($rows as $row){
$j=0;
$keyboard["inline_keyboard"][$i]=[];
$bottons = explode("+",$row);
foreach($bottons as $botton){
$g = explode("=",$botton."=");
$Ibotton = ["text" => trim($g[0]), "url" => trim($g[1])];
$keyboard["inline_keyboard"][$i][$j] = $Ibotton;
$j++;                }                $i++;            }
$reply_markup=json_encode($keyboard);
if($bot == "snn" and $text != "/start" and in_array($chat_id,$ad)){
$ali = fopen( "g.txt", 'r');
while(!feof( $ali)){
$gh = fgets($ali);
bot('sendmessage',[
'chat_id'=>$gh,
'text'=>$tx,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'reply_markup'=>($reply_markup)
]);
}
unlink("com.txt");
unlink("alh.txt");
}
if($data == "for" and in_array($chat_id2,$ad)){
file_put_contents("com.txt","fd");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>" ارسل توجيهك الان عزيزي 📌.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "fd" and $text != "/start" and in_array($chat_id,$ad)){
$ali = fopen( "g.txt", 'r');
while(!feof( $ali)){
$ali2 = fgets($ali);
bot('forwardMessage',[
 'chat_id'=>$ali2,
 'from_chat_id'=>$chat_id,
 'message_id'=>$message->message_id,
 ]);
 unlink("com.txt");
 }
 }
 if($data == "med" and in_array($chat_id2,$ad)){
file_put_contents("com.txt","mide");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🔖| حسـننآ الان ارسل احد ميديا،
📌| مثلا : صور،فيديو،ملف،اغنيه،ملصق،ملف صوتي،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
#اذاعه ب ميديا
 if($message->video and $bot == "mide" and in_array($chat_id,$ad) and $text != "/start"){
 $ali = fopen( "g.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
bot('sendvideo',['chat_id'=>$aly,'video'=>$message->video->file_id,'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,]);
bot('sendmessage',[ 
'chat_id'=>$chat_id, 'text'=>"تم نشر الفيديو '📚!",]); }unlink("com.txt"); }
if($message->document and $bot == "mide" and in_array($chat_id,$ad) and $text != "/start"){
$ali = fopen( "g.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
bot('Senddocument',['chat_id'=>$aly,'document'=>$message->document->file_id,'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
]);bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الملف او متحركه '🎻!", ]); } unlink("com.txt");}
 if($message->audio and $bot == "mide" and in_array($chat_id,$ad) and $text != "/start"){
 	$ali = fopen( "g.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
 bot('sendaudio',[    'chat_id'=>$aly,    'audio'=>$message->audio->file_id,    'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
 ]); bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الاغنيه '🎺!", ]); } unlink("com.txt");}
if($message->photo and $bot == "mide" and in_array($chat_id,$ad) and $text != "/start"){
	$ali = fopen( "g.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
    bot('sendPhoto',[      'chat_id'=>$aly,      'photo'=>$message->photo[0]->file_id,      'caption'=>$message->caption,      'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
    ]);bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الصورة '📇!", ]); } unlink("com.txt");}
if($message->voice and $bot == "mide" and in_array($chat_id,$ad) and $text != "/start"){
	$ali = fopen( "g.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
    bot('sendvoice',[     'chat_id'=>$aly,      'voice'=>$message->voice->file_id,     'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
      ]);      bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الاغنيه '📜!", ]); } unlink("com.txt");}
      if($message->sticker and $bot == "mide" and in_array($chat_id,$ad) and $text != "/start"){
      	$ali = fopen( "g.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
bot('sendsticker',['chat_id'=>$aly,'sticker'=>$message->sticker->file_id
]);bot('sendmessage',['chat_id'=>$chat_id, 'text'=>"تم نشر الملصق '📂!", ]); }unlink("com.txt"); }
$inlinequery = $update->inline_query->query;
$inlineID = $update->inline_query->from->id;
if($inlinequery == "#$inlineID" ){
    bot('answerInlineQuery',[
    'inline_query_id'=>$update->inline_query->id,    
    'cache_time'=>'300',
    'results' => json_encode([[
    'type'=>'article',
    'id'=>base64_encode(rand(5,555)),
    'title'=>' • اضغط هنا لمشاركة الرابط ، 🌐',
    'thumb_url'=>"https://d.top4top.net/p_12168e2020.jpg",
    'description'=>"سيتم آرسال الرابط تلقائي 
ويتم تجميع النقاط تلقائي ايضا ...",
    'input_message_content'=>[
    'disable_web_page_preview'=>true,
    'message_text'=>"▪اهلا بك في بوت العروض المدفوع 🛠
▫️قم تجميع النقاط وشراء العروض .. "],
    'reply_markup'=>['inline_keyboard'=>[
    [['text'=>"- اضغط هنا للدخول ، 🛠",'url'=>"https://t.me/'.$m3rf.'?start='.$chat_id.'"]]
    ]]
    ]])
    ]);
    }
  if($data == "coon"){
$code = rand(3,9);
file_put_contents("code.txt",$code);
    bot('deleteMessage',[
    'chat_id'=>$chat_id,
    'message_id'=>$message_id,
    ]);
    bot('SendMessage',[
'chat_id'=>$baageel,
 "text"=>"ارسل رقم [[ $code ]] للبوت واحصل على 2 نقاط هديه 💞🙏",
'parse_mode'=>"markdown",
'disable_web_page_preview'=>true,'
reply_markup'=>json_encode(['inline_keyboard'=>[
 [['text'=>'اضغط هنا وادخل للبوت 💞','url'=>'https://t.me/Ti7bot?start=1010918290']],
 ],
])
]);
} 
$codee= file_get_contents("code.txt"); 
if($text==$codee){
 $sales[$chat_id]['collect'] += 2;
 save($sales);
 $nn = $chat_id;
 $nnn = $namee;
 file_put_contents("code.txt"," ");
 bot("sendmessage",[
 "chat_id"=>$chat_id,
 "text"=>"!!تم اضافت لك 2 من النقاط ك هديه من المطور",
 ]);
 bot('sendmessage',[
'chat_id'=>$baageel,
'text'=>"
📬 | تم اخذ الكود بواسطة:
- @$user 
",
 ]);
}}}}}}}}} 