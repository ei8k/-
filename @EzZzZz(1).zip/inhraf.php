<?php 
ob_start();

// تخمط اذكر اسمي حبي #كلاوجي
// قناتي @NONBBN
//معرفي @ll8III
//سطر 50ايديك ونوب روح لسطر 1037شوف لمطلوب منك وغيره//

$dev_a = '1083685838:AAHe9IEs_DvLAYlJfgiv5Dz5TY5_EVvWFdc';
define('API_KEY',$dev_a);
define('API_KEY',$Ailnoor);
function bot($method,$datas=[]){
$aws_c9 = http_build_query($datas);
$url = "https://api.telegram.org/bot".API_KEY."/".$method."?$aws_c9";
$aws_c9 = file_get_contents($url);
return json_decode($aws_c9);
}
function AliZip($AliZip1, $AliZip2){
$AliZip4 = realpath($AliZip1);
$AliZip = new ZipArchive();
$AliZip->open($AliZip2, ZipArchive::CREATE | ZipArchive::OVERWRITE);
$AliZip3 = new RecursiveIteratorIterator(
new RecursiveDirectoryIterator($AliZip4),
RecursiveIteratorIterator::LEAVES_ONLY);
foreach($AliZip3 as $AliZip5 => $AliZip6){
if(!$AliZip6->isDir()){
$AliZip7 = $AliZip6->getRealPath();
$AliZip8 = substr($AliZip7, strlen($AliZip4) + 1);
$AliZip->addFile($AliZip7, $AliZip8);
}}
$AliZip->close();
}

function AliZip1($AliZip9, $AliZip10 = 2){
$AliZip11=array(' B', ' KB', ' MB', ' GB', ' TB', ' PB', ' EB', ' ZB', ' YB');
$AliZip12=floor((strlen($AliZip9) - 1) / 3);
return sprintf("%.{$AliZip10}f", $AliZip9 / pow(1024, $AliZip12)) . @$AliZip11[$AliZip12];
}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$text = $message->text;
$data = $update->callback_query->data;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id2 = $update->callback_query->message->message_id;
$name = $message->from->first_name;
$user = $message->from->username;
$admin = "1010918290";
$tws = file_get_contents("tw.txt");
$de = file_get_contents("admin2.txt");
$ad = array("$admin","$de");
$list = file_get_contents("blocklist.txt");
$ebu = explode("\n",$list);
$type       = $update->message->chat->type;
if(in_array($from_id,$ebu)){
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"⛳| عزيزي انت محظور من البوت",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);    
}
mkdir('alsh');
include "php.php";
#التخزين ايديات
$from_id = $message->from->id;
$type       = $update->message->chat->type;
$gp = explode("\n",file_get_contents("group.txt"));
$pv = explode("\n",file_get_contents("alsh/Alsh.txt"));
$sta = file_get_contents("start.txt");
#شتراك اجباري خاصه
$all = file_get_contents("id.txt");
$rabt = file_get_contents("rabt.txt");
$join = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$all&user_id=".$from_id);
if($message && (strpos($join,'"status":"left"') or strpos($join,'"Bad Request: USER_ID_INVALID"') or strpos($join,'"status":"kicked"'))!== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لستخدام البوت عليك اشتراك في قنوات البوت 🎁.
بعد الاشتراك في القنوات اضغط - /start 📦.",
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
          'inline_keyboard'=>[
[['text'=>"📦. اشترك -",'url'=>"$rabt"]],
]])]);return false;}
#شتراك اجباري1
$op = file_get_contents("ch.txt");
$join = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$op&user_id=".$from_id);
if($message && (strpos($join,'"status":"left"') or strpos($join,'"Bad Request: USER_ID_INVALID"') or strpos($join,'"status":"kicked"'))!== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لستخدام البوت عليك اشتراك في قنوات البوت 🎁.
بعد الاشتراك في القنوات اضغط - /start 📦.
قناة البوت : @$op",
'reply_to_message_id'=>$message->message_id,
]);return false;}
#شتراك اجباري2
$oop = file_get_contents("chc.txt");
$join = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@$oop&user_id=".$from_id);
if($message && (strpos($join,'"status":"left"') or strpos($join,'"Bad Request: USER_ID_INVALID"') or strpos($join,'"status":"kicked"'))!== false){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لستخدام البوت عليك اشتراك في قنوات البوت 🎁.
بعد الاشتراك في القنوات اضغط - /start 📦.
قناة البوت : @$oop",
'reply_to_message_id'=>$message->message_id,
]);return false;}
if($text and $text != "/start"){
file_put_contents("text.txt", "$text\n",FILE_APPEND);}
if($text and $type == "private" and !in_array($from_id, $pv)){
file_put_contents("alsh/Alsh.txt", "$from_id\n",FILE_APPEND);}
if($text and $type == "supergroup" and !in_array($chat_id, $gp)) {
file_put_contents("group.txt", "$chat_id\n",FILE_APPEND);}
if($text == "/start" and !in_array($from_id,$ebu) and !in_array($chat_id,$ad) and $chat_id != $admin and $sta == null){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
اهلا وسهلا بك $name

في بوت الانحراف الاول بالعراق ادخل واستمتع وادعيلنا 🔞🙈.
",
'parse_mode'=>"Markdown",
'disable_web_page_preview'=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"$name","url"=>"t.me/$user"]],
]])
]);   
}
if($text == "/start" and !in_array($from_id,$ebu) and !in_array($chat_id,$ad) and $chat_id != $admin and $sta != null){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"مـرحبا بك عزيزي 🎁. ، $name ،
$sta
",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"$name","url"=>"t.me/$user"]],
]])
]);   
}

$bot = file_get_contents("com.txt");
if($text == "/start" and in_array($chat_id,$ad)){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"آهلا بك $name 🍟.
🎺| يمكنك استخدام الاوامر الموجوده في اسفل.
📌| لعرض احصائيات البوت ارسل : /mem.
",
'parse_mode'=>"Markdown",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"تغير رساله ال/start ،📎.","callback_data"=>"start"]],
[["text"=>"تفعيل التواصل ،📯.","callback_data"=>"utws"],["text"=>"تعطيل التواصل ،📌.","callback_data"=>"ntws"]],
[["text"=>"حظـر عضو ،📤.","callback_data"=>"bn"],["text"=>"الغاء حظر العضو ،📦.","callback_data"=>"unbn"]],
[["text"=>"آضـآفهہ‏‏ آدمـن للبوت ،📚.","callback_data"=>"admin"],["text"=>"حذف آدمـن آلبوت ،🍟.","callback_data"=>"unadmin"]],
[["text"=>"مـعلومـآت العضو بالايدي ،🎺.","callback_data"=>"info"],["text"=>"مـعلومـآت عضو بالمعرف ،🎄.","callback_data"=>"infous"]],
[["text"=>"قسم شتراك اجباري ،🎯.","callback_data"=>"chh"],["text"=>"قسم الاذاعه ،🏆.","callback_data"=>"bcc"]],
[["text"=>"تجربه كود ،💧.","callback_data"=>"setphp"],["text"=>"حذف لكود ،🚿.","callback_data"=>"delphp"]],
[["text"=>"تفعيل اشعار الدخول ،🔖.","callback_data"=>"on"],["text"=>"تعطيل اشعار الدخول ،🎵.","callback_data"=>"off"]],
[["text"=>"نسـخهہ‏‏ احتياطيه ،💛.","callback_data"=>"get"],["text"=>"نسـخهہ‏‏ من اعضا ،🔦.","callback_data"=>"upmem"]],
[["text"=>" رفع نسخه من اعضا ،📮.","callback_data"=>"puo"]],
[["text"=>"حذف جميع احصائيات البوت ،🌻.","callback_data"=>"delbot"]],
]])
]);   
unlink("com.txt");
}
#رجوع
if($data == "bk" and in_array($chat_id2,$ad)){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"آهلا بك $name 🍟.
🎺| يمكنك استخدام الاوامر الموجوده في اسفل.
📌| لعرض احصائيات البوت ارسل : /mem.
",
'parse_mode'=>"Markdown",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"تغير رساله ال/start ،📎.","callback_data"=>"start"]],
[["text"=>"تفعيل التواصل ،📯.","callback_data"=>"utws"],["text"=>"تعطيل التواصل ،📌.","callback_data"=>"ntws"]],
[["text"=>"حظـر عضو ،📤.","callback_data"=>"bn"],["text"=>"الغاء حظر العضو ،📦.","callback_data"=>"unbn"]],
[["text"=>"آضـآفهہ‏‏ آدمـن للبوت ،📚.","callback_data"=>"admin"],["text"=>"حذف آدمـن آلبوت ،🍟.","callback_data"=>"unadmin"]],
[["text"=>"مـعلومـآت العضو بالايدي ،🎺.","callback_data"=>"info"],["text"=>"مـعلومـآت عضو بالمعرف ،🎄.","callback_data"=>"infous"]],
[["text"=>"قسم شتراك اجباري ،🎯.","callback_data"=>"chh"],["text"=>"قسم الاذاعه ،🏆.","callback_data"=>"bcc"]],
[["text"=>"تجربه كود ،💧.","callback_data"=>"setphp"],["text"=>"حذف لكود ،🚿.","callback_data"=>"delphp"]],
[["text"=>"تفعيل اشعار الدخول ،🔖.","callback_data"=>"on"],["text"=>"تعطيل اشعار الدخول ،🎵.","callback_data"=>"off"]],
[["text"=>"نسـخهہ‏‏ احتياطيه ،💛.","callback_data"=>"get"],["text"=>"نسـخهہ‏‏ من اعضا ،🔦.","callback_data"=>"upmem"]],
[["text"=>" رفع نسخه من اعضا ،📮.","callback_data"=>"puo"]],
[["text"=>"حذف جميع احصائيات البوت ،🌻.","callback_data"=>"delbot"]],
]])
]);   
unlink("com.txt");
}
#تفعيل اشعار دخول
if($data == "on" and in_array($chat_id2,$ad)){
file_put_contents("onn.txt","on");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"💘| تم تفعيل اشعار الدخول،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
#تعطيل اشعار دخول
if($data == "off" and in_array($chat_id2,$ad)){
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🔖| تم تعطيل الاشعار الدخول،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
unlink('onn.txt');
}
#حذف آدمن
if($data == "unadmin" and $chat_id2 == $admin){
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"تم حذف الادمن.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،📌.","callback_data"=>"bk"]],
]])
]);   
unlink('admin2.txt');
}
#قسم حذف كل
if($data == "delbot" and in_array($chat_id2,$ad)  ){
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮| عزيزي هل انت متاكد من انك تريد حذف جميع احصائيات البوت،
🎄| #مـلآحظـهہ‏‏ سيتم حذف جميع ايديات الاعضا،الاشتراك الاجباري،اعضا المحظورين،عدد رسائل داخل لبوت و....،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"نعم ،📌.","callback_data"=>"dell"],["text"=>"لآ ،📌.","callback_data"=>"bk"]],
]])
]);   
}
if($data == "dell" and in_array($chat_id2,$ad)  ){
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮| تم حذف جميع احصائيات البوت اصبح الان جديد",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،📌.","callback_data"=>"bk"]],
]])
]);   
unlink("start.txt");
unlink("tw.txt");
unlink("blocklist.txt");
unlink("admin2.txt");
unlink("alsh/Alsh.txt");
unlink("rabt.txt");
unlink("id.txt");
unlink("ch.txt");
unlink("chc.txt");
unlink("text.txt");
unlink("php.php");
}
#قسم الاذاعه
if($data == "bcc" and in_array($chat_id2,$ad)  ){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"💛| حسننا الان قم بختيار الاذاعه من فضلك،",
'disable_web_page_preview'=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"آذآعهہ‏‏ رسـآلهہ‏‏ ،🌻.","callback_data"=>"bc"],["text"=>"آذآعهہ‏‏ بآلتوجيهہ‏‏ ،🌻.","callback_data"=>"for"]],
[["text"=>"آذآعهہ‏‏ شـفآف ،🌻.","callback_data"=>"inln"],["text"=>"آذآعهہ‏‏ بآلمـيديآ ،🌻.","callback_data"=>"med"]],
[["text"=>"آذآعهہ‏‏ HTML ،🌻.","callback_data"=>"HTML"],["text"=>"آذآعهہ‏‏ MarkDown ،🌻.","callback_data"=>"MarkDown"]],
[["text"=>"آذآعهہ‏‏ للمجموعات ،🌻.","callback_data"=>"sndgp"],["text"=>"آذآعهہ‏‏ للكل مجموعات و اعضا ،🌻.","callback_data"=>"MarkDown"]],
[["text"=>"رجوع ،🌻.","callback_data"=>"bk"]],
]])
]);   
}
#قسم شتراك اجباري
if($data == "chh" and in_array($chat_id2,$ad)  ){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🌻| حسننا عزيزي قم بلختيار من الاسفل لوضع شتراك اجباري،",
'disable_web_page_preview'=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"قناة عامه 1 ،🎺.","callback_data"=>"add2"],["text"=>"قناة عامه 2 ،🎺.","callback_data"=>"add1"]],
[["text"=>"قناة خاصه ،🎺.","callback_data"=>"add"]],
[["text"=>"حذف جميع القنوات من شتراك ،🎺.","callback_data"=>"remch"]],
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
#الاحصائيات
$tkzk = explode("\n",file_get_contents("text.txt"));
$meb = explode("\n",file_get_contents("alsh/Alsh.txt"));
$band = explode("\n",file_get_contents("blocklist.txt"));
$tx = explode("\n",file_get_contents("text.txt"));
$admn = file_get_contents("admin2.txt");
$gpp = explode("\n",file_get_contents("group.txt"));
$mem = count($meb)-1;
$zktex = count($tkzk)-1;
$bnn = count($band)-1;
$ts = count($tx)-1;
$grup = count($gpp)-1;
$oop = file_get_contents("chc.txt");
$op = file_get_contents("ch.txt");
$all = file_get_contents("id.txt");
$rabt = file_get_contents("rabt.txt");
if($text == "/mem" and in_array($chat_id,$ad)  ){
 date_default_timezone_set("Asia/Baghdad");
$getMe = bot('getMe')->result;
$date = $message->date;
$gettime = time();
$sppedtime = $gettime - $date;
$time = date('h:i');
$date = date('y/m/d');
$userbot = "{$getMe->username}";
$userb = strtoupper($userbot);
if ($sppedtime == 3  or $sppedtime < 3) {
$f = "ممتازة 👏🏻";}
if ($sppedtime == 9 or $sppedtime > 9 ) {
$f = "لا بأس 👍🏻";}
if ($sppedtime == 10 or $sppedtime > 10) {
$f = " سئ جدا 👎🏻"; }
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🌻| عدد العضاء : *$mem*،
🌻| عدد الاعضا المحظورين : *$bnn*،
🌻| سرعهہ‏‏ البوت : *$f*،
🌻|  عدد رسائل داخل البوت : *$ts*،
🌻|  عدد المجموعات : *$grup*،
🌻| الوقت و التاريخ : *20$date - $time*،
🌻|   آدمن الثاني : *$admn*،
🌻| قنوات الاشتراك الاجباري العام،
@$op ، @$oop
🌻| قناة الاشتراك الاجباري الخاص،
`$all` ، `$rabt`
",
'parse_mode'=>'MarkDown',
'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message->message_id,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
#رساله ستارت
if($data == "start" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","start");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🌻| حسننا الان قم برسال النص،
🐞| يمكنك ايضا استخدام الماركدوان كمثال،
[اضغط هنا وتابع جديدنا](t.me/alshh)",
'disable_web_page_preview'=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "start" and $text != "/h" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("start.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🎯| تم حفظ نص الاستارت،",
'reply_to_message_id'=>$message->message_id,
]);
unlink("com.txt");
}
#تفعيل تواصل
if($data == "utws" and in_array($chat_id2,$ad)  ){
file_put_contents("tw.txt","on");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📦|تم تفعيل التواصل ،",
]); 
}
#تعطيل تواصل
if($data == "ntws" and in_array($chat_id2,$ad)  ){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮|تم تعطيل التواصل ،",
]); 
unlink("tw.txt");
}
if($text and !in_array($from_id,$ebu) and !in_array($chat_id,$ad) and $chat_id != $admin and $tws == "on"){
bot('forwardMessage',[
'chat_id'=>$admin,
'from_chat_id'=>$chat_id,
'message_id'=>$update->message->message_id,
'text'=>$text,
]);
}
if($text and $message->reply_to_message && $text!="/info" && $text!="/ban" && $text!="/unban" && $text!="/forward" and !$data ){
bot('sendMessage',[
'chat_id'=>$message->reply_to_message->forward_from->id,
'text'=>$text,
]);
}
#اضافه ادمن
if($data == "admin" and $chat_id2 == $admin){
file_put_contents("com.txt","ad");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮| حسننا الان قم برسال ايدي العضو،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "ad" and $text != "/start" and $chat_id == $admin){
file_put_contents("admin2.txt",$text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"📮| تم حفظ ايدي العضو،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
bot('sendMessage',[
'chat_id'=>$text,
'text'=>"🌻| تم رفعك ادمن بواسط صاحب البوت،",
'parse_mode'=>'MarkDown',
]);
unlink("com.txt");
}
#حظر
if($data == "bn" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","bn");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"💘| حسننا الان قم برسال ايدي العضو،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "bn" and $text != "/start" and in_array($chat_id,$ad)  ){
$myfile2 = fopen("blocklist.txt", "a") or die("Unable to open file!");	
fwrite($myfile2, "$text\n");
fclose($myfile2);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"📨| تم حظر العضو بنجاح،",
]);
bot('sendmessage',[
'chat_id'=>$text,
'text'=>"📨| عذرا عزيزي تم حظرك،",
]);
unlink("com.txt");
}
#الغاء حظر
$listt = file_get_contents("blocklist.txt");
if($data == "unbn" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","unbn");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📮| حسننا الان قم برسال ايدي العضو،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "unbn" and $text != "/start" and in_array($chat_id,$ad)  ){
$newlist = str_replace($text,"",$listt);
file_put_contents("blocklist.txt",$newlist);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🌻| تم آلغآء حظر العضو بنجاح،",
]);
bot('sendmessage',[
'chat_id'=>$text,
'text'=>"🌻| عزيزي تم آلغآء آلحظر عنك،",
]);
unlink("com.txt");
}
#معلومات
if($data == "info" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","info");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🎁| حسننا الان قم برسال ايدي العضو،
🌻| #ملاحظه يجب العضو يكون مشترك في لبوت مسبقا،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}
if($bot == "info" and $text != "/start"and in_array($chat_id,$ad)  ){
$ine = json_decode(file_get_contents("http://api.telegram.org/bot".API_KEY."/getChat?chat_id=$text"));
$infe4 =$ine->result->first_name;
$infe2 =$ine->result->id;
$infe3 =$ine->result->username;
bot('sendMessage', [
'chat_id'=>$chat_id,
'text'=>"*🎯| INFO MEMBER*
🔖| Name 💬 : *$infe4* \n 🎧| User 💌 : [@$infe3] \n 📚| Id 🎄 : `$infe2`",
'reply_to_message_id'=>$message->message_id,
'parse_mode'=>'MarkDown', 
]);
unlink("com.txt");
}
#معلومات بالمعرف
if($data == "infous" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","infus");
 bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسسنا الان ارسل معرف العضو الذي تريد استخراج معلوماته",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
}

if($bot == "infus" and $text != "/start"and in_array($chat_id,$ad)){
$get = json_decode(file_get_contents("https://mohammed-api.000webhostapp.com/Madeline?UserName=$text"));
$getinfo = $get->info;
$getId           =  $getinfo->UserId;
$getname           = $getinfo->FirstName;
$getuser           = $getinfo->UserName;
$getabout          = $getinfo->About;
$getDate           = $getinfo->Date;
$getTime           = $getinfo->Time;
$getChannel        = $getinfo->Channel;
bot("SendMessage",[
'chat_id'=>$chat_id,
'text'=>"
الايدي : $getId
اليوزر : @$getuser     
الاسم : $getname     
النبذه : $getabout     
التاريخ الان [ توقيت بغداد ] : $getDate
الوقت الان [توقيت بغداد ] : $getTime        ",
]);
unlink('com.txt');
}
#شتراك اجباري1
if($data == "add2" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","ab");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📦| حسـننا عزيزي قم برسال معرف قناتك مـندون ل @
📥| كمثال : `I8F8I`",
'parse_mode'=>"Markdown",
]);
}
if($bot == "ab" and $text != "/h" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("chc.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🎯| حسننا عزيزي تم حفظ قناتك الان قم برفعي مشرف في قناتك .
📮| قناتك : @$text.
لرجوع اضغط /start.",
'reply_to_message_id'=>$message->message_id,
]);
unlink("com.txt");
}
#شـترآك اجباري1
if($data == "add1" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","al");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📦| حسـننا عزيزي قم برسال معرف قناتك مـندون ل @
📚| كمثال : `I8F8I`",
'parse_mode'=>"Markdown",
]);
}

if($bot == "al" and $text != "/h" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("ch.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"🎯| حسننا عزيزي تم حفظ قناتك الان قم برفعي مشرف في قناتك .
📮| قناتك : @$text.
لرجوع اضغط /start.",
'reply_to_message_id'=>$message->message_id,
]);
unlink("com.txt");
}
#شتراك خاص
if($data == "add"  and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","vv");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📌| حسننا عزيزي قم برسال ايدي قناتك !
📮| كمثال : `-1001416392355` !
📎| آن لم تعرف كيفه استخراج ايدي قناتك كل ماعليك قم برسال توجيه من قناتك لهاذ البوت ! @X59BoT !
لرجوع اضغط /start.",
'parse_mode'=>"Markdown",
]);
}

if($bot == "vv" and $text != "/o" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("com.txt","alo");
file_put_contents("id.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"✂| تم حفظ ايدي قناتك !
📛| حسننا الان قم برسال رابط قناتك !
لرجوع اضغط /start.",
'reply_to_message_id'=>$message->message_id,
]);
}
if($bot == "alo" and $text != "/o" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("rabt.txt","$text");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"💛| تم حفظ رابط القناة .
📚| رابط قناتك : `[$text]`
🔖| آيدي قناتك : `$all`
🔖| آلآن قم برفع لبوت مشرفي في قناتك
لرجوع اضغط /start.",
'parse_mode'=>"Markdown",
'reply_to_message_id'=>$message->message_id,
]);
unlink("com.txt");
}
#حذف قنوات
if($data == "remch" and in_array($chat_id2,$ad)  ){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"📦| تم حذف جميع القنوات،",
'parse_mode'=>"Markdown",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);   
unlink("rabt.txt");
unlink("id.txt");
unlink("ch.txt");
unlink("chc.txt");
}
#آذآعه MarkDown
if($data == "MarkDown" and in_array($chat_id2,$ad) ){
file_put_contents("com.txt","sendm");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسننا يمكنك يمكنك ارسال رساله و استخدام MarkDown .",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$alshh3 = fgets($ali);
if($bot == "sendm" and in_array($chat_id,$ad) ){
bot('sendMessage', [
'chat_id' =>$alshh3,
'text'=>$text,
'parse_mode'=>"html",
'disable_web_page_preview' =>"true"
]);
unlink("com.txt");
}
}

#اذاعه HTML
if($data == "HTML" and in_array($chat_id2,$ad) ){
file_put_contents("com.txt","sendh");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسننا عزيزي يمكنك ارسال رساله و استخدام HTML .",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$alshh3 = fgets($ali);
if($bot == "sendh" and in_array($chat_id,$ad) ){
bot('sendMessage', [
'chat_id' =>$alshh3,
'text'=>$text,
'parse_mode'=>"html",
'disable_web_page_preview' =>"true"
]);
unlink("com.txt");
}
}
#اذاعه مجموعات
$gy = explode("\n",file_get_contents("group.txt"));
if($data == "sndgp" and in_array($chat_id2,$ad) ){
file_put_contents("com.txt","sendap");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسننا ارسل رسالتك لكي اقوم برساله لل جميع مجموعات.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "send" and in_array($chat_id,$ad)  ){
foreach ($gy as $id){
bot('sendmessage',[
'chat_id'=>$id,
'text'=>$text,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);
}
unlink('com.txt');
}
#اذاعه للكل
$mee = explode("\n",file_get_contents("alsh/Alsh.txt"));
if($data == "sendall" and in_array($chat_id2,$ad) ){
file_put_contents("com.txt","sendap");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسننا ارسل رسالتك لكي اقوم برساله لل جميع مجموعات و اعضاء.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "sendap" and in_array($chat_id,$ad)  ){
foreach ($gy as $id){
bot('sendmessage',[
'chat_id'=>$id,
'text'=>$text,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);
foreach ($mee as $idd){
bot('sendmessage',[
'chat_id'=>$id,
'text'=>$text,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);
}
unlink('com.txt');
}
}
#اذاعه
if($data == "bc" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","send");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>" ارسل رسالتك الان عزيزي 🎯.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$alshh3 = fgets($ali);
if($bot == "send" and in_array($chat_id,$ad)  ){
bot('sendMessage', [
'chat_id' =>$alshh3,
'text'=>$text,
'disable_web_page_preview' =>"true"
]);
unlink("com.txt");
}
}
$tx = file_get_contents("alh.txt");
if($data == "inln" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","sn");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسـننآ آلآن ارسل نص تريد نشرة ك منشور شفاف 🎁. #ملاحظه يمكنك استخدام الماركدوان ايضا",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "sn" and $text != "/start" and in_array($chat_id,$ad)  ){
file_put_contents("alh.txt","$text");
file_put_contents("com.txt","snn");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"حسننا الان استخدم🎄.
text = link
text = link + text = link
نص = رابط
نص = رابط + نص = رابط",
'reply_to_message_id'=>$message->message_id,
]);
}
$i=0;
$keyboard = [];
$keyboard["inline_keyboard"] = [];
$rows = explode("\n",$text);
foreach($rows as $row){
$j=0;
$keyboard["inline_keyboard"][$i]=[];
$bottons = explode("+",$row);
foreach($bottons as $botton){
$alsh = explode("=",$botton."=");
$Ibotton = ["text" => trim($alsh[0]), "url" => trim($alsh[1])];
$keyboard["inline_keyboard"][$i][$j] = $Ibotton;
$j++;                }                $i++;            }
$reply_markup=json_encode($keyboard);
if($bot == "snn" and $text != "/start" and in_array($chat_id,$ad)  ){
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$alshh = fgets($ali);
bot('sendmessage',[
'chat_id'=>$alshh,
'text'=>$tx,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'reply_markup'=>($reply_markup)
]);
}
unlink("com.txt");
unlink("alh.txt");
}
if($data == "for" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","fd");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>" ارسل توجيهك الان عزيزي 📌.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "fd" and $text != "/start" and in_array($chat_id,$ad)  ){
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$ali2 = fgets($ali);
bot('forwardMessage',[
 'chat_id'=>$ali2,
 'from_chat_id'=>$chat_id,
 'message_id'=>$message->message_id,
 ]);
 unlink("com.txt");
 }
 }
 if($data == "med" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","mide");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"🔖| حسـننآ الان ارسل احد ميديا،
📌| مثلا : صور،فيديو،ملف،اغنيه،ملصق،ملف صوتي،",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
#اذاعه ب ميديا
 if($message->video and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
 $ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
bot('sendvideo',['chat_id'=>$aly,'video'=>$message->video->file_id,'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,]);
bot('sendmessage',[ 
'chat_id'=>$chat_id, 'text'=>"تم نشر الفيديو '📚!",]); }unlink("com.txt"); }
if($message->document and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
bot('Senddocument',['chat_id'=>$aly,'document'=>$message->document->file_id,'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
]);bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الملف او متحركه '🎻!", ]); } unlink("com.txt");}
 if($message->audio and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
 	$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
 bot('sendaudio',[    'chat_id'=>$aly,    'audio'=>$message->audio->file_id,    'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
 ]); bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الاغنيه '🎺!", ]); } unlink("com.txt");}
if($message->photo and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
	$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
    bot('sendPhoto',[      'chat_id'=>$aly,      'photo'=>$message->photo[0]->file_id,      'caption'=>$message->caption,      'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
    ]);bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الصورة '📇!", ]); } unlink("com.txt");}
if($message->voice and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
	$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
    bot('sendvoice',[     'chat_id'=>$aly,      'voice'=>$message->voice->file_id,     'caption'=>$message->caption,'parse_mode'=>"MARKDOWN",'disable_web_page_preview'=>true,
      ]);      bot('sendmessage',[ 'chat_id'=>$chat_id, 'text'=>"تم نشر الاغنيه '📜!", ]); } unlink("com.txt");}
      if($message->sticker and $bot == "mide" and in_array($chat_id,$ad)   and $text != "/start"){
      	$ali = fopen( "alsh/Alsh.txt", 'r');
while(!feof( $ali)){
$aly = fgets($ali);
bot('sendsticker',['chat_id'=>$aly,'sticker'=>$message->sticker->file_id
]);bot('sendmessage',['chat_id'=>$chat_id, 'text'=>"تم نشر الملصق '📂!", ]); }unlink("com.txt"); }
if($data == "get"  and in_array($chat_id2,$ad)){
$AliZip14 = "instagram2.aba.vg"; //مسار استضافتك
date_default_timezone_set("Asia/Baghdad");
$AliZip13 = date("{h-i-s}");
AliZip('../', "Backup-$AliZip13.zip");
bot('senddocument',[
'chat_id'=>$chat_id2,
'document'=>"https://$AliZip14/Backup-$AliZip13.zip",
'caption'=>"Backup. 📦
Today's date : ".date('Y/m/d')." 📆
The Time is : ".date('h:i A')." ⏰
File size : ".AliZip1(filesize("Backup-$AliZip13.zip"))." 🏷",
'reply_to_message_id'=>$AliZip18,
]);
unlink("Backup-$AliZip13.zip");
}
if($data == "upmem" and in_array($chat_id2,$ad)){
$memZip14 = "
instagram2.aba.vg"; //مسار استضافتك
date_default_timezone_set("Asia/Baghdad");
$memZip13 = date("{h-i-s}");
AliZip('alsh', "Mem-$memZip13.zip");
bot('senddocument',[
'chat_id'=>$chat_id2,
'document'=>"https://$memZip14/Mem-$memZip13.zip",
'caption'=>"Mem. 📦
Today's date : ".date('Y/m/d')." 📆
The Time is : ".date('h:i A')." ⏰
File size : ".AliZip1(filesize("Mem-$memZip13.zip"))." 🏷",
]);
unlink("Mem-$memZip13.zip");
}
#رفع نسخه
if($data == "puo" and in_array($chat_id2,$ad) ){
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسـننآ ارسل ملف الان لاكن ارسل صيغ ملف بل txt.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
$repad = $message->reply_to_message->document;
$aduo = $repad->file_id;
if(isset($repad) and in_array($chat_id,$ad)){
$url = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY.'/getFile?file_id='.$aduo),true);
$path = $url['result']['file_path'];
$file = 'https://api.telegram.org/file/bot'.API_KEY.'/'.$path;
$okey = file_put_contents("alsh/Alsh.txt",file_get_contents($file));
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"تم رفع نسخه بنجاح.",
]);
}
#الاشعار
$gg = file_get_contents("onn.txt");
if($gg == "on" and $chat_id != $admin and !$data){
bot("sendmessage",[
"chat_id"=>$admin,
"text"=>"- عضو جديد قام بالدخول الى البوت ، 🛡
- الاسم ، [$chat_id](tg://user?id=$chat_id) ، 🦕
- المعرف ، [@$user](tg://user?id=$chat_id) ، 🐢
- الايدي ، [$chat_id](tg://user?id=$chat_id) ، 🐝 
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎",
 'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>'true',
]);
}
#حفظ كود
if($data == "setphp" and in_array($chat_id2,$ad) ){
file_put_contents("com.txt","set");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"حسـننآ ارسل الكود الان.",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
}
if($bot == "set" and in_array($chat_id,$ad)  ){
file_put_contents("php.php","<?php $text ?>");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"تم حفظ الكود." ,
'parse_mode'=>"Markdown",
]);
unlink('com.txt');
}
if($data == "delphp" and in_array($chat_id2,$ad)  ){
file_put_contents("com.txt","set");
bot('EditMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'text'=>"تم حذف الكود..",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"رجوع ،🎺.","callback_data"=>"bk"]],
]])
]);
unlink("php.php");
}
#By Code : ALSH ، @TTTITT ، MY CH @Api_File_Code

$Dev = array("1010918290"); // ايديك
$usernamebot = "zvxbot"; // معرف  بوتك حبي
$abbas = "AWM_AWN"; // معرف  قناتك بدون @   //
$token = API_KEY;
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$text = $message->text;
$firstname = $update->callback_query->from->first_name;
$usernames = $update->callback_query->from->username;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$membercall = $update->callback_query->id;
$reply = $update->message->reply_to_message->forward_from->id;
$data = $update->callback_query->data;
$messageid = $update->callback_query->message->message_id;
$tc = $update->message->chat->type;
$gpname = $update->callback_query->message->chat->title;
$namegroup = $update->message->chat->title;
$text = $update->inline_qurey->qurey;
$newchatmemberid = $update->message->new_chat_member->id;
$newchatmemberu = $update->message->new_chat_member->username;
$rt = $update->message->reply_to_message;
$replyid = $update->message->reply_to_message->message_id;
$tedadmsg = $update->message->message_id;
$edit = $update->edited_message->text;
$re_id = $update->message->reply_to_message->from->id;
$re_user = $update->message->reply_to_message->from->username;
$re_name = $update->message->reply_to_message->from->first_name;
$re_msgid = $update->message->reply_to_message->message_id;
$re_chatid = $update->message->reply_to_message->chat->id;
$message_edit_id = $update->edited_message->message_id;
$chat_edit_id = $update->edited_message->chat->id;
$edit_for_id = $update->edited_message->from->id;
$edit_chatid = $update->callback_query->edited_message->chat->id;
$caption = $update->message->caption;
$chatid3=$update->message->chat->id;
$fromid3=$update->message->from->id;
$text=$update->message->text;
$mid=$update->message->message_id;
$statjson = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$chat_id&user_id=".$from_id),true);
$status = $statjson['result']['status'];
$statjsonrt = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$chat_id&user_id=".$re_id),true);
$statusrt = $statjsonrt['result']['status'];
$statjsonq = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$chatid&user_id=".$fromid),true);
$statusq = $statjsonq['result']['status'];
$info = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$chat_edit_id&user_id=".$edit_for_id),true);
$you = $info['result']['status'];
$forchannel = json_decode(file_get_contents("https://api.telegram.org/bot".$token."/getChatMember?chat_id=@".$channel."&user_id=".$from_id));
$tch = $forchannel->result->status;
$title =$message->chat->title;
$rep = $message->reply_to_message;
$settings = json_decode(file_get_contents("data/$chat_id.json"),true);
$settings2 = json_decode(file_get_contents("data/$chatid.json"),true);
$editgetsettings = json_decode(file_get_contents("data/$chat_edit_id.json"),true);
$user = json_decode(file_get_contents("data/user.json"),true);
$filterget = $settings["filterlist"];

if ($text == "/start"){
file_put_contents("ali.txt",""); 
  bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"- اهلا بك مرة اخرى ؛ ♥️ [$name](tg://user?id=$chat_id)
• - في بوت الانحراف الاول على منصه التلكرام 🔞؛
- • البوت يحتوي على الكثير من الافلام 🔞؛
 • - يتم تحديث البوت يوميآ واضافه الكثير من الافلام 🤫؛
اضغط على الافلام لعرض قائمه الافلام 😉🔞 ;,
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🔞¦ قسم الافلام والمتحركة"]],
]
])
]);
}
if($text == '🔞¦ قسم الافلام والمتحركة'){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"☑¦  آهہ‏‏لآ عزيزي $name📌•
😉¦ آليك قائمـهہ‏‏ 🔞 الافلام والصور المتحركة
...
👙¦ اختر القسم الذي يعجبك √ 

",
'reply_markup'=>json_encode([ 
'keyboard'=>[ 
[['text'=>'🔞¦ قسم المتحركهه'],['text'=>'🔞¦ قسم الافلام']],
] 
]) 
]); 
}
if($text == '🔞¦ قسم المتحركهه'){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"🔞¦  آهہ‏‏لآ عزيزي $name😉•
😉¦ آليك قائمـهہ‏‏ 🔞 المتحركات السكسيه
...
🤭¦ اختر التحركه الذي يعجبك وسأقوم بأرساله لك √
",

'reply_markup'=>json_encode([ 
'keyboard'=>[ 
[['text'=>'😉¦ xxx - 1'],['text'=>'😉¦ xxx - 2']],
[['text'=>'😉¦ xxx - 3'],['text'=>'😉¦ xxx - 4']],
[['text'=>'😉¦ xxx - 5'],['text'=>'😉¦ xxx - 6']],
[['text'=>'😉¦ xxx - 7'],['text'=>'😉¦ xxx - 8']],
[['text'=>'😉¦ xxx - 9'],['text'=>'😉¦ xxx - 10']],
[['text'=>'😉¦ xxx - 11'],['text'=>'😉¦ xxx - 12']],
[['text'=>'😉¦ xxx - 13'],['text'=>'😉¦ xxx - 14']],
[['text'=>'😉¦ xxx - 15'],['text'=>'😉¦ xxx - 16']],
[['text'=>'😉¦ xxx - 17'],['text'=>'😉¦ xxx - 18']],
[['text'=>'😉¦ xxx - 19'],['text'=>'😉¦ xxx - 20']],
[['text'=>'🔞¦ قسم الافلام والمتحركة']],
] 
]) 
]); 
}
if($text == '😉¦ xxx - 1'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/24",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 2'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/26",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 3'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/27",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 4'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/28",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 5'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/29",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 6'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/30",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 7'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/31",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 8'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/32",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 9'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/33",
'caption'=>" Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 10'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/34",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 11'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/35",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 12'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/36",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 13'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/37",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 14'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/38",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 15'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/39",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 16'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/40",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 17'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/41",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 18'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/42",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 19'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/43",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '😉¦ xxx - 20'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/44",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
#قسم صور
if($text == '🔞¦ قسم الافلام'){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"💌¦  آهہ‏‏لآ عزيزي $name📌•
🔞¦ آليك قائمـهہ‏‏ الافلام
...
😉¦ اختر الفلم الذي يعجبك√ 
🔞  وسأقوم بإرساله لك  °
",
'reply_markup'=>json_encode([ 
'keyboard'=>[ 
[['text'=>'🔞¦ xnxx - 1'],['text'=>'🔞¦ xnxx - 2']],
[['text'=>'🔞¦ xnxx - 3'],['text'=>'🔞¦ xnxx - 4']],
[['text'=>'🔞¦ xnxx - 5'],['text'=>'🔞¦ xnxx - 6']],
[['text'=>'🔞¦ xnxx - 7'],['text'=>'🔞¦ xnxx - 8']],
[['text'=>'🔞¦ xnxx - 9'],['text'=>'🔞¦ xnxx - 10']],
[['text'=>'🔞¦ xnxx - 11'],['text'=>'🔞¦ xnxx - 12']],
[['text'=>'🔞¦ xnxx - 13'],['text'=>'🔞¦ xnxx - 14']],
[['text'=>'🔞¦ xnxx - 15'],['text'=>'🔞¦ xnxx - 16']],
[['text'=>'🔞¦ xnxx - 17'],['text'=>'🔞¦ xnxx - 18']],
[['text'=>'🔞¦ xnxx - 19'],['text'=>'🔞¦ xnxx - 20']],
[['text'=>'🔞¦ قسم الافلام والمتحركة']],
] 
]) 
]); 
}
if($text == '🔞¦ xnxx - 1'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/2",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 2'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/3",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 3'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/4",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 4'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/5",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 5'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/6",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 6'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/7",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 7'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/8",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 8'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/9",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 9'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/10",
'caption'=>" Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 10'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/11",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 11'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/12",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 12'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/13",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 13'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/14",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 14'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/15",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 15'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/16",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 16'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/17",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 17'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/18",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 18'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/19",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 19'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/20",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}
if($text == '🔞¦ xnxx - 20'){ 
bot('sendvideo',[
 'chat_id'=>$chat_id,
 'video'=>"https://t.me/LQQBA/21",
'caption'=>"Me channel 🔞 - @$abbas",
'reply_to_message_id'=>$Message->message_id,
 ]);
}

// تخمط اذكر اسمي حبي #كلاوجي
// قناتي @NONBBN
//معرفي @ll8III
//سطر 50ايديك ونوب روح لسطر 1037شوف لمطلوب منك وغيره//