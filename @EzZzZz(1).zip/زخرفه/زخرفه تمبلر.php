<?php 

ob_start();
$API_KEY = "1201007429:AAEp7XZtTEkCTU3Vuai5Q7VzK7akya4M3eU";#توكن البوت
define('API_KEY',$API_KEY);
echo "<a href='https://api.telegram.org/bot$API_KEY/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']."'>setwebhook</a>";
echo file_get_contents("https://api.telegram.org/bot$API_KEY/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']);
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url); curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{return json_decode($res);}}
#         mroan        #
$update   = json_decode(file_get_contents('php://input'));
$message  = $update->message;
$text     = $message->text;
$chat_id  = $message->chat->id;
$name     = $message->from->first_name;
$user     = $message->from->username;
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
$a = strtolower($text);
$T4TTTT = 1010918290; //ايديك
$SAIED = file_get_contents("SAIED.txt");
$SAIED0 = file_get_contents("SAIED0.txt");
$SAIED1= file_get_contents("SAIED1.txt");
$SAIED5 = file_get_contents("SAIED2.txt");
$SAIED6 = file_get_contents("SAIED3.txt");
$SAIED20 = json_decode(file_get_contents('php://input'));
$SAIED18 = $update->message;
$SAIED13 = $SAIED18->chat->id;
$SAIED17 = $SAIED18->text;
$SAIED19 = $SAIED20->callback_query->data;
$SAIED12 = $SAIED20->callback_query->message->chat->id;
$SAIED14 =  $SAIED20->callback_query->message->message_id;
$SAIED15 = $SAIED18->from->first_name;
$SAIED16 = $SAIED18->from->username;
$SAIED11 = $SAIED18->from->id;
$SAIED2 = explode("\n",file_get_contents("SAIED4.txt"));
$SAIED3 = count($SAIED2)-1;
if ($SAIED18 && !in_array($SAIED11, $SAIED2)) {
    file_put_contents("SAIED4.txt", $SAIED11."\n",FILE_APPEND);
  }
$SAIED9 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$SAIED0&user_id=".$SAIED11);
$SAIED10 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$SAIED1&user_id=".$SAIED11);
if($SAIED18 && (strpos($SAIED9,'"status":"left"') or strpos($SAIED9,'"Bad Request: USER_ID_INVALID"') or strpos($SAIED9,'"status":"kicked"') or strpos($SAIED10,'"status":"left"') or strpos($SAIED10,'"Bad Request: USER_ID_INVALID"') or strpos($SAIED10,'"status":"kicked"'))!== false){
bot('sendMessage', [
'chat_id'=>$SAIED13,
'text'=>'- اشترك في قنوات البوت أولا لتتمكن من إستخدامه 🤖".

'.$SAIED0.'
'.$SAIED1,
]);return false;}
if($SAIED17 == "SAIED" and $SAIED11 == $T4TTTT){
bot("sendmessage",[
"chat_id"=>$SAIED13,
"text"=>'- أهلا بك في قائمة المطور 👨🏻‍✈️".',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- أوامر قناة الإشتراك الإجباري الأولى 📡1⃣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- وضع قناة 📡✅".' ,'callback_data'=>"SAIED0"],['text'=>'- حذف القناة 📡❎".' ,'callback_data'=>"SAIED1"]],
[['text'=>'- أوامر قناة الإشتراك الإجباري الثانية 📢2⃣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- وضع قناة 📢✅".' ,'callback_data'=>"SAIED2"],['text'=>'- حذف القناة 📢❎".' ,'callback_data'=>"SAIED3"]],
[['text'=>'- عرض قنوات الإشتراك الإجباري 📜".' ,'callback_data'=>"SAIED4"]],
[['text'=>'- أوامر الإذاعة 🗣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- نشر توجيه ↪️".' ,'callback_data'=>"SAIED5"],['text'=>'- نشر رسالة 📝".' ,'callback_data'=>"SAIED6"]],
[['text'=>'- عدد المشتركين 👥".' ,'callback_data'=>"SAIED7"]],
[['text'=>'- التنبيه عند دخول أحد للبوت 🚸".' ,'callback_data'=>"SAIED"]],
[['text'=>'- تفعيل التنبيه 🚸✅".' ,'callback_data'=>"SAIED9"],['text'=>'- تعطيل التنبيه 🚸❎".' ,'callback_data'=>"SAIED10"]],
[['text'=>'- توجيه الرسائل من الأعضاء 🔃".' ,'callback_data'=>"SAIED"]],
[['text'=>'- تفعيل للتوجيه 🔃✅".' ,'callback_data'=>"SAIED11"],['text'=>'- تعطيل للتوجيه 🔃❎".' ,'callback_data'=>"SAIED12"]],
   ] 
   ])
]);
}
if($SAIED19 == "SAIED" ){
bot('EditMessageText',[
'chat_id'=>$SAIED12,
'message_id'=>$SAIED14,
"text"=>'- أهلا بك في قائمة المطور 👨🏻‍✈️".',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- أوامر قناة الإشتراك الإجباري الأولى 📡1⃣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- وضع قناة 📡✅".' ,'callback_data'=>"SAIED0"],['text'=>'- حذف القناة 📡❎".' ,'callback_data'=>"SAIED1"]],
[['text'=>'- أوامر قناة الإشتراك الإجباري الثانية 📢2⃣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- وضع قناة 📢✅".' ,'callback_data'=>"SAIED2"],['text'=>'- حذف القناة 📢❎".' ,'callback_data'=>"SAIED3"]],
[['text'=>'- عرض قنوات الإشتراك الإجباري 📜".' ,'callback_data'=>"SAIED4"]],
[['text'=>'- أوامر الإذاعة 🗣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- نشر توجيه ↪️".' ,'callback_data'=>"SAIED5"],['text'=>'- نشر رسالة 📝".' ,'callback_data'=>"SAIED6"]],
[['text'=>'- عدد المشتركين 👥".' ,'callback_data'=>"SAIED7"]],
[['text'=>'- التنبيه عند دخول أحد للبوت 🚸".' ,'callback_data'=>"SAIED"]],
[['text'=>'- تفعيل التنبيه 🚸✅".' ,'callback_data'=>"SAIED9"],['text'=>'- تعطيل التنبيه 🚸❎".' ,'callback_data'=>"SAIED10"]],
[['text'=>'- توجيه الرسائل من الأعضاء 🔃".' ,'callback_data'=>"SAIED"]],
[['text'=>'- تفعيل للتوجيه 🔃✅".' ,'callback_data'=>"SAIED11"],['text'=>'- تعطيل للتوجيه 🔃❎".' ,'callback_data'=>"SAIED12"]],
   ] 
   ])
]);
unlink("SAIED.txt");
}
if($SAIED19 == "SAIED0"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- أرسل معرف القناة الآن Ⓜ️".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- إلغاء ❌".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED.txt","SAIED0");
}
if($SAIED17 and $SAIED == "SAIED0" and $SAIED11 == $T4TTTT){
bot("sendmessage",[
"chat_id"=>$SAIED13,
"text"=>'- تم حفظ معرف القناة بنجاح ✅".

- تأكد من أن البوت أدمن في القناة ليتم تفعيل الإشتراك الإجباري 👨🏻‍✈️".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED0.txt","$SAIED17");
unlink("SAIED.txt");
}
if($SAIED19 == "SAIED1"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم حذف القناة بنجاح ✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
unlink("SAIED0.txt");
}
if($SAIED19 == "SAIED2"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- أرسل معرف القناة الآن Ⓜ️".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- إلغاء ❌".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED.txt","SAIED1");
}
if($SAIED17 and $SAIED == "SAIED1" and $SAIED11 == $T4TTTT){
bot("sendmessage",[
"chat_id"=>$SAIED13,
"text"=>'- تم حفظ معرف القناة بنجاح ✅".

- تأكد من أن البوت أدمن في القناة ليتم تفعيل الإشتراك الإجباري 👨🏻‍✈️".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED1.txt","$SAIED17");
unlink("SAIED.txt");
}
if($SAIED19 == "SAIED3"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم حذف القناة بنجاح ✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
unlink("SAIED1.txt");
}
if($SAIED19 == "SAIED4"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- هذه هي قائمة قنوات الإشتراك الإجباري 📜".

- القناة الأولى '.$SAIED0.' 📡".

- القناة الثانية '.$SAIED1.' 📢".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
}
if($SAIED19 == "SAIED5"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- أرسل رسالتك ليتم نشرها توجيه لجميع الأعضاء ↪️".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- إلغاء ❌".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED.txt","SAIED2");
}
if($SAIED18 and $SAIED == "SAIED2" and $SAIED11 == $T4TTTT){
bot("sendmessage",[
"chat_id"=>$SAIED13,
"text"=>'- تم التوجيه بنجاح ✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
for($i=0;$i<count($SAIED2); $i++){
bot('forwardMessage', [
'chat_id'=>$SAIED2[$i],
'from_chat_id'=>$SAIED11,
'message_id'=>$SAIED18->message_id
]);
unlink("SAIED.txt");
}
}
if($SAIED19 == "SAIED6"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- أرسل رسالتك ليتم نشرها رسالة لجميع الأعضاء 📝".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- إلغاء ❌".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED.txt","SAIED3");
}
if($SAIED17 and $SAIED == "SAIED3" and $SAIED11 == $T4TTTT){
bot("sendmessage",[
"chat_id"=>$SAIED13,
"text"=>'- تم النشر بنجاح ✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
for($i=0;$i<count($SAIED2); $i++){
bot('sendMessage', [
'chat_id'=>$SAIED2[$i],
'text'=>$SAIED17
]);
unlink("SAIED.txt");
}
}
if($SAIED19 == "SAIED7"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- عدد مشتركين البوت هو '.$SAIED3.' 👥".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
}
if($SAIED19 == "SAIED9"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم تفعيل تنبيه دخول الأعضاء 🚸✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED2.txt","SAIED");
}
if($SAIED17 == "/start" and $SAIED5 == "SAIED" and $SAIED11 != $T4TTTT){
bot("sendmessage",[
"chat_id"=>$T4TTTT,
"text"=>'- دخل شخص إلى البوت 🚶‍♂".

- اسمه '.$SAIED15.' 🔠".

- معرفه '.$SAIED16.' Ⓜ️".

- ايديه '.$SAIED11.' 🆔".',
]);
}
if($SAIED19 == "SAIED10"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم تعطيل تنبيه دخول الأعضاء 🚸❎".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
unlink("SAIED2.txt");
}
if($SAIED19 == "SAIED11"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم تفعيل توجيه الرسائل 🔃✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED3.txt","SAIED");
}
if($SAIED18 and $SAIED6 == "SAIED" and $SAIED11 != $T4TTTT){
bot('forwardMessage', [
'chat_id'=>$T4TTTT,
'from_chat_id'=>$SAIED11,
'message_id'=>$SAIED18->message_id
]);
}
if($SAIED18 and $SAIED6 == "SAIED" and $SAIED11 == $T4TTTT){
bot('sendMessage',[
'chat_id'=>$SAIED18->reply_to_message->forward_from->id,
    'text'=>$SAIED17,
    ]);
}
if($SAIED19 == "SAIED12"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم تعطيل توجيه الرسائل 🔃❎".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
unlink("SAIED3.txt");
}
if ($text == '/start' && !in_array($chat_id, $band)){
    bot('sendMessage',[
        'chat_id'=>$chat_id,
         'text' => "- اهلا بك ؛ [$name](tg://user?id=$chat_id)
- ارسل اسمك بالانكليزيةه وانتظر قليلا ، 🕊 '
- يمنع استخدام الاحرف العربية او الرموز ، 📄'
- ارسل اسمك وقم بتجربته بنفسك ، 🌼'
• يتم اضافةه حروف جديد كل يوم ،♥!' 
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[• اضغط هنا وتابع جديدنا،♥](https://t.me/ThePHPbots),
'parse_mode' => 'MarcDown', 'disable_web_page_preview' => true, 'reply_markup' => json_encode(['inline_keyboard' => [[['text' => "• اضغط هنا وتابع قناة البوت ، 🔰" , 'url' =>"t.me/thephpbots" ]], ]]) ]);
}
if($_GET['s']){
    $text = 'sssasa';
    echo $count = count($text); 
}
if($text != '/start'and$text!='/us'){
  $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
   $k = strtolower('a','𝐴',$k); 
 $a = str_replace('b','𝐵',$k); 
 $k = str_replace('c','𝐶',$k); 
 $k = str_replace('d','𝐷',$k); 
 $k = str_replace('e','𝐸',$k); 
 $k = str_replace('f','𝐹',$k); 
 $k = str_replace('g','𝐺',$k); 
 $k = str_replace('h','𝐻',$k); 
 $k = str_replace('i','𝐼',$k); 
 $k = str_replace('j','𝐽',$k); 
 $k = str_replace('k','𝐾',$k); 
 $k = str_replace('l','𝐿',$k); 
 $k = str_replace('m','𝑀',$k); 
 $k = str_replace('n','𝑁',$k); 
 $k = str_replace('o','𝑂',$k); 
 $k = str_replace('p','𝑃',$k); 
 $k = str_replace('q','𝑄',$k); 
 $k = str_replace('r','𝑅',$k); 
 $k = str_replace('s','𝑆',$k); 
 $k = str_replace('t','𝑇',$k); 
 $k = str_replace('u','𝑈',$k); 
 $k = str_replace('v','𝑉',$k); 
 $k = str_replace('w','𝑊',$k); 
 $k = str_replace('x','𝑋',$k); 
 $k = str_replace('y','𝑌',$k); 
 $k = str_replace('z','𝑍',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
$k = str_replace('a','𝐀',$text); 
 $k = str_replace('b','𝐁',$k); 
 $k = str_replace('c','𝐂',$k); 
 $k = str_replace('d','𝐃',$k); 
 $k = str_replace('e','𝐄',$k); 
 $k = str_replace('f','𝐅',$k); 
 $k = str_replace('g','𝐆',$k); 
 $k = str_replace('h','𝐇',$k); 
 $k = str_replace('i','𝐈',$k); 
 $k = str_replace('j','𝐉',$k); 
 $k = str_replace('k','𝐊',$k); 
 $k = str_replace('l','𝐋',$k); 
 $k = str_replace('m','𝐌',$k); 
 $k = str_replace('n','𝐍',$k); 
 $k = str_replace('o','𝐎',$k); 
 $k = str_replace('p','𝐏',$k); 
 $k = str_replace('q','𝐐',$k); 
 $k = str_replace('r','𝐑',$k); 
 $k = str_replace('s','𝐒',$k); 
 $k = str_replace('t','𝐓',$k); 
 $k = str_replace('u','𝐔',$k); 
 $k = str_replace('v','𝐕',$k); 
 $k = str_replace('w','𝐖',$k); 
 $k = str_replace('x','𝐗',$k); 
 $k = str_replace('y','𝐘',$k); 
 $k = str_replace('z','𝐙',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
   $k = str_replace('a','𝖆',$text); 
 $k = str_replace('b','𝖇',$k); 
 $k = str_replace('c','𝖈',$k); 
 $k = str_replace('d','𝖉',$k); 
 $k = str_replace('e','𝖊',$k); 
 $k = str_replace('f','𝖋',$k); 
 $k = str_replace('g','𝖌',$k); 
 $k = str_replace('h','𝖍',$k); 
 $k = str_replace('i','𝖎',$k); 
 $k = str_replace('j','𝖏',$k); 
 $k = str_replace('k','𝖐',$k); 
 $k = str_replace('l','𝖑',$k); 
 $k = str_replace('m','𝖒',$k); 
 $k = str_replace('n','𝖓',$k); 
 $k = str_replace('o','𝖔',$k); 
 $k = str_replace('p','𝖕',$k); 
 $k = str_replace('q','𝖖',$k); 
 $k = str_replace('r','𝖗',$k); 
 $k = str_replace('s','𝖘',$k); 
 $k = str_replace('t','𝖙',$k); 
 $k = str_replace('u','𝖚',$k); 
 $k = str_replace('v','𝖛',$k); 
 $k = str_replace('w','𝖜',$k); 
 $k = str_replace('x','𝖝',$k); 
 $k = str_replace('y','𝖞',$k); 
 $k = str_replace('z','𝖟',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
   $k = str_replace('a','𝙰',$text); 
 $k = str_replace('b','𝙱',$k); 
 $k = str_replace('c','𝙲',$k); 
 $k = str_replace('d','𝙳',$k); 
 $k = str_replace('e','𝙴',$k); 
 $k = str_replace('f','𝙵',$k); 
 $k = str_replace('g','𝙶',$k); 
 $k = str_replace('h','𝙷',$k); 
 $k = str_replace('i','𝙸',$k); 
 $k = str_replace('j','𝙹',$k); 
 $k = str_replace('k','𝙺',$k); 
 $k = str_replace('l','𝙻',$k); 
 $k = str_replace('m','𝙼',$k); 
 $k = str_replace('n','𝙽',$k); 
 $k = str_replace('o','𝙾',$k); 
 $k = str_replace('p','𝙿',$k); 
 $k = str_replace('q','𝚀',$k); 
 $k = str_replace('r','𝚁',$k); 
 $k = str_replace('s','𝚂',$k); 
 $k = str_replace('t','𝚃',$k); 
 $k = str_replace('u','𝙺',$k); 
 $k = str_replace('v','𝚅',$k); 
 $k = str_replace('w','𝚆',$k); 
 $k = str_replace('x','𝚇',$k); 
 $k = str_replace('y','𝚈',$k); 
 $k = str_replace('z','𝚉',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   
   ]); 
   $k = $text;
$k=str_replace('қ','q​',$k);
$k=str_replace('я','ya',$k);
$k=str_replace('е','e​',$k);
$k=str_replace('р','r​',$k);
$k=str_replace('т','t​',$k);
$k=str_replace('й','y​',$k);
$k=str_replace('у','u​',$k);
$k=str_replace('и','i​',$k);
$k=str_replace('о','o​',$k);
$k=str_replace('п','p',$k);
$k=str_replace('а','a​',$k);
$k=str_replace('с','s',$k);
$k=str_replace('д','d',$k);
$k=str_replace('ф','f',$k);
$k=str_replace('г','g​',$k);
$k=str_replace('х','h​',$k);
$k=str_replace('ж','j​',$k);
$k=str_replace('к','​k',$k);
$k=str_replace('л','l​',$k);
$k=str_replace('з','z​',$k);
$k=str_replace('ҳ','x',$k);
$k=str_replace('с','c​',$k);
$k=str_replace('в','v',$k);
$k=str_replace('б','b​',$k);
$k=str_replace('н','n​',$k);
$k=str_replace('м','m​',$k);
$k=str_replace('ё','yo​',$k);
$k=str_replace('ғ','g‘​',$k);
$k=str_replace('ъ','‘​',$k);
$k=str_replace('ш','sh',$k);
bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
$k=str_replace('q','қ ​',$k);
$k=str_replace('ya','я',$k);
$k=str_replace('e','е​',$k);
$k=str_replace('r','р​',$k);
$k=str_replace('t','т​',$k);
$k=str_replace('y','й​',$k);
$k=str_replace('u','у​',$k);
$k=str_replace('i','и​',$k);
$k=str_replace('o','о​',$k);
$k=str_replace('p','п​',$k);
$k=str_replace('a','а​',$k);
$k=str_replace('s','с​',$k);
$k=str_replace('d','д​',$k);
$k=str_replace('f','ф​',$k);
$k=str_replace('g','г​',$k);
$k=str_replace('h','х​',$k);
$k=str_replace('j','ж​',$k);
$k=str_replace('k','​к',$k);
$k=str_replace('l','л​',$k);
$k=str_replace('z','з​',$k);
$k=str_replace('x','ҳ',$k);
$k=str_replace('c','с​',$k);
$k=str_replace('v','в',$k);
$k=str_replace('b','б​',$k);
$k=str_replace('n','н​',$k);
$k=str_replace('m','м​',$k);
$k=str_replace('yo','ё​',$k);
$k=str_replace('g‘','ғ​',$k);
$k=str_replace('‘','ъ​',$k);
$k=str_replace('sh','ш',$k);
bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
$k=str_replace('q','🇶​',$k);
$k=str_replace('w','🇼​',$k);
$k=str_replace('e','🇪​',$k);
$k=str_replace('r','🇷​',$k);
$k=str_replace('t','🇹​',$k);
$k=str_replace('y','🇾​',$k);
$k=str_replace('u','🇺​',$k);
$k=str_replace('i','🇮​',$k);
$k=str_replace('o','🇴​',$k);
$k=str_replace('p','🇵​',$k);
$k=str_replace('a','🇦​',$k);
$k=str_replace('s','🇸​',$k);
$k=str_replace('d','🇩​',$k);
$k=str_replace('f','🇫​',$k);
$k=str_replace('g','🇬​',$k);
$k=str_replace('h','🇭​',$k);
$k=str_replace('j','🇯​',$k);
$k=str_replace('k','​🇰',$k);
$k=str_replace('l','🇱​',$k);
$k=str_replace('z','🇿​',$k);
$k=str_replace('x','🇽​',$k);
$k=str_replace('c','🇨​',$k);
$k=str_replace('v','🇻​',$k);
$k=str_replace('b','🇧​',$k);
$k=str_replace('n','🇳​',$k);
$k=str_replace('m','🇲​',$k);
bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
$k=str_replace('q','q​',$k);
$k=str_replace('w','ω​',$k);
$k=str_replace('e','є​',$k);
$k=str_replace('r','я​',$k);
$k=str_replace('t','т​',$k);
$k=str_replace('y','у​',$k);
$k=str_replace('u','υ​',$k);
$k=str_replace('i','ι​',$k);
$k=str_replace('o','σ​',$k);
$k=str_replace('p','ρ​',$k);
$k=str_replace('a','α​',$k);
$k=str_replace('s','ѕ​',$k);
$k=str_replace('d','∂​',$k);
$k=str_replace('f','f​',$k);
$k=str_replace('g','g​',$k);
$k=str_replace('h','н​',$k);
$k=str_replace('j','ʝ​',$k);
$k=str_replace('k','​к',$k);
$k=str_replace('l','ℓ​',$k);
$k=str_replace('z','z​',$k);
$k=str_replace('x','χ​',$k);
$k=str_replace('c','¢​',$k);
$k=str_replace('v','ν​',$k);
$k=str_replace('b','в​',$k);
$k=str_replace('n','и​',$k);
$k=str_replace('m','м​',$k);
bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
$k=str_replace('q','🍳​',$k);
$k=str_replace('w','👐​',$k);
$k=str_replace('e','📧​',$k);
$k=str_replace('r','®​',$k);
$k=str_replace('t','🌴​',$k);
$k=str_replace('y','🌱​',$k);
$k=str_replace('u','⛎​',$k);
$k=str_replace('i','📍',$k);
$k=str_replace('o','⭕​',$k);
$k=str_replace('p','🅿​',$k);
$k=str_replace('s','⚡​',$k);
$k=str_replace('d','👌​',$k);
$k=str_replace('f','🎏​',$k);
$k=str_replace('g','❡​',$k);
$k=str_replace('h','♓​',$k);
$k=str_replace('j','🎷​',$k);
$k=str_replace('k','​🎋',$k);
$k=str_replace('l','👢​',$k);
$k=str_replace('z','🍃​',$k);
$k=str_replace('x','❌​',$k);
$k=str_replace('c','🍉​',$k);
$k=str_replace('v','♈​',$k);
$k=str_replace('b','🅱​',$k);
$k=str_replace('n','🎵​',$k);
$k=str_replace('m','Ⓜ​',$k);
bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
$k=str_replace('q','q̲̅​',$k);
$k=str_replace('w','w̲̅​',$k);
$k=str_replace('e','e̲̅​',$k);
$k=str_replace('r','r̲̅​',$k);
$k=str_replace('t','t̲̅​',$k);
$k=str_replace('y','y̲̅​',$k);
$k=str_replace('u','u̲̅​',$k);
$k=str_replace('i','i̲̅​',$k);
$k=str_replace('o','o̲̅​',$k);
$k=str_replace('p','p̲̅​',$k);
$k=str_replace('a','a̲̅​',$k);
$k=str_replace('s','s̲̅​',$k);
$k=str_replace('d','d̲̅​',$k);
$k=str_replace('f','f̲̅​',$k);
$k=str_replace('g','g̲̅​',$k);
$k=str_replace('h','h̲̅​',$k);
$k=str_replace('j','j̲̅​',$k);
$k=str_replace('k','​k̲̅',$k);
$k=str_replace('l','l̲̅​',$k);
$k=str_replace('z','z̲̅​',$k);
$k=str_replace('x','x̲̅​',$k);
$k=str_replace('c','c̲̅​',$k);
$k=str_replace('v','v̲̅​',$k);
$k=str_replace('b','b̲̅​',$k);
$k=str_replace('n','n̲̅​',$k);
$k=str_replace('m','m̲̅​',$k);
$bot->sendMessage($cid, "$k");
}
if(mb_stripos($mtext,"#text5") !== false){
$c = explode(">",$mtext);
$k = $c[1];
$k=str_replace('q','ǫ​',$k);
$k=str_replace('w','ᴡ​',$k);
$k=str_replace('e','ᴇ​',$k);
$k=str_replace('r','ʀ​',$k);
$k=str_replace('t','ᴛ​',$k);
$k=str_replace('y','ʏ​',$k);
$k=str_replace('u','ᴜ​',$k);
$k=str_replace('i','ɪ​',$k);
$k=str_replace('o','ᴏ​',$k);
$k=str_replace('p','ᴘ​',$k);
$k=str_replace('a','ᴀ​',$k);
$k=str_replace('s','s​',$k);
$k=str_replace('d','ᴅ​',$k);
$k=str_replace('f','ғ​',$k);
$k=str_replace('g','ɢ​',$k);
$k=str_replace('h','ʜ​',$k);
$k=str_replace('j','ᴊ​',$k);
$k=str_replace('k','​ᴋ',$k);
$k=str_replace('l','ʟ​',$k);
$k=str_replace('z','ᴢ​',$k);
$k=str_replace('x','x​',$k);
$k=str_replace('c','ᴄ​',$k);
$k=str_replace('v','ᴠ​',$k);
$k=str_replace('b','ʙ​',$k);
$k=str_replace('n','ɴ​',$k);
$k=str_replace('m','ᴍ',$k);
bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
$k=str_replace('q','q͛​',$k);
$k=str_replace('w','w͛​',$k);
$k=str_replace('e','e͛​',$k);
$k=str_replace('r','r͛​',$k);
$k=str_replace('t','t͛​',$k);
$k=str_replace('y','y͛​',$k);
$k=str_replace('u','u͛​',$k);
$k=str_replace('i','i͛​',$k);
$k=str_replace('o','o͛​',$k);
$k=str_replace('p','p͛​',$k);
$k=str_replace('a','a͛​',$k);
$k=str_replace('s','s͛​',$k);
$k=str_replace('d','d͛​',$k);
$k=str_replace('f','f͛​',$k);
$k=str_replace('g','g͛​',$k);
$k=str_replace('h','h͛​',$k);
$k=str_replace('j','j͛​',$k);
$k=str_replace('k','​k͛',$k);
$k=str_replace('l','l͛​',$k);
$k=str_replace('z','z͛​',$k);
$k=str_replace('x','x͛​',$k);
$k=str_replace('c','c͛​',$k);
$k=str_replace('v','v͛​',$k);
$k=str_replace('b','b͛​',$k);
$k=str_replace('n','n͛​',$k);
$k=str_replace('m','m͛​',$k);
bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]);

   $k = $text;
$k = str_replace('a','𝒂',$text); 
 $k = str_replace('b','𝒃',$k); 
 $k = str_replace('c','𝒄',$k); 
 $k = str_replace('d','𝒅',$k); 
 $k = str_replace('e','𝒆',$k); 
 $k = str_replace('f','𝒇',$k); 
 $k = str_replace('g','𝒈',$k); 
 $k = str_replace('h','𝒉',$k); 
 $k = str_replace('i','𝒊',$k); 
 $k = str_replace('j','𝒋',$k); 
 $k = str_replace('k','𝒌',$k); 
 $k = str_replace('l','𝒍',$k); 
 $k = str_replace('m','𝒎',$k); 
 $k = str_replace('n','𝒏',$k); 
 $k = str_replace('o','𝒐',$k); 
 $k = str_replace('p','𝒑',$k); 
 $k = str_replace('q','𝒒',$k); 
 $k = str_replace('r','𝒓',$k); 
 $k = str_replace('s','𝒔',$k); 
 $k = str_replace('t','𝒕',$k); 
 $k = str_replace('u','𝒖',$k); 
 $k = str_replace('v','𝒗',$k); 
 $k = str_replace('w','𝒘',$k); 
 $k = str_replace('x','𝒙',$k); 
 $k = str_replace('y','𝒚',$k); 
 $k = str_replace('z','𝒛',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]);
} 

