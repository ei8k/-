<?php
$to = "exxt4148@gmail.com";
$subject = "SHAHID VIP";
$body = "لقد تم تفعيل خدمة شاهد vip الشهرية للمستخدم exxt4148@gmail.com 

Support Shahid Vip team "; 
$headers = "From: Shahid";
if (mail($to, $subject, $body, $headers)){
echo "  تم ارسال الرساله الى $to";
}
else{
echo "حدث خطا اثناء ارسال الرساله الى $to";}