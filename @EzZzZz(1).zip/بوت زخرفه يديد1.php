<?php

ob_start();

$eermar = '998817210:AAGsEHNVKga3nSc_fzLazgPb6Tz7axBnGbA';

define('API_KEY',$eermar);

echo file_get_contents("https://api.telegram.org/bot" . API_KEY . "/setwebhook?url=" . $_SERVER['SERVER_NAME'] . "" . $_SERVER['SCRIPT_NAME']);
function bot($method,$datas=[]){
$aws_c9 = http_build_query($datas);
$url = "https://api.telegram.org/bot".API_KEY."/".$method."?$aws_c9";
$aws_c9 = file_get_contents($url);
return json_decode($aws_c9);
}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$first_name = $message->from->first_name;
$botnem = "FEFXBot";
$cx = "ZZZZZT";
$data = $update->callback_query->data;
$id_yfeee = $update->callback_query->message->chat->id;
$hassanmuaed = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$name = $update->message->from->first_name;
$from_id = $message->from->id;
$message = $update->message;
$php_i = $message->chat->id;
$text = $message->text;
$vverok = file_get_contents("hassanmuaed.txt");
$username = $message->from->username;
$ttya = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$dev_i = $update->callback_query->message->message_id;
$sudo = 1010918290; //ايديك          
$ttvi = "EzZzZz" ; //المطور.
$Kingdom_Lovers = "Kingdom_Lovers" ;
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$message_id2 = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$name = $update->message->from->first_name;
$from_id = $message->from->id;
$lolk = $get_token[1]; 
$ttya = $update->callback_query->message->chat->id;
$chat_id = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$rasclon = file_get_contents("rasclon.txt");
$hassyne = json_decode(file_get_contents('php://input'));
$ihasanui = $update->message;
$krare2 = $ihasanui->chat->id;
$ihasanp = $ihasanui->text;
$imarcussr = $hassyne->callback_query->data;
$krare = $hassyne->callback_query->message->chat->id;
$forkk =  $hassyne->callback_query->message->message_id;
$tbook = $ihasanui->from->first_name;
$ihasani = $ihasanui->from->username;
$sudoe = $ihasanui->from->id;
$muaed = explode("\n",file_get_contents("hassanmuaedlfta4.txt"));
$hassanmuaed = count($muaed)-1;
if ($ihasanui && !in_array($sudoe, $muaed)) {
    file_put_contents("hassanmuaedlfta4.txt", $sudoe."\n",FILE_APPEND);
  }

if($ihasanp == "/admin" and $sudoe == $sudo){
bot("sendmessage",[
"chat_id"=>$krare2,
"text"=>'- أهلا بك في قائمة المطےوڑ',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- عدد المشتركين' ,'callback_data'=>"hassanmuaedlfta7"]],
[['text'=>'نشر توجيه' ,'callback_data'=>"znoba"],['text'=>'نشر رساله' ,'callback_data'=>"vverok"]],
   ] 
   ])
]);
}
if($data == "hassanmuaedlfta" ){
bot('EditMessageText',[
'chat_id'=>$krare,
'message_id'=>$forkk,
"text"=>'اهلاةبك في قائمه المطور ',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- عدد المشتركين' ,'callback_data'=>"hassanmuaedlfta7"]],
[['text'=>'نشر توجيه' ,'callback_data'=>"znoba"],['text'=>'نشر رساله' ,'callback_data'=>"vverok"]],
   ] 
   ])
]);

unlink("hassanmuaedlfta.txt");
}
if($imarcussr == "znoba"){
bot('EditMessageText',[
    'chat_id'=>$krare,
    'message_id'=>$forkk,
'text'=>'
❧أرسل رسالتك ليتم نشرها توجيه لجميع الأعضاء ',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'❧إلغاء' ,'callback_data'=>"hassanmuaedlfta"]],
]])
]);
file_put_contents("hassanmuaedlfta.txt","muaed");
}
if($ihasanui and $hassanmuaedlfta == "muaed" and $sudoe == $sudo){
bot("sendmessage",[
"chat_id"=>$krare2,
"text"=>'
- تم التوجيه بنجاح ⍻',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'رجوع' ,'callback_data'=>"hassanmuaedlfta"]],
]])
]);
for($i=0;$i<count($muaed); $i++){
bot('forwardMessage', [
'chat_id'=>$muaed[$i],
'from_chat_id'=>$sudoe,
'message_id'=>$ihasanui->message_id
]);
unlink("hassanmuaedlfta.txt");
}
}
if($imarcussr == "vverok"){
bot('EditMessageText',[
    'chat_id'=>$krare,
    'message_id'=>$forkk,
'text'=>'
أرسل رسالتك ليتم نشرها رسالة لجميع الأعضاء ',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'❧إلغاء' ,'callback_data'=>"hassanmuaedlfta"]],
]])
]);
file_put_contents("hassanmuaedlfta.txt","hassanmuaed");
}
if($ihasanp and $hassanmuaedlfta == "hassanmuaed" and $sudoe == $sudo){
bot("sendmessage",[
"chat_id"=>$krare2,
"text"=>'
- تم النشر بنجاح',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'❧رجوع' ,'callback_data'=>"hassanmuaedlfta"]],
]])
]);
for($i=0;$i<count($muaed); $i++){
bot('sendMessage', [
'chat_id'=>$muaed[$i],
'text'=>$ihasanp
]);
unlink("hassanmuaedlfta.txt");
}
}
if($imarcussr == "hassanmuaedlfta7"){
bot('EditMessageText',[
    'chat_id'=>$krare,
    'message_id'=>$forkk,
'text'=>'
- عدد مشتركين البوت هو '.$hassanmuaed.'',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'❧رجوع' ,'callback_data'=>"hassanmuaedlfta"]],
]])
]);
unlink("hassanmuaedlfta.txt");
}

if($text == '/start'){
    bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>"
- اهلا بك $first_name
📜| مرحبا بك في بوت الزخرفة
📬 | ارسل اسمكك ليتم زخرفته تمبلر،💘😻
⚠️| ملاحضة :- عليك ارسال احرف انكليزية فقط .",
 'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"• لـشراء بوت مماثل 😻🔥", 'url'=>"https://t.me/EzZzZz"]],
        ] ])]);}


if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ན',' ཌྷ',' ཉ',' ཪ',' ྊ',' ྿',' ྾',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾',',𖢿','𖣏','𖣎','𖣍','𖣒','𖣘','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1); 
  $lolo = $MR[$MC];
   $count = count($text); 
$marcusi = str_replace('a','𝗔',$text); 
$marcusi = str_replace("b","𝗕",$marcusi); 
$marcusi = str_replace("c","𝗖",$marcusi); 
$marcusi = str_replace("d","𝗗",$marcusi); 
$marcusi = str_replace("e","𝗘",$marcusi); 
$marcusi = str_replace("f","𝗙",$marcusi); 
$marcusi = str_replace("g","𝗚",$marcusi); 
$marcusi = str_replace("h","𝗛",$marcusi); 
$marcusi = str_replace("i","𝗜",$marcusi); 
$marcusi = str_replace("j","𝗝",$marcusi); 
$marcusi = str_replace("k","𝗞",$marcusi); 
$marcusi = str_replace("l","𝗟",$marcusi); 
$marcusi = str_replace("m","𝗠",$marcusi); 
$marcusi = str_replace("n","𝗡",$marcusi); 
$marcusi = str_replace("o","𝗢",$marcusi); 
$marcusi = str_replace("p","𝗣",$marcusi); 
$marcusi = str_replace("q","𝗤",$marcusi); 
$marcusi = str_replace("r","𝗥",$marcusi); 
$marcusi = str_replace("s","𝗦",$marcusi); 
$marcusi = str_replace("t","𝗧",$marcusi); 
$marcusi = str_replace("u","𝗨",$marcusi); 
$marcusi = str_replace("v","𝗩",$marcusi); 
$marcusi = str_replace("w","𝗪",$marcusi); 
$marcusi = str_replace("x","𝗫",$marcusi); 
$marcusi = str_replace("y","𝗬",$marcusi); 
$marcusi = str_replace("z","𝗭",$marcusi);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
$marcusi = str_replace('a','𝒶',$text); 
$marcusi = str_replace("b","𝒷",$marcusi); 
$marcusi = str_replace("c","𝒸",$marcusi); 
$marcusi = str_replace("d","𝒹",$marcusi); 
$marcusi = str_replace("e","𝖊",$marcusi); 
$marcusi = str_replace("f","𝒻",$marcusi); 
$marcusi = str_replace("g","𝖌",$marcusi); 
$marcusi = str_replace("h","𝒽",$marcusi); 
$marcusi = str_replace("i","𝒾",$marcusi); 
$marcusi = str_replace("j","𝗝",$marcusi); 
$marcusi = str_replace("k","𝒿",$marcusi); 
$marcusi = str_replace("l","𝓀",$marcusi); 
$marcusi = str_replace("m","𝓁",$marcusi); 
$marcusi = str_replace("n","𝓂",$marcusi); 
$marcusi = str_replace("o","𝓃",$marcusi); 
$marcusi = str_replace("p","𝖔",$marcusi); 
$marcusi = str_replace("q","𝓅",$marcusi); 
$marcusi = str_replace("r","𝓆",$marcusi); 
$marcusi = str_replace("s","𝓇",$marcusi); 
$marcusi = str_replace("t","𝓉",$marcusi); 
$marcusi = str_replace("u","𝓊",$marcusi); 
$marcusi = str_replace("v","𝓋",$marcusi); 
$marcusi = str_replace("w","𝓌",$marcusi); 
$marcusi = str_replace("x","𝓍",$marcusi); 
$marcusi = str_replace("y","𝓎",$marcusi); 
$marcusi = str_replace("z","𝓏",$marcusi); 
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
 $marcusi = str_replace('a','𝒂',$text); 
 $marcusi = str_replace('b','𝒃',$marcusi); 
 $marcusi = str_replace('c','𝒄',$marcusi); 
 $marcusi = str_replace('d','𝒅',$marcusi); 
 $marcusi = str_replace('e','𝒆',$marcusi); 
 $marcusi = str_replace('f','𝒇',$marcusi); 
 $marcusi = str_replace('g','𝒈',$marcusi); 
 $marcusi = str_replace('h','𝒉',$marcusi); 
 $marcusi = str_replace('i','𝒊',$marcusi); 
 $marcusi = str_replace('j','𝒋',$marcusi); 
 $marcusi = str_replace('k','𝒌',$marcusi); 
 $marcusi = str_replace('l','𝒍',$marcusi); 
 $marcusi = str_replace('m','𝒎',$marcusi); 
 $marcusi = str_replace('n','𝒏',$marcusi); 
 $marcusi = str_replace('o','𝒐',$marcusi); 
 $marcusi = str_replace('p','𝒑',$marcusi); 
 $marcusi = str_replace('q','𝒒',$marcusi); 
 $marcusi = str_replace('r','𝒓',$marcusi); 
 $marcusi = str_replace('s','𝒔',$marcusi); 
 $marcusi = str_replace('t','𝒕',$marcusi); 
 $marcusi = str_replace('u','𝒖',$marcusi); 
 $marcusi = str_replace('v','𝒗',$marcusi); 
 $marcusi = str_replace('w','𝒘',$marcusi); 
 $marcusi = str_replace('x','𝒙',$marcusi); 
 $marcusi = str_replace('y','𝒚',$marcusi); 
 $marcusi = str_replace('z','𝒛',$marcusi);
 
if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
$marcusi = str_replace('a','𝐀',$text); 
$marcusi = str_replace("b","𝐁",$marcusi); 
$marcusi = str_replace("c","𝐂",$marcusi); 
$marcusi = str_replace("d","𝐃",$marcusi); 
$marcusi = str_replace("e","𝐄",$marcusi); 
$marcusi = str_replace("f","𝐅",$marcusi); 
$marcusi = str_replace("g","𝐆",$marcusi); 
$marcusi = str_replace("h","𝐇",$marcusi); 
$marcusi = str_replace("i","𝐈",$marcusi); 
$marcusi = str_replace("j","𝐉",$marcusi); 
$marcusi = str_replace("k","𝐊",$marcusi); 
$marcusi = str_replace("l","𝐋",$marcusi); 
$marcusi = str_replace("m","𝐌",$marcusi); 
$marcusi = str_replace("n","𝐍",$marcusi); 
$marcusi = str_replace("o","𝐎",$marcusi); 
$marcusi = str_replace("p","𝐏",$marcusi); 
$marcusi = str_replace("q","𝐐",$marcusi); 
$marcusi = str_replace("r","𝐑",$marcusi); 
$marcusi = str_replace("s","𝐒",$marcusi); 
$marcusi = str_replace("t","𝐓",$marcusi); 
$marcusi = str_replace("u","𝐔",$marcusi); 
$marcusi = str_replace("v","𝐕",$marcusi); 
$marcusi = str_replace("w","𝐖",$marcusi); 
$marcusi = str_replace("x","𝐗",$marcusi); 
$marcusi = str_replace("y","𝐘",$marcusi); 
$marcusi = str_replace("z","𝐙",$marcusi); 
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
 $marcusi = str_replace('a','𝖆',$text); 
 $marcusi = str_replace('b','𝖇',$marcusi); 
 $marcusi = str_replace('c','𝖈',$marcusi); 
 $marcusi = str_replace('d','𝖉',$marcusi); 
 $marcusi = str_replace('e','𝖊',$marcusi); 
 $marcusi = str_replace('f','𝖋',$marcusi); 
 $marcusi = str_replace('g','𝖌',$marcusi); 
 $marcusi = str_replace('h','𝖍',$marcusi); 
 $marcusi = str_replace('i','𝖎',$marcusi); 
 $marcusi = str_replace('j','𝖏',$marcusi); 
 $marcusi = str_replace('k','𝖐',$marcusi); 
 $marcusi = str_replace('l','𝖑',$marcusi); 
 $marcusi = str_replace('m','𝖒',$marcusi); 
 $marcusi = str_replace('n','𝖓',$marcusi); 
 $marcusi = str_replace('o','𝖔',$marcusi); 
 $marcusi = str_replace('p','𝖕',$marcusi); 
 $marcusi = str_replace('q','𝖖',$marcusi); 
 $marcusi = str_replace('r','𝖗',$marcusi); 
 $marcusi = str_replace('s','𝖘',$marcusi); 
 $marcusi = str_replace('t','𝖙',$marcusi); 
 $marcusi = str_replace('u','𝖚',$marcusi); 
 $marcusi = str_replace('v','𝖛',$marcusi); 
 $marcusi = str_replace('w','𝖜',$marcusi); 
 $marcusi = str_replace('x','𝖝',$marcusi); 
 $marcusi = str_replace('y','𝖞',$marcusi); 
 $marcusi = str_replace('z','𝖟',$marcusi);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$marcusi."".$lolo
]);}


if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
$marcusi = str_replace('a','𝙰',$text); 
 $marcusi = str_replace('b','𝙱',$marcusi); 
 $marcusi = str_replace('c','𝙲',$marcusi); 
 $marcusi = str_replace('d','𝙳',$marcusi); 
 $marcusi = str_replace('e','𝙴',$marcusi); 
 $marcusi = str_replace('f','𝙵',$marcusi); 
 $marcusi = str_replace('g','𝙶',$marcusi); 
 $marcusi = str_replace('h','𝙷',$marcusi); 
 $marcusi = str_replace('i','𝙸',$marcusi); 
 $marcusi = str_replace('j','𝙹',$marcusi); 
 $marcusi = str_replace('k','𝙺',$marcusi); 
 $marcusi = str_replace('l','𝙻',$marcusi); 
 $marcusi = str_replace('m','𝙼',$marcusi); 
 $marcusi = str_replace('n','𝙽',$marcusi); 
 $marcusi = str_replace('o','𝙾',$marcusi); 
 $marcusi = str_replace('p','𝙿',$marcusi); 
 $marcusi = str_replace('q','𝚀',$marcusi); 
 $marcusi = str_replace('r','𝚁',$marcusi); 
 $marcusi = str_replace('s','𝚂',$marcusi); 
 $marcusi = str_replace('t','𝚃',$marcusi); 
 $marcusi = str_replace('u','𝙺',$marcusi); 
 $marcusi = str_replace('v','𝚅',$marcusi); 
 $marcusi = str_replace('w','𝚆',$marcusi); 
 $marcusi = str_replace('x','𝚇',$marcusi); 
 $marcusi = str_replace('y','𝚈',$marcusi); 
 $marcusi = str_replace('z','𝚉',$marcusi);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$marcusi."".$lolo
]);}


if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
$marcusi = str_replace('a','𝒂',$text); 
 $marcusi = str_replace('b','𝒃',$marcusi); 
 $marcusi = str_replace('c','𝒄',$marcusi); 
 $marcusi = str_replace('d','𝒅',$marcusi); 
 $marcusi = str_replace('e','𝒆',$marcusi); 
 $marcusi = str_replace('f','𝒇',$marcusi); 
 $marcusi = str_replace('g','𝒈',$marcusi); 
 $marcusi = str_replace('h','𝒉',$marcusi); 
 $marcusi = str_replace('i','𝒊',$marcusi); 
 $marcusi = str_replace('j','𝒋',$marcusi); 
 $marcusi = str_replace('k','𝒌',$marcusi); 
 $marcusi = str_replace('l','𝒍',$marcusi); 
 $marcusi = str_replace('m','𝒎',$marcusi); 
 $marcusi = str_replace('n','𝒏',$marcusi); 
 $marcusi = str_replace('o','𝒐',$marcusi); 
 $marcusi = str_replace('p','𝒑',$marcusi); 
 $marcusi = str_replace('q','𝒒',$marcusi); 
 $marcusi = str_replace('r','𝒓',$marcusi); 
 $marcusi = str_replace('s','𝒔',$marcusi); 
 $marcusi = str_replace('t','𝒕',$marcusi); 
 $marcusi = str_replace('u','𝒖',$marcusi); 
 $marcusi = str_replace('v','𝒗',$marcusi); 
 $marcusi = str_replace('w','𝒘',$marcusi); 
 $marcusi = str_replace('x','𝒙',$marcusi); 
 $marcusi = str_replace('y','𝒚',$marcusi); 
 $marcusi = str_replace('z','𝒛',$marcusi);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
 $marcusi = str_replace('b','𝐵',$text); 
 $marcusi = str_replace('c','𝐶',$marcusi); 
 $marcusi = str_replace('d','𝐷',$marcusi); 
 $marcusi = str_replace('e','𝐸',$marcusi); 
 $marcusi = str_replace('f','𝐹',$marcusi); 
 $marcusi = str_replace('g','𝐺',$marcusi); 
 $marcusi = str_replace('h','𝐻',$marcusi); 
 $marcusi = str_replace('i','𝐼',$marcusi); 
 $marcusi = str_replace('j','𝐽',$marcusi); 
 $marcusi = str_replace('k','𝐾',$marcusi); 
 $marcusi = str_replace('l','𝐿',$marcusi); 
 $marcusi = str_replace('m','𝑀',$marcusi); 
 $marcusi = str_replace('n','𝑁',$marcusi); 
 $marcusi = str_replace('o','𝑂',$marcusi); 
 $marcusi = str_replace('p','𝑃',$marcusi); 
 $marcusi = str_replace('q','𝑄',$marcusi); 
 $marcusi = str_replace('r','𝑅',$marcusi); 
 $marcusi = str_replace('s','𝑆',$marcusi); 
 $marcusi = str_replace('t','𝑇',$marcusi); 
 $marcusi = str_replace('u','𝑈',$marcusi); 
 $marcusi = str_replace('v','𝑉',$marcusi); 
 $marcusi = str_replace('w','𝑊',$marcusi); 
 $marcusi = str_replace('x','𝑋',$marcusi); 
 $marcusi = str_replace('y','𝑌',$marcusi); 
 $marcusi = str_replace('z','𝑍',$marcusi);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$marcusi."".$lolo
]);}


if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
$marcusi = str_replace('a','𝐀',$text); 
 $marcusi = str_replace('b','𝐁',$marcusi); 
 $marcusi = str_replace('c','𝐂',$marcusi); 
 $marcusi = str_replace('d','𝐃',$marcusi); 
 $marcusi = str_replace('e','𝐄',$marcusi); 
 $marcusi = str_replace('f','𝐅',$marcusi); 
 $marcusi = str_replace('g','𝐆',$marcusi); 
 $marcusi = str_replace('h','𝐇',$marcusi); 
 $marcusi = str_replace('i','𝐈',$marcusi); 
 $marcusi = str_replace('j','𝐉',$marcusi); 
 $marcusi = str_replace('k','𝐊',$marcusi); 
 $marcusi = str_replace('l','𝐋',$marcusi); 
 $marcusi = str_replace('m','𝐌',$marcusi); 
 $marcusi = str_replace('n','𝐍',$marcusi); 
 $marcusi = str_replace('o','𝐎',$marcusi); 
 $marcusi = str_replace('p','𝐏',$marcusi); 
 $marcusi = str_replace('q','𝐐',$marcusi); 
 $marcusi = str_replace('r','𝐑',$marcusi); 
 $marcusi = str_replace('s','𝐒',$marcusi); 
 $marcusi = str_replace('t','𝐓',$marcusi); 
 $marcusi = str_replace('u','𝐔',$marcusi); 
 $marcusi = str_replace('v','𝐕',$marcusi); 
 $marcusi = str_replace('w','𝐖',$marcusi); 
 $marcusi = str_replace('x','𝐗',$marcusi); 
 $marcusi = str_replace('y','𝐘',$marcusi); 
 $marcusi = str_replace('z','𝐙',$marcusi);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
 $marcusi = str_replace('a','𝖆',$text); 
 $marcusi = str_replace('b','𝖇',$marcusi); 
 $marcusi = str_replace('c','𝖈',$marcusi); 
 $marcusi = str_replace('d','𝖉',$marcusi); 
 $marcusi = str_replace('e','𝖊',$marcusi); 
 $marcusi = str_replace('f','𝖋',$marcusi); 
 $marcusi = str_replace('g','𝖌',$marcusi); 
 $marcusi = str_replace('h','𝖍',$marcusi); 
 $marcusi = str_replace('i','𝖎',$marcusi); 
 $marcusi = str_replace('j','𝖏',$marcusi); 
 $marcusi = str_replace('k','𝖐',$marcusi); 
 $marcusi = str_replace('l','𝖑',$marcusi); 
 $marcusi = str_replace('m','𝖒',$marcusi); 
 $marcusi = str_replace('n','𝖓',$marcusi); 
 $marcusi = str_replace('o','𝖔',$marcusi); 
 $marcusi = str_replace('p','𝖕',$marcusi); 
 $marcusi = str_replace('q','𝖖',$marcusi); 
 $marcusi = str_replace('r','𝖗',$marcusi); 
 $marcusi = str_replace('s','𝖘',$marcusi); 
 $marcusi = str_replace('t','𝖙',$marcusi); 
 $marcusi = str_replace('u','𝖚',$marcusi); 
 $marcusi = str_replace('v','𝖛',$marcusi); 
 $marcusi = str_replace('w','𝖜',$marcusi); 
 $marcusi = str_replace('x','𝖝',$marcusi); 
 $marcusi = str_replace('y','𝖞',$marcusi); 
 $marcusi = str_replace('z','𝖟',$marcusi);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
   $marcusi = str_replace('a','𝙰',$text); 
 $marcusi = str_replace('b','𝙱',$marcusi); 
 $marcusi = str_replace('c','𝙲',$marcusi); 
 $marcusi = str_replace('d','𝙳',$marcusi); 
 $marcusi = str_replace('e','𝙴',$marcusi); 
 $marcusi = str_replace('f','𝙵',$marcusi); 
 $marcusi = str_replace('g','𝙶',$marcusi); 
 $marcusi = str_replace('h','𝙷',$marcusi); 
 $marcusi = str_replace('i','𝙸',$marcusi); 
 $marcusi = str_replace('j','𝙹',$marcusi); 
 $marcusi = str_replace('k','𝙺',$marcusi); 
 $marcusi = str_replace('l','𝙻',$marcusi); 
 $marcusi = str_replace('m','𝙼',$marcusi); 
 $marcusi = str_replace('n','𝙽',$marcusi); 
 $marcusi = str_replace('o','𝙾',$marcusi); 
 $marcusi = str_replace('p','𝙿',$marcusi); 
 $marcusi = str_replace('q','𝚀',$marcusi); 
 $marcusi = str_replace('r','𝚁',$marcusi); 
 $marcusi = str_replace('s','𝚂',$marcusi); 
 $marcusi = str_replace('t','𝚃',$marcusi); 
 $marcusi = str_replace('u','𝙺',$marcusi); 
 $marcusi = str_replace('v','𝚅',$marcusi); 
 $marcusi = str_replace('w','𝚆',$marcusi); 
 $marcusi = str_replace('x','𝚇',$marcusi); 
 $marcusi = str_replace('y','𝚈',$marcusi); 
 $marcusi = str_replace('z','𝚉',$marcusi);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
$marcusi = str_replace('a','𝒂',$text);
$marcusi = str_replace("b","𝒃",$marcusi);
$marcusi = str_replace("c","𝒄",$marcusi);
$marcusi = str_replace("d","𝒅",$marcusi);
$marcusi = str_replace("e","𝒆",$marcusi);
$marcusi = str_replace("E","𝒇",$marcusi);
$marcusi = str_replace("g","𝒈",$marcusi);
$marcusi = str_replace("h","𝒉",$marcusi);
$marcusi = str_replace("i","𝒊",$marcusi);
$marcusi = str_replace("j","𝒋",$marcusi);
$marcusi = str_replace("k","𝒌",$marcusi);
$marcusi = str_replace("l","𝒍",$marcusi);
$marcusi = str_replace("m","𝒎",$marcusi);
$marcusi = str_replace("n","𝒏",$marcusi);
$marcusi = str_replace("o","𝒐",$marcusi);
$marcusi = str_replace("p","𝒑",$marcusi);
$marcusi = str_replace("q","𝒒",$marcusi);
$marcusi = str_replace("r","𝒓",$marcusi);
$marcusi = str_replace("s","𝒔",$marcusi);
$marcusi = str_replace("t","𝒕",$marcusi);
$marcusi = str_replace("u","𝒖",$marcusi);
$marcusi = str_replace("v","𝒗",$marcusi);
$marcusi = str_replace("w","𝒘",$marcusi);
$marcusi = str_replace("x","𝒙",$marcusi);
$marcusi = str_replace("y","𝒚",$marcusi);
$marcusi = str_replace("z","𝒛",$marcusi);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$marcusi."".$lolo
]);}


if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
$marcusi = str_replace('a','𝐴',$text);
$marcusi = str_replace("b","𝒃",$marcusi);
$marcusi = str_replace("c","𝐶",$marcusi);
$marcusi = str_replace("d","𝐷",$marcusi);
$marcusi = str_replace("e","𝐸",$marcusi);
$marcusi = str_replace("E","𝐹",$marcusi);
$marcusi = str_replace("g","𝐺",$marcusi);
$marcusi = str_replace("h","𝐻",$marcusi);
$marcusi = str_replace("i","𝐼",$marcusi);
$marcusi = str_replace("j","𝐽",$marcusi);
$marcusi = str_replace("k","𝐾",$marcusi);
$marcusi = str_replace("l","𝐿",$marcusi);
$marcusi = str_replace("m","𝑀",$marcusi);
$marcusi = str_replace("n","𝑁",$marcusi);
$marcusi = str_replace("o","𝑂",$marcusi);
$marcusi = str_replace("p","𝑃",$marcusi);
$marcusi = str_replace("q","𝑄",$marcusi);
$marcusi = str_replace("r","𝑅",$marcusi);
$marcusi = str_replace("s","𝑆",$marcusi);
$marcusi = str_replace("t","𝑇",$marcusi);
$marcusi = str_replace("u","𝑈",$marcusi);
$marcusi = str_replace("v","𝑉",$marcusi);
$marcusi = str_replace("w","𝑊",$marcusi);
$marcusi = str_replace("x","𝑋",$marcusi);
$marcusi = str_replace("y","𝑌",$marcusi);
$marcusi = str_replace("z","𝑍",$marcusi);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
$marcusi = str_replace('a','𝔸',$text);
$marcusi = str_replace("b","𝔹",$marcusi);
$marcusi = str_replace("c","ℂ",$marcusi);
$marcusi = str_replace("d","𝔻",$marcusi);
$marcusi = str_replace("e","𝔼",$marcusi);
$marcusi = str_replace("E","𝔽",$marcusi);
$marcusi = str_replace("g","𝔾",$marcusi);
$marcusi = str_replace("h","ℍ",$marcusi);
$marcusi = str_replace("i","𝕀",$marcusi);
$marcusi = str_replace("j","𝕁",$marcusi);
$marcusi = str_replace("k","𝕂",$marcusi);
$marcusi = str_replace("l","𝕃",$marcusi);
$marcusi = str_replace("m","𝕄",$marcusi);
$marcusi = str_replace("n","ℕ",$marcusi);
$marcusi = str_replace("o","𝕆",$marcusi);
$marcusi = str_replace("p","ℙ",$marcusi);
$marcusi = str_replace("q","ℚ",$marcusi);
$marcusi = str_replace("r","ℝ",$marcusi);
$marcusi = str_replace("s","𝕊",$marcusi);
$marcusi = str_replace("t","𝕋",$marcusi);
$marcusi = str_replace("u","𝕌",$marcusi);
$marcusi = str_replace("v","𝕍",$marcusi);
$marcusi = str_replace("w","𝕎",$marcusi);
$marcusi = str_replace("x","𝕏",$marcusi);
$marcusi = str_replace("y","𝕐",$marcusi);
$marcusi = str_replace("z","ℤ",$marcusi);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
$marcusi  = str_replace('a', 'ᴀ', $text);
$marcusi  = str_replace('b', 'ᴮ', $marcusi);
$marcusi  = str_replace('c', 'ᶜ', $marcusi);
$marcusi  = str_replace('d', 'ᴰ', $marcusi);
$marcusi  = str_replace('e', 'ᴱ', $marcusi);
$marcusi  = str_replace('f', 'ᶠ', $marcusi);
$marcusi  = str_replace('g', 'ᴳ', $marcusi);
$marcusi  = str_replace('h', 'ᴴ', $marcusi);
$marcusi  = str_replace('i', 'ᴵ', $marcusi);
$marcusi  = str_replace('j', 'ᴶ', $marcusi);
$marcusi  = str_replace('k', 'ᴷ', $marcusi);
$marcusi  = str_replace('l', 'ᴸ', $marcusi);
$marcusi  = str_replace('m', 'ᴹ', $marcusi);
$marcusi  = str_replace('n', 'ᴺ', $marcusi);
$marcusi  = str_replace('o', 'ᴼ', $marcusi);
$marcusi  = str_replace('p', 'ᴾ', $marcusi);
$marcusi  = str_replace('q', 'ᵟ', $marcusi);
$marcusi  = str_replace('r', 'ᴿ', $marcusi);
$marcusi  = str_replace('s', 'ˢ', $marcusi);
$marcusi  = str_replace('t', 'ᵀ', $marcusi);
$marcusi  = str_replace('u', 'ᵁ', $marcusi);
$marcusi  = str_replace('v', 'ᵛ', $marcusi);
$marcusi  = str_replace('w', 'ᵂ', $marcusi);
$marcusi  = str_replace('x', 'ˣ', $marcusi);
$marcusi  = str_replace('y', 'ᵞ', $marcusi);
$marcusi    = str_replace('z', 'ᶻ', $marcusi);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
$marcus = str_replace('a',"ᵃ",$text);
$marcus = str_replace("b","ᵇ",$marcus);
$marcus = str_replace("c","ᶜ",$marcus);
$marcus = str_replace("d","ᵈ",$marcus);
$marcus = str_replace("e","ᵉ",$marcus);
$marcus = str_replace("f","ᶠ",$marcus);
$marcus = str_replace("g","ᵍ",$marcus);
$marcus = str_replace("h","ʰ",$marcus);
$marcus = str_replace("i","ᶤ",$marcus);
$marcus = str_replace("j","ʲ",$marcus);
$marcus = str_replace("k","ᵏ",$marcus);
$marcus = str_replace("l","ˡ",$marcus);
$marcus = str_replace("m","ᵐ",$marcus);
$marcus = str_replace("n","ᶰ",$marcus);
$marcus = str_replace("o","ᵒ",$marcus);
$marcus = str_replace("p","ᵖ",$marcus);
$marcus = str_replace("q","ᵠ",$marcus);
$marcus = str_replace("r","ʳ",$marcus);
$marcus = str_replace("s","ˢ",$marcus);
$marcus = str_replace("t","ᵗ",$marcus);
$marcus = str_replace("u","ᵘ",$marcus);
$marcus = str_replace("v","ᵛ",$marcus);
$marcus = str_replace("w","ʷ",$marcus);
$marcus = str_replace("x","ˣ",$marcus);
$marcus = str_replace("y","ʸ",$marcus);
$marcus = str_replace("z","ᶻ",$marcus);
 bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
 $marcusi = str_replace('a', 'ᴀ', $text);
$marcusi = str_replace('b', 'ʙ', $marcusi);
$marcusi = str_replace('c', 'ᴄ', $marcusi);
$marcusi = str_replace('d', 'ᴅ', $marcusi);
$marcusi = str_replace('e', 'ᴇ', $marcusi);
$marcusi = str_replace('f', 'ᴈ', $marcusi);
$marcusi = str_replace('g', 'ɢ', $marcusi);
$marcusi = str_replace('h', 'ʜ', $marcusi);
$marcusi = str_replace('i', 'ɪ', $marcusi);
$marcusi = str_replace('j', 'ᴊ', $marcusi);
$marcusi = str_replace('k', 'ᴋ', $marcusi);
$marcusi = str_replace('l', 'ʟ', $marcusi);
$marcusi = str_replace('m', 'ᴍ', $marcusi);
$marcusi = str_replace('n', 'ɴ', $marcusi);
$marcusi = str_replace('o', 'ᴏ', $marcusi);
$marcusi = str_replace('p', 'ᴘ', $marcusi);
$marcusi = str_replace('q', 'ᴓ', $marcusi);
$marcusi = str_replace('r', 'ʀ', $marcusi);
$marcusi = str_replace('s', 'ᴤ', $marcusi);
$marcusi = str_replace('t', 'ᴛ', $marcusi);
$marcusi = str_replace('u', 'ᴜ', $marcusi);
$marcusi = str_replace('v', 'ᴠ', $marcusi);
$marcusi = str_replace('w', 'ᴡ', $marcusi);
$marcusi = str_replace('x', 'ᴥ', $marcusi);
$marcusi = str_replace('y', 'ʏ', $marcusi);
$marcusi = str_replace('z', 'ᴢ', $marcusi);
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>$marcusi."".$lolo
]);}

if($text != '/start' and $text !='/admin' and $text !='الاعضاء'){
  $MR =    $MR =  [' ༗',' ༉','༈',' ༊',' ༒',' ༕',' ༖',' ༑',' ࿅',' ࿄ ',' ࿃',' ࿂ ',' ࿋ ',' ࿌ ',' ࿐',' ࿑',' ࿗',' ၍',' ᪥',' ᪣',' ⸙ ',' ꫝ ','',' 𖠲','𖠱',' 𖠰','𖠪','𖠴','𖠿','𖡣','𖡟','𖢺','𖢹','𖢾','𖢿','𖣏','𖣎','𖣍','𖣒','𖣐','𖤊 ','𖤓',' 𖤍',' 𖤇','𖤓','𖤛','𖤥','𖤞','𖤬','𖤴','𖤳','𖤸','𖤽','𖤾','𖤿','𖥇','𖥆','𖥄','𖥂','𖥒','𖥔','𖥕','𖥖','𖥓','𖥤','𖥢','𖥵','𖦋'];
  $MC = array_rand($MR,1);
  $lolo = $MR[$MC];
   $count = count($text); 
$marcusi = str_replace('a','ᗩ',$text);
$marcusi = str_replace("b","β",$marcusi);
$marcusi = str_replace("c","Ｃ",$marcusi);
$marcusi = str_replace("d","Ɗ",$marcusi);
$marcusi = str_replace("e","Ｅ",$marcusi);
$marcusi = str_replace("E","Բ",$marcusi);
$marcusi = str_replace("g","Ｇ",$marcusi);
$marcusi = str_replace("h","ⴼ",$marcusi);
$marcusi = str_replace("i","Ｉ",$marcusi);
$marcusi = str_replace("j","Ј",$marcusi);
$marcusi = str_replace("k","₭",$marcusi);
$marcusi = str_replace("l","Ł",$marcusi);
$marcusi = str_replace("m","ᗰ",$marcusi);
$marcusi = str_replace("n","Ŋ",$marcusi);
$marcusi = str_replace("o","σ",$marcusi);
$marcusi = str_replace("p","Ꝑ",$marcusi);
$marcusi = str_replace("q","℺",$marcusi);
$marcusi = str_replace("r","Ꮢ",$marcusi);
$marcusi = str_replace("s","₷",$marcusi);
$marcusi = str_replace("t","Ƭ",$marcusi);
$marcusi = str_replace("u","ᵿ",$marcusi);
$marcusi = str_replace("v","ѵ",$marcusi);
$marcusi = str_replace("w","Ꮤ",$marcusi);
$marcusi = str_replace("x","χ",$marcusi);
$marcusi = str_replace("y","ɣ",$marcusi);
$marcusi = str_replace("z","Ꙃ",$marcusi);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>$marcusi."".$lolo
]);}

    bot('sendMessage',[
'chat_id'=>$chat_id,
        'text'=>"
تمت زخرفة اسمك بنجاح ♥️.
By: @$botnem .
————————————
",
 'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"اضغط هنا لرؤية الرموز ✅",'callback_data'=>"ёё"]], 
        ] ])]);}
if($data == "ёё"){
    bot('deleteMessage',[
    'chat_id'=>$id_yfeee,    'message_id'=>$hassanmuaed,
    ]);
    bot('sendMessage',[
'chat_id'=>$id_yfeee,
        'text'=>"
𓅄 𓅅 𓅆 𓅇 𓅈 𓅉 𓅊 𓅋 𓅌 𓅍 𓅎 𓅏 𓅐 𓅑 𓅒 𓅓 𓅔𓅕 𓅖 𓅗 𓅘 𓅙 𓅚 𓅛 𓅜 𓅝 𓅞 𓅟 𓅠 𓅡 𓅢 𓅣 𓅤 𓅥 𓅦 𓅧 𓅨 𓅩 𓅫 𓅬 𓅭 𓅮 𓅯 𓅰 𓅱 𓅲 𓅳 𓅴 
‏𓅵 𓅶 𓅷 𓅸 𓅹 𓅺 𓅻 
‏ ☤ 𓅾 𓅿 𓆀 𓆁 𓆂
‏𓀀 𓀁 𓀂 𓀃 𓀄 𓀅 𓀆 𓀇 𓀈 𓀉 𓀊 𓀋 𓀌 𓀍 𓀎 𓀏 𓀐 𓀑 𓀒 𓀓 𓀔 𓀕 𓀖 𓀗 𓀘 𓀙 𓀚 𓀛 𓀜 𓀝 𓀞 𓀟 𓀠 𓀡 𓀢 𓀣 𓀤 𓀥 𓀦 𓀧 𓀨 𓀩 𓀪 𓀫 𓀬 𓀭 𓀮 𓀯 𓀰 𓀱 𓀲 𓀳 𓀴 𓀵 𓀶 𓀷 𓀸 𓀹 𓀺 𓀻 𓀼 𓀽 𓀾 𓀿 𓁀 𓁁 𓁂 𓁃 𓁄 𓁅 𓁆 𓁇 𓁈 𓁉 𓁊 𓁋 𓁌 𓁍 𓁎 𓁏 𓁐 𓁑 𓁒 𓁓 𓁔 𓁕 𓁖 𓁗 𓁘 𓁙 𓁚 𓁛 𓁜 𓁝 𓁞 𓁟 𓁠 𓁡 𓁢 𓁣 𓁤 𓁥 𓁦 𓁧 𓁨 𓁩 𓁪 𓁫 𓁬 𓁭 𓁮 𓁯 𓁰 𓁱 𓁲 𓁳 𓁴 𓁵 𓁶 𓁷 𓁸 𓁹 𓁺 𓁻 𓁼 𓁽 𓁾 𓁿 𓂀𓂅 𓂆 𓂇 𓂈 𓂉 𓂊 𓂋 𓂌 𓂍 𓂎 𓂏 𓂐 𓂑 𓂒 𓂓 𓂔 𓂕 𓂖 𓂗 𓂘 𓂙 𓂚 𓂛 𓂜 𓂝 𓂞 𓂟 𓂠 𓂡 𓂢 𓂣 𓂤 𓂥 𓂦 𓂧 𓂨 𓂩 𓂪 𓂫 𓂬 𓂭 𓂮 𓂯 𓂰 𓂱 𓂲 𓂳 𓂴 𓂵 𓂶 𓂷 𓂸 𓂹 𓂺 𓂻 𓂼 𓂽 𓂾 𓂿 𓃀 𓃁 𓃂 𓃃 𓃅 𓃆 𓃇 𓃈 𓃉 𓃊 𓃋 𓃌 𓃍 𓃎 𓃏 𓃐 𓃑 𓃒 𓃓 𓃔 𓃕 𓃖 𓃗 𓃘 𓃙 𓃚 𓃛 𓃜 𓃝 𓃞 𓃟 𓃠 𓃡 𓃢 𓃣 𓃤 𓃥 𓃦 𓃧 𓃨 𓃩 𓃪 𓃫 𓃬 𓃭 𓃮 𓃯 𓃰 𓃱 𓃲 𓃳 𓃴 𓃵 𓃶 𓃷 𓃸 𓃹 𓃺 𓃻 𓃼 𓃽 𓃾 𓃿 𓄀 𓄁 𓄂 𓄃 𓄄 𓄅 𓄆 𓄇 𓄈 𓄉 𓄊 𓄋 𓄌 𓄍 𓄎 𓄏 𓄐 𓄑 𓄒 𓄓 𓄔 𓄕 𓄖 𓄙 𓄚 𓄛 𓄜 𓄝 𓄞 𓄟 𓄠 𓄡 𓄢 𓄣 𓄤 𓄥 𓄦 𓄧 𓄨 𓄩 𓄪 𓄫 𓄬 𓄭 𓄮 𓄯 𓄰 𓄱 𓄲 𓄳 𓄴 𓄵 𓄶 𓄷 𓄸 𓄹 𓄺   𓄼 𓄽 𓄾 𓄿 𓅀 𓅁 𓅂 𓅃 𓅄 𓅅 𓅆 𓅇 𓅈 𓅉 𓅊 𓅋 𓅌 𓅍 𓅎 𓅏 𓅐 𓅑 𓅒 𓅓 𓅔 𓅕 𓅖 𓅗 𓅘 𓅙 𓅚 𓅛 𓅜 𓅝 𓅞 𓅟 𓅠 𓅡 𓅢 𓅣 𓅤 𓅥 𓅦 𓅧 𓅨 𓅩 𓅪 𓅫 𓅬 𓅭 𓅮 𓅯 𓅰 𓅱 𓅲 𓅳 𓅴 𓅵 𓅶 𓅷 𓅸 𓅹 𓅺 𓅻 𓅼 𓅽 𓅾 𓅿 𓆀 𓆁 𓆂 𓆃 𓆄 𓆅 𓆆 𓆇 𓆈 𓆉 𓆊 𓆋 𓆌 𓆍 𓆎 𓆐 𓆑 𓆒 𓆓 𓆔 𓆕 𓆖 𓆗 𓆘 𓆙 𓆚 𓆛 𓆜 𓆝 𓆞 𓆟 𓆠 𓆡 𓆢 𓆣 𓆤 𓆥 𓆦 𓆧 𓆨 𓆩𓆪 𓆫 𓆬 𓆭 𓆮 𓆯 𓆰 𓆱 𓆲 𓆳 𓆴 𓆵 𓆶 𓆷 𓆸 𓆹 𓆺 𓆻 𓆼 𓆽 𓆾 𓆿 𓇀 𓇁 𓇂 𓇃 𓇄 𓇅 𓇆 𓇇 𓇈 𓇉 𓇊 𓇋 𓇌 𓇍 𓇎 𓇏 𓇐 𓇑 𓇒 𓇓 𓇔 𓇕 𓇖 𓇗 𓇘 𓇙 𓇚 𓇛 𓇜 𓇝 𓇞 𓇟 𓇠 𓇡 𓇢 𓇣 𓇤 𓇥 𓇦 𓇧 𓇨 𓇩 𓇪 𓇫 𓇬 𓇭 𓇮 𓇯 𓇰 𓇱 𓇲 𓇳 𓇴 𓇵 𓇶 𓇷 𓇸 𓇹 𓇺 𓇻 𓇼 𓇾 𓇿 𓈀 𓈁 𓈂 𓈃 𓈄 𓈅 𓈆 𓈇 𓈈 𓈉 𓈊 𓈋 𓈌 𓈍 𓈎 𓈏 𓈐 𓈑 𓈒 𓈓 𓈔 𓈕 𓈖 𓈗 𓈘 𓈙 𓈚 𓈛 𓈜 𓈝 𓈞 𓈟 𓈠 𓈡 𓈢 𓈣 𓈤  𓈥 𓈦 𓈧 𓈨 𓈩 𓈪 𓈫 𓈬 𓈭 𓈮 𓈯 𓈰 𓈱 𓈲 𓈳 𓈴 𓈵 𓈶 𓈷 𓈸 𓈹 𓈺 𓈻 𓈼 𓈽 𓈾 𓈿 𓉀 𓉁 𓉂 𓉃 𓉄 𓉅 𓉆 𓉇 𓉈 𓉉 𓉊 𓉋 𓉌 𓉍 𓉎 𓉏 𓉐 𓉑 𓉒 𓉓 𓉔 𓉕 𓉖 𓉗 𓉘 𓉙 𓉚 𓉛 𓉜 𓉝 𓉞 𓉟 𓉠 𓉡 𓉢 𓉣 𓉤 𓉥 𓉦 𓉧 𓉨 𓉩 𓉪 𓉫 𓉬 𓉭 𓉮 𓉯 𓉰 𓉱 𓉲 𓉳 𓉴 𓉵 𓉶 𓉷 𓉸 𓉹 𓉺 𓉻 𓉼 𓉽 𓉾 𓉿 𓊀 𓊁 𓊂 𓊃 𓊄 𓊅 𓊈 𓊉 𓊊 𓊋 𓊌 𓊍 𓊎 𓊏 𓊐 𓊑 𓊒 𓊓 𓊔 𓊕 𓊖 𓊗 𓊘 𓊙 𓊚 𓊛 𓊜 𓊝 𓊞 𓊟 𓊠 𓊡 𓊢 𓊣 𓊤 𓊥 𓊦 𓊧 𓊨 𓊩 𓊪 𓊫 𓊬 𓊭 𓊮 𓊯 𓊰 𓊱 𓊲 𓊳 𓊴 𓊵 𓊶 𓊷 𓊸 𓊹 𓊺 𓊻 𓊼 𓊽 𓊾 𓊿 𓋀 𓋁 𓋂 𓋃 𓋄 𓋅 𓋆 𓋇 𓋈 𓋉 𓋊 𓋋 𓋌 𓋍 𓋎 𓋏 𓋐 𓋑 𓋒 𓋓 𓋔 𓋕 𓋖 𓋗 𓋘 𓋙 𓋚 𓋛 𓋜 𓋝 𓋞 𓋟 𓋠 𓋡 𓋢 𓋣 𓋤 𓋥 𓋦 𓋧 𓋨 𓋩 𓋪 𓋫 𓋬 𓋭 𓋮 𓋯 𓋰 𓋱 𓋲 𓋳 𓋴 𓋵 𓋶 𓋷 𓋸 𓋹 𓋺 𓋻 𓋼 𓋽 𓋾 𓋿 𓌀 𓌁 𓌂 𓌃 𓌄 𓌅 𓌆 𓌇 𓌈 𓌉 𓌊 𓌋 𓌌 𓌍 𓌎 𓌏 𓌐 𓌑 𓌒 𓌓 𓌔 𓌕 𓌖 𓌗 𓌘 𓌙 𓌚 𓌛 𓌜 𓌝 𓌞 𓌟 𓌠 𓌡 𓌢 𓌣 𓌤 𓌥 𓌦 𓌧 𓌨 𓌩 𓌪 𓌫 𓌬 𓌭 𓌮 𓌯 𓌰 𓌱 𓌲 𓌳 𓌴 𓌵 𓌶 𓌷 𓌸 𓌹 𓌺 𓌻 𓌼 𓌽 𓌾 𓌿 𓍀 𓍁 𓍂 𓍃 𓍄 𓍅 𓍆 𓍇 𓍈 𓍉 𓍊 𓍋 𓍌 𓍍 𓍎 𓍏 𓍐 𓍑 𓍒 𓍓 𓍔 𓍕 𓍖 𓍗 𓍘 𓍙 𓍚 𓍛 𓍜 𓍝 𓍞 𓍟 𓍠 𓍡 𓍢 𓍣 𓍤 𓍥 𓍦 𓍧 𓍨 𓍩 𓍪 𓍫 𓍬 𓍭 𓍮 𓍯 𓍰 𓍱 𓍲 𓍳 𓍴 𓍵 𓍶 𓍷 𓍸 𓍹 𓍺 𓍻 𓍼 𓍽 𓍾 𓍿 𓎀 𓎁 𓎂 𓎃 𓎄 𓎅 𓎆 𓎇 𓎈 𓎉 𓎊 𓎋 𓎌 𓎍 𓎎 𓎏 𓎐 𓎑 𓎒 𓎓 𓎔 𓎕 𓎖 𓎗 𓎘 𓎙 𓎚 𓎛 𓎜 𓎝 𓎞 𓎟 𓎠 𓎡 𓏋 𓏌 𓏍 𓏎 𓏏 𓏐 𓏑 𓏒 𓏓 
‏ 𓏕 𓏖 𓏗 𓏘 𓏙 𓏚 𓏛 𓏜 𓏝 𓏞 𓏟 𓏠 𓏡 𓏢 𓏣 𓏤 𓏥 𓏦 𓏧 𓏨 𓏩 𓏪 𓏫 𓏬 𓏭 𓏮 𓏯 𓏰 𓏱 𓏲 𓏳 𓏴 𓏶 𓏷 𓏸 𓏹 ?? 𓏻 𓏼 𓏽 𓏾 𓏿 𓐀 𓐁 𓐂 𓐃 𓐄 𓐅 𓐆 : @$botnem.
 ",
]);}

?>
	
	
	#لاتخمط بيك خير انت اكتب لان بس الفرخ يخمط ويكول كتابتي، 
	Dev :-) @EzZzZz
	Ch :-)  @ZZZZZT