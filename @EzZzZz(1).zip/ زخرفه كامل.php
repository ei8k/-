<?php 

BY : IKETO
Code : @HHHHR
CH : @KQQQQ

ob_start();
$API_KEY = "998817210:AAGsEHNVKga3nSc_fzLazgPb6Tz7axBnGbA";#توكن البوت
define('API_KEY',$API_KEY);
echo "<a href='https://api.telegram.org/bot$API_KEY/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']."'>setwebhook</a>";
echo file_get_contents("https://api.telegram.org/bot$API_KEY/setwebhook?url=".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']);
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url); curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{return json_decode($res);}}
#         iKETO BOOS         #
$update   = json_decode(file_get_contents('php://input'));
$message  = $update->message;
$text     = $message->text;
$chat_id  = $message->chat->id;
$name     = $message->from->first_name;
$user     = $message->from->username;
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
$a = strtolower($text);
/*
تم كتابة الأكواد بواسطة 🅂 🄰 🄸 🄴 🄳 ㋡ | @T4TTTT

- Follow our new 🖤✨! | تابع جديدنا 💭✔️..

- @SAIEDCH ✅..
*/
/*
تنقل اذكر المصدر 🌚
صير فرخ واخمط 🌚😹
*/
$T4TTTT = 1010918290; //ايديك
$SAIED = file_get_contents("SAIED.txt");
$SAIED0 = file_get_contents("SAIED0.txt");
$SAIED1= file_get_contents("SAIED1.txt");
$SAIED5 = file_get_contents("SAIED2.txt");
$SAIED6 = file_get_contents("SAIED3.txt");
$SAIED20 = json_decode(file_get_contents('php://input'));
$SAIED18 = $update->message;
$SAIED13 = $SAIED18->chat->id;
$SAIED17 = $SAIED18->text;
$SAIED19 = $SAIED20->callback_query->data;
$SAIED12 = $SAIED20->callback_query->message->chat->id;
$SAIED14 =  $SAIED20->callback_query->message->message_id;
$SAIED15 = $SAIED18->from->first_name;
$SAIED16 = $SAIED18->from->username;
$SAIED11 = $SAIED18->from->id;
$SAIED2 = explode("\n",file_get_contents("SAIED4.txt"));
$SAIED3 = count($SAIED2)-1;
if ($SAIED18 && !in_array($SAIED11, $SAIED2)) {
    file_put_contents("SAIED4.txt", $SAIED11."\n",FILE_APPEND);
  }
$SAIED9 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$SAIED0&user_id=".$SAIED11);
$SAIED10 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$SAIED1&user_id=".$SAIED11);
if($SAIED18 && (strpos($SAIED9,'"status":"left"') or strpos($SAIED9,'"Bad Request: USER_ID_INVALID"') or strpos($SAIED9,'"status":"kicked"') or strpos($SAIED10,'"status":"left"') or strpos($SAIED10,'"Bad Request: USER_ID_INVALID"') or strpos($SAIED10,'"status":"kicked"'))!== false){
bot('sendMessage', [
'chat_id'=>$SAIED13,
'text'=>'- اشترك في قنوات البوت أولا لتتمكن من إستخدامه 🤖".

'.$SAIED0.'
'.$SAIED1,
]);return false;}
if($SAIED17 == "SAIED" and $SAIED11 == $T4TTTT){
bot("sendmessage",[
"chat_id"=>$SAIED13,
"text"=>'- أهلا بك في قائمة المطور 👨🏻‍✈️".',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- أوامر قناة الإشتراك الإجباري الأولى 📡1⃣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- وضع قناة 📡✅".' ,'callback_data'=>"SAIED0"],['text'=>'- حذف القناة 📡❎".' ,'callback_data'=>"SAIED1"]],
[['text'=>'- أوامر قناة الإشتراك الإجباري الثانية 📢2⃣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- وضع قناة 📢✅".' ,'callback_data'=>"SAIED2"],['text'=>'- حذف القناة 📢❎".' ,'callback_data'=>"SAIED3"]],
[['text'=>'- عرض قنوات الإشتراك الإجباري 📜".' ,'callback_data'=>"SAIED4"]],
[['text'=>'- أوامر الإذاعة 🗣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- نشر توجيه ↪️".' ,'callback_data'=>"SAIED5"],['text'=>'- نشر رسالة 📝".' ,'callback_data'=>"SAIED6"]],
[['text'=>'- عدد المشتركين 👥".' ,'callback_data'=>"SAIED7"]],
[['text'=>'- التنبيه عند دخول أحد للبوت 🚸".' ,'callback_data'=>"SAIED"]],
[['text'=>'- تفعيل التنبيه 🚸✅".' ,'callback_data'=>"SAIED9"],['text'=>'- تعطيل التنبيه 🚸❎".' ,'callback_data'=>"SAIED10"]],
[['text'=>'- توجيه الرسائل من الأعضاء 🔃".' ,'callback_data'=>"SAIED"]],
[['text'=>'- تفعيل للتوجيه 🔃✅".' ,'callback_data'=>"SAIED11"],['text'=>'- تعطيل للتوجيه 🔃❎".' ,'callback_data'=>"SAIED12"]],
   ] 
   ])
]);
}
if($SAIED19 == "SAIED" ){
bot('EditMessageText',[
'chat_id'=>$SAIED12,
'message_id'=>$SAIED14,
"text"=>'- أهلا بك في قائمة المطور 👨🏻‍✈️".',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- أوامر قناة الإشتراك الإجباري الأولى 📡1⃣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- وضع قناة 📡✅".' ,'callback_data'=>"SAIED0"],['text'=>'- حذف القناة 📡❎".' ,'callback_data'=>"SAIED1"]],
[['text'=>'- أوامر قناة الإشتراك الإجباري الثانية 📢2⃣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- وضع قناة 📢✅".' ,'callback_data'=>"SAIED2"],['text'=>'- حذف القناة 📢❎".' ,'callback_data'=>"SAIED3"]],
[['text'=>'- عرض قنوات الإشتراك الإجباري 📜".' ,'callback_data'=>"SAIED4"]],
[['text'=>'- أوامر الإذاعة 🗣".' ,'callback_data'=>"SAIED"]],
[['text'=>'- نشر توجيه ↪️".' ,'callback_data'=>"SAIED5"],['text'=>'- نشر رسالة 📝".' ,'callback_data'=>"SAIED6"]],
[['text'=>'- عدد المشتركين 👥".' ,'callback_data'=>"SAIED7"]],
[['text'=>'- التنبيه عند دخول أحد للبوت 🚸".' ,'callback_data'=>"SAIED"]],
[['text'=>'- تفعيل التنبيه 🚸✅".' ,'callback_data'=>"SAIED9"],['text'=>'- تعطيل التنبيه 🚸❎".' ,'callback_data'=>"SAIED10"]],
[['text'=>'- توجيه الرسائل من الأعضاء 🔃".' ,'callback_data'=>"SAIED"]],
[['text'=>'- تفعيل للتوجيه 🔃✅".' ,'callback_data'=>"SAIED11"],['text'=>'- تعطيل للتوجيه 🔃❎".' ,'callback_data'=>"SAIED12"]],
   ] 
   ])
]);
unlink("SAIED.txt");
}
if($SAIED19 == "SAIED0"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- أرسل معرف القناة الآن Ⓜ️".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- إلغاء ❌".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED.txt","SAIED0");
}
if($SAIED17 and $SAIED == "SAIED0" and $SAIED11 == $T4TTTT){
bot("sendmessage",[
"chat_id"=>$SAIED13,
"text"=>'- تم حفظ معرف القناة بنجاح ✅".

- تأكد من أن البوت أدمن في القناة ليتم تفعيل الإشتراك الإجباري 👨🏻‍✈️".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED0.txt","$SAIED17");
unlink("SAIED.txt");
}
if($SAIED19 == "SAIED1"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم حذف القناة بنجاح ✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
unlink("SAIED0.txt");
}
if($SAIED19 == "SAIED2"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- أرسل معرف القناة الآن Ⓜ️".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- إلغاء ❌".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED.txt","SAIED1");
}
if($SAIED17 and $SAIED == "SAIED1" and $SAIED11 == $T4TTTT){
bot("sendmessage",[
"chat_id"=>$SAIED13,
"text"=>'- تم حفظ معرف القناة بنجاح ✅".

- تأكد من أن البوت أدمن في القناة ليتم تفعيل الإشتراك الإجباري 👨🏻‍✈️".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED1.txt","$SAIED17");
unlink("SAIED.txt");
}
if($SAIED19 == "SAIED3"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم حذف القناة بنجاح ✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
unlink("SAIED1.txt");
}
if($SAIED19 == "SAIED4"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- هذه هي قائمة قنوات الإشتراك الإجباري 📜".

- القناة الأولى '.$SAIED0.' 📡".

- القناة الثانية '.$SAIED1.' 📢".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
}
if($SAIED19 == "SAIED5"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- أرسل رسالتك ليتم نشرها توجيه لجميع الأعضاء ↪️".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- إلغاء ❌".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED.txt","SAIED2");
}
if($SAIED18 and $SAIED == "SAIED2" and $SAIED11 == $T4TTTT){
bot("sendmessage",[
"chat_id"=>$SAIED13,
"text"=>'- تم التوجيه بنجاح ✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
for($i=0;$i<count($SAIED2); $i++){
bot('forwardMessage', [
'chat_id'=>$SAIED2[$i],
'from_chat_id'=>$SAIED11,
'message_id'=>$SAIED18->message_id
]);
unlink("SAIED.txt");
}
}
if($SAIED19 == "SAIED6"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- أرسل رسالتك ليتم نشرها رسالة لجميع الأعضاء 📝".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- إلغاء ❌".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED.txt","SAIED3");
}
if($SAIED17 and $SAIED == "SAIED3" and $SAIED11 == $T4TTTT){
bot("sendmessage",[
"chat_id"=>$SAIED13,
"text"=>'- تم النشر بنجاح ✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
for($i=0;$i<count($SAIED2); $i++){
bot('sendMessage', [
'chat_id'=>$SAIED2[$i],
'text'=>$SAIED17
]);
unlink("SAIED.txt");
}
}
if($SAIED19 == "SAIED7"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- عدد مشتركين البوت هو '.$SAIED3.' 👥".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
}
if($SAIED19 == "SAIED9"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم تفعيل تنبيه دخول الأعضاء 🚸✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED2.txt","SAIED");
}
if($SAIED17 == "/admin" and $SAIED5 == "SAIED" and $SAIED11 != $T4TTTT){
bot("sendmessage",[
"chat_id"=>$T4TTTT,
"text"=>'- دخل شخص إلى البوت 🚶‍♂".

- اسمه '.$SAIED15.' 🔠".

- معرفه '.$SAIED16.' Ⓜ️".

- ايديه '.$SAIED11.' 🆔".',
]);
}
if($SAIED19 == "SAIED10"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم تعطيل تنبيه دخول الأعضاء 🚸❎".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
unlink("SAIED2.txt");
}
if($SAIED19 == "SAIED11"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم تفعيل توجيه الرسائل 🔃✅".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
file_put_contents("SAIED3.txt","SAIED");
}
if($SAIED18 and $SAIED6 == "SAIED" and $SAIED11 != $T4TTTT){
bot('forwardMessage', [
'chat_id'=>$T4TTTT,
'from_chat_id'=>$SAIED11,
'message_id'=>$SAIED18->message_id
]);
}
if($SAIED18 and $SAIED6 == "SAIED" and $SAIED11 == $T4TTTT){
bot('sendMessage',[
'chat_id'=>$SAIED18->reply_to_message->forward_from->id,
    'text'=>$SAIED17,
    ]);
}
if($SAIED19 == "SAIED12"){
bot('EditMessageText',[
    'chat_id'=>$SAIED12,
    'message_id'=>$SAIED14,
'text'=>'- تم تعطيل توجيه الرسائل 🔃❎".',
 'reply_markup'=>json_encode([ 
      'inline_keyboard'=>[
[['text'=>'- رجوع ↩️".' ,'callback_data'=>"SAIED"]],
]])
]);
unlink("SAIED.txt");
unlink("SAIED3.txt");
}
/*
تم كتابة الأكواد بواسطة 🅂 🄰 🄸 🄴 🄳 ㋡ | @T4TTTT

- Follow our new 🖤✨! | تابع جديدنا 💭✔️..

- @SAIEDCH ✅..
*/
/*
تنقل اذكر المصدر 🌚
صير فرخ واخمط 🌚😹
*/
if ($text == '/start' && !in_array($chat_id, $band)){
    bot('sendMessage',[
        'chat_id'=>$chat_id,
         'text' => "- اهلا بك ؛ [$name](tg://user?id=$chat_id)
- ارسل اسمك بالانكليزيةه وانتظر قليلا ، 🕊 '
- يمنع استخدام الاحرف العربية او الرموز ، 📄'
- يحتوي البوت على اكثر من *4* انوع ، 🌀'
- ارسل اسمك وقم بتجربته بنفسك ، 🌼'
• يتم اضافةه حروف جديد كل يوم ،♥!' 
﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎
[)",
'parse_mode' => "MarkDown", 'disable_web_page_preview' => true, 'reply_markup' => json_encode(['inline_keyboard' => [[['text' => "• مطور البوت ، 🔰'", 'url' => "https://t.me/EzZzZz"]], ]]) ]);
}
if($_GET['s']){
    $text = 'sssasa';
    echo $count = count($text); 
}
if($text != '/start'and$text!='/us'){
  $items = ['𝆔𝆕','𝆮','𝆯𝆴','𝆳𝆺','𝆹𝅥𝅯','𝆺𝅥𝅮','𝆹𝅥𝅮','𝆺𝅥𝅯','𝇕','𝅘𝅥𝅯','𝅘𝅥𝅮','𝄵','𝄮','𝄬','𝄋','𖠛','𖠜','𖠲','𖡥'];
  $_smile = array_rand($items,1);
  $smile = $items[$_smile];
   $count = count($text); 
   $k = strtolower('a','𝐴',$k); 
 $a = str_replace('b','𝐵',$k); 
 $k = str_replace('c','𝐶',$k); 
 $k = str_replace('d','𝐷',$k); 
 $k = str_replace('e','𝐸',$k); 
 $k = str_replace('f','𝐹',$k); 
 $k = str_replace('g','𝐺',$k); 
 $k = str_replace('h','𝐻',$k); 
 $k = str_replace('i','𝐼',$k); 
 $k = str_replace('j','𝐽',$k); 
 $k = str_replace('k','𝐾',$k); 
 $k = str_replace('l','𝐿',$k); 
 $k = str_replace('m','𝑀',$k); 
 $k = str_replace('n','𝑁',$k); 
 $k = str_replace('o','𝑂',$k); 
 $k = str_replace('p','𝑃',$k); 
 $k = str_replace('q','𝑄',$k); 
 $k = str_replace('r','𝑅',$k); 
 $k = str_replace('s','𝑆',$k); 
 $k = str_replace('t','𝑇',$k); 
 $k = str_replace('u','𝑈',$k); 
 $k = str_replace('v','𝑉',$k); 
 $k = str_replace('w','𝑊',$k); 
 $k = str_replace('x','𝑋',$k); 
 $k = str_replace('y','𝑌',$k); 
 $k = str_replace('z','𝑍',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
$k = str_replace('a','𝐀',$text); 
 $k = str_replace('b','𝐁',$k); 
 $k = str_replace('c','𝐂',$k); 
 $k = str_replace('d','𝐃',$k); 
 $k = str_replace('e','𝐄',$k); 
 $k = str_replace('f','𝐅',$k); 
 $k = str_replace('g','𝐆',$k); 
 $k = str_replace('h','𝐇',$k); 
 $k = str_replace('i','𝐈',$k); 
 $k = str_replace('j','𝐉',$k); 
 $k = str_replace('k','𝐊',$k); 
 $k = str_replace('l','𝐋',$k); 
 $k = str_replace('m','𝐌',$k); 
 $k = str_replace('n','𝐍',$k); 
 $k = str_replace('o','𝐎',$k); 
 $k = str_replace('p','𝐏',$k); 
 $k = str_replace('q','𝐐',$k); 
 $k = str_replace('r','𝐑',$k); 
 $k = str_replace('s','𝐒',$k); 
 $k = str_replace('t','𝐓',$k); 
 $k = str_replace('u','𝐔',$k); 
 $k = str_replace('v','𝐕',$k); 
 $k = str_replace('w','𝐖',$k); 
 $k = str_replace('x','𝐗',$k); 
 $k = str_replace('y','𝐘',$k); 
 $k = str_replace('z','𝐙',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
   $k = str_replace('a','𝖆',$text); 
 $k = str_replace('b','𝖇',$k); 
 $k = str_replace('c','𝖈',$k); 
 $k = str_replace('d','𝖉',$k); 
 $k = str_replace('e','𝖊',$k); 
 $k = str_replace('f','𝖋',$k); 
 $k = str_replace('g','𝖌',$k); 
 $k = str_replace('h','𝖍',$k); 
 $k = str_replace('i','𝖎',$k); 
 $k = str_replace('j','𝖏',$k); 
 $k = str_replace('k','𝖐',$k); 
 $k = str_replace('l','𝖑',$k); 
 $k = str_replace('m','𝖒',$k); 
 $k = str_replace('n','𝖓',$k); 
 $k = str_replace('o','𝖔',$k); 
 $k = str_replace('p','𝖕',$k); 
 $k = str_replace('q','𝖖',$k); 
 $k = str_replace('r','𝖗',$k); 
 $k = str_replace('s','𝖘',$k); 
 $k = str_replace('t','𝖙',$k); 
 $k = str_replace('u','𝖚',$k); 
 $k = str_replace('v','𝖛',$k); 
 $k = str_replace('w','𝖜',$k); 
 $k = str_replace('x','𝖝',$k); 
 $k = str_replace('y','𝖞',$k); 
 $k = str_replace('z','𝖟',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]); 
   $k = $text;
   $k = str_replace('a','𝙰',$text); 
 $k = str_replace('b','𝙱',$k); 
 $k = str_replace('c','𝙲',$k); 
 $k = str_replace('d','𝙳',$k); 
 $k = str_replace('e','𝙴',$k); 
 $k = str_replace('f','𝙵',$k); 
 $k = str_replace('g','𝙶',$k); 
 $k = str_replace('h','𝙷',$k); 
 $k = str_replace('i','𝙸',$k); 
 $k = str_replace('j','𝙹',$k); 
 $k = str_replace('k','𝙺',$k); 
 $k = str_replace('l','𝙻',$k); 
 $k = str_replace('m','𝙼',$k); 
 $k = str_replace('n','𝙽',$k); 
 $k = str_replace('o','𝙾',$k); 
 $k = str_replace('p','𝙿',$k); 
 $k = str_replace('q','𝚀',$k); 
 $k = str_replace('r','𝚁',$k); 
 $k = str_replace('s','𝚂',$k); 
 $k = str_replace('t','𝚃',$k); 
 $k = str_replace('u','𝙺',$k); 
 $k = str_replace('v','𝚅',$k); 
 $k = str_replace('w','𝚆',$k); 
 $k = str_replace('x','𝚇',$k); 
 $k = str_replace('y','𝚈',$k); 
 $k = str_replace('z','𝚉',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]);
   $k = $text;
$k = str_replace('a','𝒂',$text); 
 $k = str_replace('b','𝒃',$k); 
 $k = str_replace('c','𝒄',$k); 
 $k = str_replace('d','𝒅',$k); 
 $k = str_replace('e','𝒆',$k); 
 $k = str_replace('f','𝒇',$k); 
 $k = str_replace('g','𝒈',$k); 
 $k = str_replace('h','𝒉',$k); 
 $k = str_replace('i','𝒊',$k); 
 $k = str_replace('j','𝒋',$k); 
 $k = str_replace('k','𝒌',$k); 
 $k = str_replace('l','𝒍',$k); 
 $k = str_replace('m','𝒎',$k); 
 $k = str_replace('n','𝒏',$k); 
 $k = str_replace('o','𝒐',$k); 
 $k = str_replace('p','𝒑',$k); 
 $k = str_replace('q','𝒒',$k); 
 $k = str_replace('r','𝒓',$k); 
 $k = str_replace('s','𝒔',$k); 
 $k = str_replace('t','𝒕',$k); 
 $k = str_replace('u','𝒖',$k); 
 $k = str_replace('v','𝒗',$k); 
 $k = str_replace('w','𝒘',$k); 
 $k = str_replace('x','𝒙',$k); 
 $k = str_replace('y','𝒚',$k); 
 $k = str_replace('z','𝒛',$k);
   bot('sendMessage',[
        'chat_id'=>$chat_id,
        'text'=>$k." ".$smile
   ]);
} 

